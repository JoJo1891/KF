import React from 'react';
import { NavigationContainer } from '@react-navigation/native';

import ScreensContainer from './ScreensContainer';

const AppNavigation = () => {
    return <NavigationContainer>
        <ScreensContainer/>
    </NavigationContainer>
}

export default AppNavigation;