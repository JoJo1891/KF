import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigation } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  LoginScreen,
  ForgotPasswordScreen,
  RegisterScreen,
  InscriptionScreen,
  SliderScreen,
  EmailPasswordScreen,
  HelpScreen,
  Inscription,
  CardScreen,
  CatalogScreen,
  AdvantagesScreen,
  BonusPlansScreen,
  DealsScreen,
  CashBackScreen,
  CashBackCodeScreen,
  SelectZoneScreen,
  CguScreen,
  RecommendScreen,
  FaqsScreen,
  RequestAccountScreen,
  DeleteAccountScreen,
  ScannerScreen,
  ScannerScreenError,
  CardSuccessScreen,
  WhoWeAreScreen,
  ConfianceScreen,
  MenuScreen,
  CompteScreen,
  ContactScreen,
  ParameterScreen,
  MesPointsScreen,
  RatingPage,
  NotificationScreen,
  HomeTutorialStep1,
  ProfileScreen,
  ReferalScreen,
  SecurityScreen,
  DeleteAccount1Screen,
  AccountDeletedScreen,
  SetNotificationScreen,
  ManualCardScreen,
  EarningsHistoryScreen,
  ChallengeScoringScreen,
  HomeTutorialStep2,
  HomeTutorialStep3,
  HomeTutorialStep4,
  HomeTutorialStep5,
  MesPointsTutorial1,
  MesPointsTutorial2,
  MesPointsTutorial3,
  Menu2Tutorial1,
  Menu2Tutorial2,
  Menu2Tutorial3,
  Home3Tutorial1,
  Home3Tutorial2,
  CardScreenTurorial1,
  CardScreenTurorial2,
  CardScreenTurorial3,
  CardScreenTurorial4,
  CardScreenTurorial5,
  CardScreenTurorial6,
  CardScreenTurorial7,
  CardScreenTurorial8,
  ProgramesFidelitesScreen,
  PointsAideScreen,
  DefisPointsScreen,
  CardErrorScreen,
  ScannerBPScreen,
  HistoryPointsPrograms,
} from '../screens';
import TabBar from '../navigation/TabBarComponent';
import { getUser } from '../api/user';
import { selectIsLogged, setIsLogged, setUser } from '../state/auth';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import * as Notifications from 'expo-notifications';
import { registerForPushNotificationsAsync } from '../state/ExpoPushToken';
import { setNotificationsToken } from '../api/notifications';
import {
  setCashBackUsed,
  setNewStories,
  setNotificationReceived,
} from '../state/notificationsReceived';

const Stack = createStackNavigator();

const NavigationContainer = () => {
  const isLogged = useSelector(selectIsLogged);
  const [expoPushToken, setExpoPushToken] = useState('');
  const [notification, setNotification] = useState(false);
  const notificationListener = useRef();
  const responseListener = useRef();
  const queryClient = useQueryClient();

  const navigation = useNavigation();
  const dispatch = useDispatch();

  const registerExpoPushToken = useMutation(setNotificationsToken, {
    onSuccess: (response) => {
      //console.log(response)
    },
    onError: (error) => {
      //
    },
    onSettled: () => {
      queryClient.invalidateQueries('setNotificationsToken');
    },
  });

  const backgroundOpacity = {
    animationEnabled: true,
    cardStyle: { backgroundColor: 'rgba(0, 0, 0, 0.85)' },
    cardOverlayEnabled: true,
    cardStyleInterpolator: ({ current: { progress } }) => {
      return {
        cardStyle: {
          opacity: progress.interpolate({
            inputRange: [0, 0.5, 0.9, 1],
            outputRange: [0, 0.25, 0.7, 1],
          }),
        },
        overlayStyle: {
          opacity: progress.interpolate({
            inputRange: [0, 1],
            outputRange: [0, 0.5],
            extrapolate: 'clamp',
          }),
        },
      };
    },
  };

  const checkNotificationStories = () => {
    notificationListener.current =
      Notifications.addNotificationReceivedListener((notification) => {
        if (notification.request.content.body.endsWith('partagé une storie')) {
          setTimeout(function () {
            dispatch(setNewStories(true));
          }, 2000);
        }
      });
  };

  useEffect(() => {
    if (isLogged) {
      registerForPushNotificationsAsync().then((token) => {
        setExpoPushToken(token);
        if (token !== 'denied') {
          registerExpoPushToken.mutate(token);
        } else {
          //console.log("AQUIIIII nooo : "+token)
        }
      });

      notificationListener.current =
        Notifications.addNotificationReceivedListener((notification) => {
          if (
            notification.request.content.body ===
            "Vous venez d'utiliser votre cashback !"
          ) {
            dispatch(setCashBackUsed(true));
          }
          dispatch(setNotificationReceived(true));
          setNotification(notification);
        });

      responseListener.current =
        Notifications.addNotificationResponseReceivedListener((response) => {
          navigation.navigate('NotificationScreen');
        });

      return () => {
        Notifications.removeNotificationSubscription(
          notificationListener.current
        );
        Notifications.removeNotificationSubscription(responseListener.current);
      };
    } else {
      //checkNotificationStories();
    }
  }, [isLogged]);

  useEffect(() => {
    checkLogin();
    checkInscription();
    checkNotificationStories();
  }, []);

  useQuery('checkLogin', checkLogin);

  const checkInscription = async () => {
    try {
      const inscription = await AsyncStorage.getItem('inscription');
      const slider = await AsyncStorage.getItem('slider');
      let day = new Date();
      //console.log(inscription)
      if (slider) {
        if (inscription && inscription === 'true') {
          //  await AsyncStorage.removeItem('inscription');
          // await AsyncStorage.removeItem('slider');
          //  Alert.alert("Si :"+inscription);
        } else if (inscription && inscription !== 'true') {
          let reminderDate = new Date(inscription);
          if (day > reminderDate) {
            day.setDate(day.getDate() + 1);
            await AsyncStorage.setItem('inscription', day.toString());
            navigation.navigate('Inscription');
          }
        } else {
          day.setDate(day.getDate() + 1);
          await AsyncStorage.setItem('inscription', day.toString());
          navigation.navigate('Inscription');
        }
      }
    } catch (error) {
      //
    }
  };

  const checkLogin = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      if (!token) {
        try {
          const slider = await AsyncStorage.getItem('slider');
          if (slider === 'true') {
            navigation.navigate('SelectZoneScreen');
          } else {
            navigation.navigate('SliderScreen');
          }
        } catch (error) {
          //xs navigation.navigate('HomeScreen')
        }
      } else {
        //console.log(token)
        await AsyncStorage.setItem('inscription', 'true');
        const user = await getUser();
        dispatch(setIsLogged(true));
        dispatch(setUser(user));
        navigation.navigate('Home');
      }
    } catch (error) {
      navigation.navigate('SliderScreen');
    }
  };

  return (
    <Stack.Navigator
      initialRouteName="Home"
      screenOptions={{
        headerShown: false,
        presentation: 'transparentModal',
      }}
    >
      <Stack.Screen name="Home" component={TabBar} />
      <Stack.Screen name="LoginScreen" component={LoginScreen} />
      <Stack.Screen name="RegisterScreen" component={RegisterScreen} />
      <Stack.Screen
        name="ForgotPasswordScreen"
        component={ForgotPasswordScreen}
      />
      <Stack.Screen name="InscriptionScreen" component={InscriptionScreen} />
      <Stack.Screen name="SliderScreen" component={SliderScreen} />
      <Stack.Screen
        name="EmailPasswordScreen"
        component={EmailPasswordScreen}
      />
      <Stack.Screen name="CardScreen" component={CardScreen} />
      <Stack.Screen name="CatalogScreen" component={CatalogScreen} />
      <Stack.Screen name="AdvantagesScreen" component={AdvantagesScreen} />
      <Stack.Screen name="BonusPlansScreen" component={BonusPlansScreen} />
      <Stack.Screen name="DealsScreen" component={DealsScreen} />
      <Stack.Screen name="CashBackScreen" component={CashBackScreen} />
      <Stack.Screen name="CashBackCodeScreen" component={CashBackCodeScreen} />
      <Stack.Screen name="SelectZoneScreen" component={SelectZoneScreen} />
      <Stack.Screen name="MenuScreen" component={MenuScreen} />
      <Stack.Screen name="CompteScreen" component={CompteScreen} />
      <Stack.Screen name="ProfileScreen" component={ProfileScreen} />
      <Stack.Screen name="ReferalScreen" component={ReferalScreen} />
      <Stack.Screen name="ParameterScreen" component={ParameterScreen} />
      <Stack.Screen name="HelpScreen" component={HelpScreen} />
      <Stack.Screen name="Inscription" component={Inscription} />
      <Stack.Screen name="CguScreen" component={CguScreen} />
      <Stack.Screen name="ContactScreen" component={ContactScreen} />
      <Stack.Screen name="RecommendScreen" component={RecommendScreen} />
      <Stack.Screen name="FaqsScreen" component={FaqsScreen} />
      <Stack.Screen
        name="RequestAccountScreen"
        component={RequestAccountScreen}
      />
      <Stack.Screen
        name="DeleteAccountScreen"
        component={DeleteAccountScreen}
      />
      <Stack.Screen
        name="DeleteAccount1Screen"
        component={DeleteAccount1Screen}
      />
      <Stack.Screen
        name="AccountDeletedScreen"
        component={AccountDeletedScreen}
      />
      <Stack.Screen name="WhoWeAreScreen" component={WhoWeAreScreen} />
      <Stack.Screen name="ConfianceScreen" component={ConfianceScreen} />
      <Stack.Screen name="SecurityScreen" component={SecurityScreen} />
      <Stack.Screen name="MesPointsScreen" component={MesPointsScreen} />
      <Stack.Screen name="RatingPage" component={RatingPage} />
      <Stack.Screen
        name="SetNotificationScreen"
        component={SetNotificationScreen}
      />
      <Stack.Screen name="ScannerScreen" component={ScannerScreen} />
      <Stack.Screen name="ScannerBPScreen" component={ScannerBPScreen} />
      <Stack.Screen name="ScannerScreenError" component={ScannerScreenError} />
      <Stack.Screen name="CardSuccessScreen" component={CardSuccessScreen} />
      <Stack.Screen name="ManualCardScreen" component={ManualCardScreen} />
      <Stack.Screen
        name="ProgramesFidelitesScreen"
        component={ProgramesFidelitesScreen}
      />
      <Stack.Screen name="PointsAideScreen" component={PointsAideScreen} />
      <Stack.Screen
        name="EarningsHistoryScreen"
        component={EarningsHistoryScreen}
      />
      <Stack.Screen name="DefisPointsScreen" component={DefisPointsScreen} />
      <Stack.Screen
        name="ChallengeScoringScreen"
        component={ChallengeScoringScreen}
      />
      <Stack.Screen name="NotificationScreen" component={NotificationScreen} />
      <Stack.Screen
        name="HistoryPointsPrograms"
        component={HistoryPointsPrograms}
      />
      <Stack.Screen name="CardErrorScreen" component={CardErrorScreen} />
      <Stack.Screen
        name="HomeTutorialStep1"
        component={HomeTutorialStep1}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="HomeTutorialStep2"
        component={HomeTutorialStep2}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="HomeTutorialStep3"
        component={HomeTutorialStep3}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="HomeTutorialStep4"
        component={HomeTutorialStep4}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="HomeTutorialStep5"
        component={HomeTutorialStep5}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="MesPointsTutorial1"
        component={MesPointsTutorial1}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="MesPointsTutorial2"
        component={MesPointsTutorial2}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="MesPointsTutorial3"
        component={MesPointsTutorial3}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="Menu2Tutorial1"
        component={Menu2Tutorial1}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="Menu2Tutorial2"
        component={Menu2Tutorial2}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="Menu2Tutorial3"
        component={Menu2Tutorial3}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="Home3Tutorial1"
        component={Home3Tutorial1}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="Home3Tutorial2"
        component={Home3Tutorial2}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="CardScreenTurorial1"
        component={CardScreenTurorial1}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="CardScreenTurorial2"
        component={CardScreenTurorial2}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="CardScreenTurorial3"
        component={CardScreenTurorial3}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="CardScreenTurorial4"
        component={CardScreenTurorial4}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="CardScreenTurorial5"
        component={CardScreenTurorial5}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="CardScreenTurorial6"
        component={CardScreenTurorial6}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="CardScreenTurorial7"
        component={CardScreenTurorial7}
        options={backgroundOpacity}
      />
      <Stack.Screen
        name="CardScreenTurorial8"
        component={CardScreenTurorial8}
        options={backgroundOpacity}
      />
    </Stack.Navigator>
  );
};

export default NavigationContainer;
