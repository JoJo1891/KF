import React from 'react';
import { useSelector } from 'react-redux';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {HomeScreen, MenuScreen, CardsScreen} from '../screens';

import WalletInactiveIcon from '../assets/icons/wallet_inactive.svg';
import WalletActiveIcon from '../assets/icons/wallet_active.svg';
import GfActiveIcon from '../assets/icons/gf-active.svg';
import GfInactiveIcon from '../assets/icons/gf-inactive.svg';
import UserInactiveIcon from '../assets/icons/user_inactive.svg';
import UserActiveIcon from '../assets/icons/user_active.svg';

import { moderateVerticalScale } from 'react-native-size-matters';
import { selectIsLogged } from '../state/auth';

const Tab = createBottomTabNavigator();

const TabBar = ({navigation}) => {
    const isLogged = useSelector(selectIsLogged)
    return (<Tab.Navigator
        initialRouteName="HomeScreen"
        screenOptions={({route})=>({
            tabBarIcon : ({ focused ,}) => {
                let currentTab;
                if(route.name === 'HomeScreen'){
                    currentTab = focused ? (
                        <GfActiveIcon />
                      ) : (
                        <GfInactiveIcon/>
                      );
                }else if(route.name === 'MenuScreen'){
                    currentTab = focused ? (
                    <UserActiveIcon />
                    ) : (
                      <UserInactiveIcon/>
                    );
                    //  FIX MEEEEEE!
                }else if(route.name === 'CardsScreen'){
                    currentTab = focused ? (
                    <WalletActiveIcon />
                    ) : (
                      <WalletInactiveIcon/>
                    );
                }
                return currentTab
            },
            headerShown : false,
            tabBarShowLabel : false,
            tabBarStyle : {
                height : moderateVerticalScale(55)
            }
        })}
    >
        <Tab.Screen name="CardsScreen" component={CardsScreen} listeners={{
            tabPress : e =>{
                e.preventDefault()
                if(!isLogged){
                    navigation.navigate('Inscription')
                }else{
                    navigation.navigate('CardsScreen')
                }
                
            }
        }}/>
        <Tab.Screen name="HomeScreen" component={HomeScreen}/>
        <Tab.Screen name="MenuScreen" component={MenuScreen}/>
    </Tab.Navigator>)
}

export default TabBar;