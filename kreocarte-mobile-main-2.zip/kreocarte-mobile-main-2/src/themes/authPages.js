
import { StyleSheet } from 'react-native';
import { useFonts } from 'expo-font';
import { windowHeight } from '.';



export const defaultAuthForm = StyleSheet.create({
      
  
    enregistrer:{
        fontSize: 24,
        color:"#FFFFFF",
        fontFamily: 'MontserratRegular',
        textAlign: 'center'
    },
    bienvenue:{
        fontSize: 40, 
        paddingLeft: 26,
        color:"#FFFFFF",
        fontFamily: 'MontserratBold'
    },
    inputContainer:{
      
        flexDirection:"row",
        alignItems:"center",
        marginHorizontal: 17,
        borderBottomWidth :1,
        marginTop:40,
        paddingHorizontal:16,
        borderColor:"#FFFFFF",
        paddingVertical:7,
        
    },
    inputTxt:{
        flex : 1,
        paddingHorizontal:10,
        fontSize: 18, 
        fontFamily: 'MontserratRegular',
        textAlign: "left", 
        color:"#FFFFFF",
        width: '100%'
    },
    inputTxtPassword:{
        flexDirection:"row",
        width: '90%'
    },
    authButton:{
        alignSelf: 'stretch',
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 25,
        flexDirection: 'row',
        marginHorizontal: 16,
        backgroundColor: 'white',
    },
    authButtText:{
        fontSize: 20,
        color: "#174B9D",
        textAlign:'center',
        fontFamily: 'MontserratSemiBold'
    },
    authButtTextDisabled:{
        fontSize: 20,
        color: "grey",
        textAlign:'center',
        fontFamily: 'MontserratSemiBold'
    }

});

export const authBackground = StyleSheet.create({
    image_backgrounds: {
        flex: 1,
        resizeMode: 'cover',
        justifyContent: 'center',
    },
    logo_background:{
        width: 84,
        height: 60,
    },
    logo_background2:{
        width: 85,
        height: 58.94,
    }
});

export const authInputInsc= StyleSheet.create({
    title:{
        fontSize: 24, 
        color:"#174B9D",
        fontFamily: 'HelveticaNeueBold',
        textAlign: 'center'
    },
    label:{
        alignItems: 'flex-start', 
        paddingHorizontal:16,
        fontSize:50,
        marginTop: 20
    },
    labelTxt:{
        fontSize: 14, 
        color:"#174B9D",
        fontFamily: 'HelveticaNeueBold',
    },
    inputContainer:{
        flexDirection:"row",
        alignItems:'center',
        backgroundColor: '#0697DC0A',
        marginHorizontal: 17,
        borderWidth:1,
        marginTop:10,
        borderColor:"#0697DC",
        borderRadius: 8,
        marginTop: 5,
        height: 50
    },
    inputTxt:{
        fontSize: 14, 
        fontFamily: 'MontserratMedium',
        textAlign: "left",
        color:'#174B9D',
        height: 50,
        width: '90%',
        paddingHorizontal: 10
    },
    authButton:{
        alignSelf: 'stretch',
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 25,
        flexDirection: 'row',
        marginHorizontal: 16,
        backgroundColor: '#174B9D',
    },
    authButtonOK:{
        alignSelf: 'stretch',
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 25,
        flexDirection: 'row',
        marginHorizontal: 16,
        backgroundColor: '#4DBDF2',
    },
    authButtText:{
        fontSize: 20,
        color: "#FFFFFF",
        textAlign:'center',
        fontFamily: 'MontserratSemiBold'
        
    },
    authButtTextDisabled:{
        fontSize: 20,
        color: "grey",
        textAlign:'center',
        fontFamily: 'MontserratSemiBold'
        
    }

    

});
