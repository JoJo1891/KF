import { createSlice } from '@reduxjs/toolkit'

export const authSlice = createSlice({
    name : 'auth',
    initialState : {
        isLogged : false,
        user : null
    },
    reducers : {
        setUser : (state,action) =>{
            state.user = action.payload
        },
        setIsLogged : (state,action) => {
            state.isLogged = action.payload
        },
        editUser : (state,action) =>{
            state.user = {
                ...state.user,
                ...action.payload
            }
        }
    }
})

export const { setUser,setIsLogged,editUser } = authSlice.actions

export const selectIsLogged = (state) => state.auth.isLogged
export const selectUser = (state) => state.auth.user

export default authSlice.reducer