import { configureStore } from '@reduxjs/toolkit'

import authReducer from './auth'
import notificationReducer from './notificationsReceived'

export default configureStore({
    reducer: {
        auth: authReducer,
        notification : notificationReducer,
    }
})