import { createSlice } from '@reduxjs/toolkit'


export const notificationSlice = createSlice({
    name : 'notification',
    initialState : {
        notificationReceived : false,
        cashBackUsed : false,
        newStories: false
    },
    reducers : {
        setNotificationReceived : (state,action) =>{
            state.notificationReceived = action.payload
        },
        setCashBackUsed : (state,action) =>{
            state.cashBackUsed = action.payload
        },
        setNewStories : (state,action) =>{
            state.newStories = action.payload
        },
    }
})

export const {setNotificationReceived, setCashBackUsed, setNewStories} = notificationSlice.actions

export const selectNotification = (state) => state.notification.notificationReceived
export const selectCashBackUsed = (state) => state.notification.cashBackUsed
export const selectNewStories= (state) => state.notification.newStories

export default notificationSlice.reducer