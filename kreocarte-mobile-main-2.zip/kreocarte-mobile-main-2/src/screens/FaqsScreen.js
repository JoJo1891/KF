import React, { useState } from "react";
import {
  Text,
  View,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Linking,
} from "react-native";
import { ScrollView } from "react-native";

import { SimpleHeaderComponent } from "../components";
import Arcordeon from "../components/partials/Arcordeon";

const FaqsScreen = () => {
  const [information1, setInformation1] = useState(false);
  const [information2, setInformation2] = useState(false);
  const [information3, setInformation3] = useState(false);
  const [information4, setInformation4] = useState(false);
  const [information5, setInformation5] = useState(false);
  const [information6, setInformation6] = useState(false);
  const [information7, setInformation7] = useState(false);
  const [information8, setInformation8] = useState(false);
  const [information9, setInformation9] = useState(false);
  const [information10, setInformation10] = useState(false);

  const handlerInfo1 = () => {
    if (information1 === true) {
      setInformation1(false);
    } else {
      setInformation1(true);
    }
  };

  const handlerInfo2 = () => {
    if (information2 === true) {
      setInformation2(false);
    } else {
      setInformation2(true);
    }
  };

  const handlerInfo3 = () => {
    if (information3 === true) {
      setInformation3(false);
    } else {
      setInformation3(true);
    }
  };

  const handlerInfo4 = () => {
    if (information4 === true) {
      setInformation4(false);
    } else {
      setInformation4(true);
    }
  };

  const handlerInfo5 = () => {
    if (information5 === true) {
      setInformation5(false);
    } else {
      setInformation5(true);
    }
  };

  const handlerInfo6 = () => {
    if (information6 === true) {
      setInformation6(false);
    } else {
      setInformation6(true);
    }
  };

  const handlerInfo7 = () => {
    if (information7 === true) {
      setInformation7(false);
    } else {
      setInformation7(true);
    }
  };

  const handlerInfo8 = () => {
    if (information8 === true) {
      setInformation8(false);
    } else {
      setInformation8(true);
    }
  };

  const handlerInfo9 = () => {
    if (information9 === true) {
      setInformation9(false);
    } else {
      setInformation9(true);
    }
  };

  const handlerInfo10 = () => {
    if (information10 === true) {
      setInformation10(false);
    } else {
      setInformation10(true);
    }
  };

  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <SimpleHeaderComponent title="FAQs" />

      <View style={styles.screenContainer}>
        <Arcordeon
          description="Comment créer, importer et effacer des cartes ?"
          type="1"
          press={handlerInfo1}
        />
        {information1 === true && (
          <View style={styles.textContainer}>
            <Text style={styles.paragraph}>
              <Text style={styles.title}>
                Comment créer une / des cartes(s) ?{"\n\n"}
              </Text>
              Sur l’écran de démarrage, vous avez accès à des suggestions de
              cartes. Appuyer sur la carte qui vous intéresse et ajoutez-la à
              votre wallet. Vous pouvez également appuyer sur le bouton « + »,
              puis cliquez sur l’enseigne référencé dans la liste ou faire une
              recherche manuellement. {"\n\n"}Une fois que vous l’avez trouver,
              cliquez dessus et rajoutez-la à votre wallet. Après avoir créé la
              carte, vous la retrouverez dans votre Wallet, prête a l’emploi.
              {"\n\n"}
              <Text style={styles.title}>
                Quelle(s) carte(s) puis-je importer sur KréoCarte ?{"\n\n"}
              </Text>
              Sur l’écran de démarrage, appuyer sur le bouton « scan ». Ensuite
              placer votre carte de fidélité dans le viseur afin de créer
              celle-ci. Dans le cas ou votre carte n’est pas reconnue par le
              viseur, vous avez la possibilité de le faire manuellement, en
              rentrant le nom, le numéro de la carte et scanner le code barre
              afin de retranscrire à l’identité du code barre.{"\n\n"}
              <Text style={styles.title}>
                Comment effacer une carte de son wallet ?{"\n\n"}
              </Text>
              Pour supprimer une carte de son wallet, faite un appui long sur la
              carte que vous souhaiter supprimer et cliquez sur la croix de
              suppression.
            </Text>
          </View>
        )}

        <Arcordeon
          description="Partager et enregistrement des cartes en mémoires ?"
          type="1"
          press={handlerInfo2}
        />
        {information2 === true && (
          <View style={styles.textContainer}>
            <Text style={styles.paragraph}>
              <Text style={styles.title}>
                La récupération de donnée est-elle possible, si je perds mon
                téléphone ?{"\n\n"}
              </Text>
              La récupération de donnée est possible, dès que vous vous
              connecterez à nouveau sur votre compte KréoCarte. {"\n\n"}
              <Text style={styles.title}>
                Une fonction cloud synchronisation est-elle utilisée ?{"\n\n"}
              </Text>
              La fonction cloud synchronisation vous permet de recevoir vos
              informations instantanément, dès votre connexion sur votre compte
              KréoCarte sur un autre appareil connecté. {"\n\n"}
              <Text style={styles.title}>
                L’utilisation de la fonction partager. {"\n\n"}
              </Text>
              Cette fonction vous permet de partager l’application à vos amis,
              familles, contacts, collègues afin qu’ils bénéficient des nombreux
              avantages.{"\n\n"}
              <Text style={styles.title}>
                Comment puis-je, partager un article avec un contact ? {"\n\n"}
              </Text>
              En cliquant sur un article, vous pouvez le partager à votre
              contact.{"\n\n"}
              <Text style={styles.title}>
                Puis-je transférer mes cartes à un autre programme de
                fidélisation ?{"\n\n"}
              </Text>
              Le transfert de ses cartes à un autre programme de fidélisation
              n’est pas possible.{"\n\n"}
            </Text>
          </View>
        )}

        <Arcordeon
          description="Scanner QR code"
          type="2"
          press={handlerInfo3}
        />
        {information3 === true && (
          <View style={styles.textContainer}>
            <Text style={styles.paragraph}>
              <Text style={styles.title}>
                Comment utiliser le scanner ? {"\n\n"}
              </Text>
              Cette fonction vous permet de scanner le Qr code du Partenaire
              afin de cumuler des points de fidélité, des tampons, du cash back
              et de bénéficier des nombreux avantages que confère l’application.
              Pour l’utilisation aller sur l’écran de démarrage, cliquez sur le
              bouton « + » et sur le bouton « scan » et placer le QR code dans
              le champ de vision de la caméra. Un signal sonore vous avertira de
              la réussite du scan. {"\n\n"}
              <Text style={styles.title}>
                Comment utiliser le flash ? {"\n\n"}
              </Text>
              Pour utiliser le flash, lors de l’utilisation du scan, appuyer sur
              le symbole de l’ampoule pour l’activer.{"\n\n"}
            </Text>
          </View>
        )}

        <Arcordeon
          description="Fonction du compte"
          type="2"
          press={handlerInfo4}
        />
        {information4 === true && (
          <View style={styles.textContainer}>
            <Text style={styles.paragraph}>
              <Text style={styles.title}>
                Dois-je créer un compte KréoCarte ?{"\n\n"}
              </Text>
              Il est primordial de créer un compte afin de pouvoir utiliser
              pleinement l’application.{"\n\n"}
              <Text style={styles.title}>
                À quoi ç sert de créer un compte ?{"\n\n"}
              </Text>
              Créer un compte vous permet de pouvoir créer des cartes de
              fidélité, d’en importer, de recevoir des bons plans, des remises
              et des cadeaux. {"\n\n"}
              <Text style={styles.title}>
                Comment pourrais-je changer mon nom ? {"\n\n"}
              </Text>
              Pour toute modification, aller sur la page « compte » puis
              « profil », cliquez sur les champs à modifier, ensuite cliquez sur
              le bouton « enregistrer ».{"\n\n"}
              <Text style={styles.title}>
                Comment supprimer mon compte ?{"\n\n"}
              </Text>
              Pour supprimer son compte aller sur la page « compte » puis
              « supprimer mon compte », cliquez sur le bouton « supprimer mon
              compte ». Après ,a suppression de son compte, il vous sera demandé
              à nouveau de créer un compte lors de la réutilisation de
              l’application. {"\n\n"}
              <Text style={styles.title}>
                Comment récupérer mon mot de passe ?{"\n\n"}
              </Text>
              Si vous avez oublié votre mot de passe, vous pouvez toute fois
              recevoir un mail de récupération. En cliquant sur le lien (mot de
              passe oublié).{"\n\n"}
            </Text>
          </View>
        )}

        <Arcordeon
          description="Modèle de carte"
          type="2"
          press={handlerInfo5}
        />
        {information5 === true && (
          <View style={styles.textContainer}>
            <Text style={styles.paragraph}>
              <Text style={styles.title}>
                Puis-je utiliser les cartes créer et importer de la même façon ?
                {"\n\n"}
              </Text>
              Vous ne pouvez pas utiliser les cartes importées de la même façon
              que les cartes référencées.{"\n\n"}
              <Text style={styles.title}>
                Une carte importée peut-elle m’apporter des points ? {"\n\n"}
              </Text>
              Une carte importée ne peut pas rapporter de point, ni de tampon
              car elle n’est pas référencée dans le programme, cela est réservé
              uniquement aux cartes partenaires.{"\n\n"}
            </Text>
          </View>
        )}

        <Arcordeon
          description="Attributions des points"
          type="2"
          press={handlerInfo6}
        />
        {information6 === true && (
          <View style={styles.textContainer}>
            <Text style={styles.paragraph}>
              <Text style={styles.title}>
                Comment m’attribuer mes tampons, mes points et mon cashback chez
                le partenaire ?{"\n\n"}
              </Text>
              Pour cumulé mes tampons, mes points et mon cashback, l’utilisateur
              devra lors de son passage en caisse , scanner avec la fonction
              « scan » de l’application le Qr code du Partenaire. {"\n\n"}
              <Text style={styles.title}>
                Comment utiliser sa récompense ? {"\n\n"}
              </Text>
              Pour utiliser sa récompense, l’utilisateur devra se rendre dans le
              magasin du partenaire et lui présenter sa récompense (cadeau,
              remise...) afin de valider celle-ci soit en scannant le qr code du
              commerçant, ou en lui remettant le code secret inscrit sur le
              coupon cadeau. {"\n\n"}
              <Text style={styles.title}>
                Quand utiliser sa récompense ? {"\n\n"}
              </Text>
              Lors de la réception de sa récompense, l’utilisateur reçoit une
              notification. Dans la notification apparaît les conditions de
              validation et la durée de la récompense.{"\n\n"}
            </Text>
          </View>
        )}

        <Arcordeon
          description="Donnée enregistrées"
          type="2"
          press={handlerInfo7}
        />
        {information7 === true && (
          <View style={styles.textContainer}>
            <Text style={styles.paragraph}>
              <Text style={styles.title}>
                Où sont stocker mes informations et mes données ?{"\n\n"}
              </Text>
              Vos données sont stockées sur un serveur sécurisé et le mot de
              passe de votre compte est crypté.{"\n\n"}
              <Text style={styles.title}>
                Quel est la politique de confidentialité des données KréoCarte
                {"\n\n"}
              </Text>
              Nous sommes soumis à la Directive Européenne sur la protection des
              données et à la sécurité de vos données et de votre vie privée. La
              transmission de données est également sécurisée et l’accès externe
              n’est possible qu’avec des connexions authentifiées et se déroule
              via https. Les mots de passe des comptes de KréoCarte sont cryptés et
              ne peuvent pas être lus par notre société. Nous n’acceptons
              aucunes autres informations de compte à part si vous nous demandez
              de l’aide, par exemple lorsque vous modifiez votre adresse mail de
              connexion.{"\n\n"}
            </Text>
          </View>
        )}

        <Arcordeon
          description="Cagnottage Point KréoCarte"
          type="2"
          press={handlerInfo8}
        />
        {information8 === true && (
          <View style={styles.textContainer}>
            <Text style={styles.paragraph}>
              <Text style={styles.title}>Comment cagnotte ?{"\n\n"}</Text>
              Vous cagnottez à tout moment, en faisant de nombreuses actions
              dans l’application. Référez-vous à la liste des actions à mener
              pour cagnotter dans la page « aide », puis « point KréoCarte ».{" "}
              {"\n\n"}
              <Text style={styles.title}>Qui peut cagnotter ? {"\n\n"}</Text>
              Tout les utilisateurs peuvent cagnotter et bénéficier des bons
              plans cagnotte.{"\n\n"}
              <Text style={styles.title}>
                Comment utiliser ma cagnotte ?{"\n\n"}
              </Text>
              Pour utiliser sa cagnotte, vous devez avoir assez de points KréoCarte
              pour débloquer un bon plan. Une fois que vous avez suffisamment de
              point, choisissez le bon plan qui vous intéresse et cliquez sur le
              bouton « collecter ce bon plan ».{"\n\n"}
            </Text>
          </View>
        )}

        <Arcordeon description="Général" type="2" press={handlerInfo9} />
        {information9 === true && (
          <View style={styles.textContainer}>
            <Text style={styles.paragraph}>
              <Text style={styles.title}>
                Pourquoi ma carte n’est pas acceptée ?{"\n\n"}
              </Text>
              Votre carte n’est pas accepté, car elle n’est pas référencée, ou
              géré par l’application KréoCarte. {"\n\n"}
              <Text style={styles.title}>
                Pourquoi ma carte ne peut pas être scanner ?{"\n\n"}
              </Text>
              Si vous rencontrez des difficultés à scanner votre carte,
              augmenter la luminosité de l’écran afin d’améliorer la lecture du
              scan. {"\n\n"}
              <Text style={styles.title}>
                Quels systèmes d’exploitation utilisable pour KréoCarte ?{"\n\n"}
              </Text>
              KréoCarte est utilisable sur les deux principales plateformes IOS et
              Android.{"\n\n"}
              <Text style={styles.title}>
                Quelle langue est disponible ?{"\n\n"}
              </Text>
              KréoCarte se présente sur spécialement en français.{"\n\n"}
              <Text style={styles.title}>
                Dois-je avoir besoin d’une connexion internet ?{"\n\n"}
              </Text>
              Pour pouvoir utiliser pleinement de l’application KréoCarte une
              connexion internet est obligatoire.{"\n\n"}
              <Text style={styles.title}>
                Comment désactiver les notifications ?{"\n\n"}
              </Text>
              Pour désactiver les notifications sur son mobile, aller dans la
              page paramètre et décocher le champ « notification ». {"\n\n"}
              <Text style={styles.title}>
                Comment désactiver les newsletters ?{"\n\n"}
              </Text>
              Pour désactiver les newsletters sur son mobile, aller dans la page
              paramètre et décocher le champ « newsletter ». {"\n\n"}
              <Text style={styles.title}>
                Comment désactiver les sms ?{"\n\n"}
              </Text>
              Pour désactiver les sms sur son mobile, aller dans la page
              paramètre et décocher le champ « sms ».{"\n\n"}
              <Text style={styles.title}>
                Existe-t-il une version Pc ?{"\n\n"}
              </Text>
              Non, aucune version Pc n’est disponible présentement.{"\n\n"}
              <Text style={styles.title}>
                Dois-je m’inscrire pour pouvoir utiliser KréoCarte ?{"\n\n"}
              </Text>
              Il est impératif de s’inscrire pour pouvoir utiliser pleinement
              l’application.{"\n\n"}
            </Text>
          </View>
        )}

        <Arcordeon
          description="Adhérer au Réseau"
          type="2"
          press={handlerInfo10}
        />
        {information10 === true && (
          <View style={styles.textContainer}>
            <Text style={styles.paragraph}>
              <Text style={styles.title}>
                Comment intégrer mon entreprise au réseau ?{"\n\n"}
              </Text>
              Go Nord by KréoCarte est disponible pour tout type de commerces. Que
              vous soyez une boutique de prêt-à-porter, de restauration rapide,
              dans l'univers de la beauté et Bien-être, de l'hôtellerie ou un
              artisan, Go Nord by KréoCarte s'adapte à votre clientèle. {"\n\n"}
              Pour en savoir plus, n’hésitez pas à consulter notre site internet{" "}
              <Text
                style={[styles.title, { textDecorationLine: "underline" }]}
                onPress={() =>
                  Linking.openURL(
                    "https://gonordmartinique.fr/qui-sommes-nous/ "
                  )
                }
              >
                https://gonordmartinique.fr/qui-sommes-nous/
              </Text>
              , contactez-nous soit par mail sur gonordmartinique@mediafid.fr ou
              par téléphone au 0696045318. {"\n\n"}
            </Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
};

export default FaqsScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    marginHorizontal: 16,
    alignItems: "center",
    height: "100%",
    alignContent: "center",
    paddingTop: 30,
  },
  textContainer: {
    width:'92%'
  },
  title: {
    fontFamily: "MontserratMedium",
    fontSize: 14,
    color: "#174B9D",
    flexDirection: "row",
    textAlign: "left",
    width: "100%",
  },
  paragraph: {
    fontFamily: "MontserratRegular",
    fontSize: 14,
    color: "#7D7D7D",
    marginBottom: 19,
  },
});
