import React, { useState } from 'react';
import {Text,View, TextInput,  TouchableOpacity, StyleSheet, Image, Alert} from 'react-native';
import * as Yup from 'yup';
import { Formik } from 'formik';
import { authInputInsc, defaultAuthForm } from '../themes/authPages';
import { ScrollView } from 'react-native';
import { authBackground } from '../themes/authPages';
import BackArrowIcon from '../assets/icons/backArrow.svg';
import { moderateScale, moderateVerticalScale } from 'react-native-size-matters';
import { requestResetPassword } from '../api/user';
import { useMutation,useQueryClient } from "react-query";


const EmailPasswordScreen = ({navigation}) => {
    const [visible , setVisible] = useState(false);

    const inputValidationSchema = Yup.object().shape({
        email: Yup.string()
          .email("Merci d’entrer une adresse e-mail valable")
          .required('Adresse e-mail est nécessaire')
      })

    const { mutate , isLoading , isError } = useMutation('requestResetPassword',requestResetPassword,{
        onSuccess: async data => {
            setVisible(true)
        },
        onError: error =>{
            console.log(error.error)
            if(error.message === 'Request failed with status code 400'){
                Alert.alert('E-mail invalide ou vous avez déjà demandé un e-mail de réinitialisation du mot de passe.')
            }
        }
    })
    const handlerOk = async () =>{
        navigation.navigate("HomeScreen")
    }


    const requestHandler = async (email) =>{
          mutate({
              email
          })
      }
        return(
            
            <ScrollView style={{backgroundColor:'white'}}>

           
            <View style={{height:"100%", alignContent:"center"}}>
     
                <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginStart: 17, marginTop:moderateVerticalScale(40) }} >
                    <BackArrowIcon />
                </TouchableOpacity>

                
                 <View style={{alignItems: 'center', paddingTop:moderateVerticalScale(20)}}>
                     <Image source={require('../assets/gofid_logo_2.png')} style={authBackground.logo_background2} />
                </View>

                <View style={{marginTop:moderateVerticalScale(40), marginBottom: moderateVerticalScale(25)}}>
                    <Text style={authInputInsc.title}>
                    Entrez votre Email
                    </Text>
                </View>


        <Formik
            initialValues={{ email: "", password: "" }}
            onSubmit={(values) => {
              requestHandler(values.email);
            }}
            validationSchema={inputValidationSchema}
          >
            {({ handleChange, handleBlur, handleSubmit, values, errors }) => (
              <>
                <View style={authInputInsc.label}>
                     <Text style={authInputInsc.labelTxt} 
                            > Email
                     </Text>
                </View>
                <View style={ authInputInsc.inputContainer }>
                    <TextInput 
                        type="text"
                        style={authInputInsc.inputTxt}
                        placeholder = "votre@mail.com"
                        placeholderTextColor="#174B9D"
                        name="email"
                        onChangeText={handleChange("email")}
                        onBlur={handleBlur("email")}
                        value={values.email}
                    />
                </View>
                {errors.email && (
                  <Text style={{ fontSize: 10, color: "red", marginLeft: 16 }}>
                    {errors.email}
                  </Text>
                )}


               

                {!visible &&
                    <View  style={ styles.buttonContainer}>
                        <TouchableOpacity style={authInputInsc.authButton} onPress={handleSubmit}>
                            <Text style={isLoading? authInputInsc.authButtTextDisabled : authInputInsc.authButtText}>
                                Envoyer</Text>
                        </TouchableOpacity>
                    </View>
                }
                
                {visible === true &&
                     <View>
                            <View style={ styles.alertContainer } >
                                <Text style={styles.alertTxt}>
                                    Nous vous avons envoyé un lien pour changer le mot de passe sur votre mail
                                </Text>
                            </View>
                            <View  style={ styles.buttonContainerAlert}>
                                <TouchableOpacity style={authInputInsc.authButtonOK} onPress={handlerOk}>
                                    <Text style={authInputInsc.authButtText}>OK</Text>
                                </TouchableOpacity>
                            </View>
                    </View>
                }
                
                </>
            )}
          </Formik>
            </View >
           
            </ScrollView>
        )
    

}


export default EmailPasswordScreen;

const styles = StyleSheet.create({
    buttonContainer:{
        alignItems:"center",
        justifyContent:"flex-end",
        flex: 1,
        marginTop: moderateVerticalScale(300),
        marginBottom: 50
    },
    buttonContainerAlert:{
        alignItems:"center",
        justifyContent:"flex-end",
        flex: 1,
        marginTop: moderateVerticalScale(85),
        marginBottom: 50,
    },
    alertContainer:{
        width:'100%',
        height:moderateVerticalScale(65),
        backgroundColor: "#4DBDF2",
        marginTop: moderateVerticalScale(150),
        justifyContent:'center'
    },
    alertTxt:{
        marginHorizontal: moderateScale(16),
        color:'#FFFFFF',
        fontSize:18,
        fontFamily:'MontserratRegular',
        textAlign:'center'
    }
    
})

