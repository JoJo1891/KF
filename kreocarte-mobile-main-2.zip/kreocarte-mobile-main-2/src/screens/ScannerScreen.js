import React, { useState, useEffect } from 'react';

import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { CameraView, Camera } from 'expo-camera';
import {
  moderateScale,
  moderateVerticalScale,
} from 'react-native-size-matters';
import { useMutation, useQueryClient } from 'react-query';

import {
  BonusPlanModal,
  Loader,
  ModalComponent,
  SimpleHeaderComponent,
} from '../components';
import ScannerIcon from '../assets/icons/scan_qr_serial_icon.svg';
import { qrAddPoints } from '../api/card';

import Selector from '../assets/icons/selector_guide.svg';
import { schedulePushNotification } from '../state/ExpoPushToken';
import { selectUser } from '../state/auth';
import { useSelector } from 'react-redux';
import { saveNotification } from '../api/notifications';

const ScannerScreen = ({ navigation }) => {
  const [hasPermission, setHasPermission] = useState(null);
  const [scanned, setScanned] = useState(false);
  const [gift, setGift] = useState({});
  const [modalVisible, setModalVisible] = useState(false);
  const queryClient = useQueryClient();
  const [cardIdScanned, setId] = useState(0);
  const user = useSelector(selectUser);

  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, []);

  const saveNotificationdMutation = useMutation(saveNotification, {
    onSuccess: (response) => {
      //console.log(response)
    },
    onError: (error) => {
      console.log(error);
    },
    onSettled: () => {
      queryClient.invalidateQueries('saveNotification');
    },
  });

  const { mutate, isLoading } = useMutation('qrAddPoints', qrAddPoints, {
    onSuccess: (datas) => {
      console.log(datas);
      setId(datas.card_id);

      //verify if there is only one point to win a reward
      let result = datas.treshold - datas.point_fidelite;
      if (result == 1 && datas.type_carte != 'CASHBACK') {
        schedulePushNotification(
          'Gofid',
          `${user.prenom}, il ne te reste qu'un point pour débloquer ta récompense.`,
          'ONE_POINT',
          datas.card_id
        );
        saveNotificationdMutation.mutate({
          message: `${user.prenom}, il ne te reste qu'un point pour débloquer ta récompense.`,
          type: 'ONE_POINT',
          card_id: datas.card_id,
        });
      }

      //verify if there is any error, ex: scan after x minutes
      if (datas.error) {
        Alert.alert(datas.error);
      } else {
        if (datas.isNewGift && datas.type_carte != 'CASHBACK') {
          setGift(datas.gift);
          setModalVisible(true);
          navigation.navigate('CardScreen', {
            id: datas.card_id,
          });
        } else {
          navigation.navigate('CardScreen', {
            id: datas.card_id,
          });
        }
      }
    },
    onError: (error) => {
      navigation.navigate('ScannerScreenError');
    },
  });

  const apiHandler = (code) => {
    mutate({
      code,
    });
  };

  const handlerSuccess = () => {
    navigation.navigate('HomeScreen');
  };

  const handleBarCodeScanned = ({ type, data }) => {
    //console.log(data + " "+type)
    setScanned(true);
    //console.log(data)

    //When is adding points
    //Scanning points
    if (data.startsWith('[{"id":') || data.startsWith('[{"qrcode":')) {
      let arr = JSON.parse(data);
      let id;
      if (data.startsWith('[{"qrcode":')) {
        id = arr[0].qrcode;
      } else if (data.startsWith('[{"id":')) {
        id = arr[0].id;
      }

      if (id) {
        apiHandler(id);
      } else {
        alert('Error: no id in the QrCode');
      }
    } else if (data) {
      //if it is a number only then... (Add a card manual)
      navigation.navigate('ManualCardScreen', {
        id: data,
      });
    } else {
      //Error
      navigation.navigate('ScannerScreenError');
    }
    // else if(data.startsWith('https://dev.mediafid.fr/api/v3/cadeaux/')){    //if it is using the bon plan...
    //   var regex = /(\d+)/g;
    //   let id = data.match(regex)[1];
    //   useBonPlanMutation.mutate(id)
    // }
  };

  if (hasPermission === null) {
    return (
      <View style={styles.previewScreen}>
        <Text>Requesting for camera permission</Text>
      </View>
    );
  }

  if (hasPermission === false) {
    Alert.alert(
      'Accès Refusé',
      "L'application KreoCarte doit accéder à votre appareil photo pour que vous puissiez scanner le code Qr.",
      [
        {
          text: 'Ok',
          onPress: () => handlerSuccess(),
        },
      ]
    );
  }

  return (
    <View style={styles.screenContainer}>
      <ModalComponent modalVisible={modalVisible}>
        <BonusPlanModal
          data={gift}
          card_id={cardIdScanned}
          onClose={() => {
            setModalVisible(!modalVisible);
          }}
        />
      </ModalComponent>
      <CameraView
        onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
        style={StyleSheet.absoluteFillObject}
      />
      <View style={styles.contentContainer}>
        <View style={styles.headerContainer}>
          <SimpleHeaderComponent tintColor="white" title="Scan carte" />
        </View>

        <View style={styles.selectorContainer}>
          {isLoading ? (
            <>
              <Loader />
            </>
          ) : (
            <Selector />
          )}
        </View>

        <TouchableOpacity
          onPress={() => setScanned(false)}
          style={styles.scannerButton}
        >
          <ScannerIcon />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ScannerScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
  },
  contentContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'space-between',
  },
  previewScreen: {
    flex: 1,
    justifyContent: 'center',
    alignContent: 'center',
  },
  headerContainer: {},
  scannerButton: {
    backgroundColor: '#174B9D',
    padding: 15,
    width: moderateScale(70),
    height: moderateVerticalScale(70),
    borderRadius: moderateScale(70),
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    marginBottom: moderateVerticalScale(100),
  },
  selectorContainer: {
    alignContent: 'center',
    alignItems: 'center',
  },
});
