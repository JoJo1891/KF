import React from 'react';
import {Text,View,StyleSheet} from 'react-native';
import { ScrollView } from 'react-native';



import { SimpleHeaderComponent } from '../components';


const CguScreen = () => {

   
        return(
        <ScrollView style={{backgroundColor:'white',paddingTop: 20,}}>
                <SimpleHeaderComponent title="CGU" />
            <View style={styles.screenContainer}>
            

           <Text style={styles.title}>
                Condition Général d’Utilisation 
           </Text>

     {/* 1 -------------------------------------------------------------------------------!!!! */}

           <Text style={styles.titles}>
                 1. Conditions d'utilisation et politique de confidentialité
           </Text>

    
           <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"1.1 "}
                    </Text>
                        L'installation et l'utilisation de « KréoCarte » impliquent le consentement de l'utilisateur aux conditions d'utilisation, selon le cas, et modifiées de temps à autre. Les termes et conditions générales des utilisateurs ne sont pas efficaces en relation avec MEDIAFID.
                </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"1.2 "}
                    </Text>
                          Avec l'installation de l'application ou l'utilisation de services de « KréoCarte », les conditions d'utilisation entrent en vigueur. Les termes d'utilisation sont fondés pour une période de temps infinie et sont terminables avec un préavis de deux semaines.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"1.3 "}
                    </Text>
                         MEDIAFID a le droit d'annuler la relation juridique avec effet immédiat pour cause matérielle ou si l'utilisateur enfreint les conditions d'utilisation ou la loi applicable.        
                 </Text>
            </View>

    {/* 2 -------------------------------------------------------------------------------!!!! */}    

            <Text style={styles.titles}>
                2. Utilisation de l'application « KréoCarte  »
            </Text>

            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"2.1 "}
                    </Text>
                    L'application mobile « KréoCarte » permet aux utilisateurs de créer et d'enregistrer leurs cartes de fidélitésur les smartphones et de les utiliser pour l'identification numérique. En outre, un utilisateur peut être informédes offres actuelles et des coupons de porte-cartes de fidélité et des offres actuelles des entreprises partenaires.
                </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"2.2 "}
                    </Text>
                    Pour profiter de KréoCarte , les utilisateurs doivent installer l'application sur leur smartphone créer et enregistrer leurs cartes de fidélité avec les données requises. Même l'entrée d'une carte de fidélité ou d'un numéro de carte spécifique est suffisante pour la créer. Pour compléter l'inscription, l'utilisateur doit remplir le formulaire d’inscription. {"\n\n"}MEDIAFID se réserve le droit, à son entière discrétion, de rejeter les utilisateurs en raison de la saisie d'adresses non valides ou d'autres causes.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"2.3 "}
                    </Text>
                    MEDIAFID offre gratuitement l'application aux utilisateurs. Il est possible que les fournisseurs d’accès internet prélèvent des frais pour le transfert de données en cas de dépassement de leur forfait dans le cadre de l'utilisation de l’application mobile. Ces coûts doivent être supportés par l'utilisateur.
                 </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"2.4 "}
                    </Text>
                    MEDIAFID accorde à l'utilisateur un droit limité, non exclusif, non transférable, d'utiliser cette application (KréoCarte ) dans la dernière version, y compris les mises à jour et autres fonctionnalités soumises aux présentes conditions d'utilisation. Le droit d'utilisation prend fin à la fin de la relation juridique.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"2.5 "}
                    </Text>
                    L'utilisateur n'a pas le droit de modifier, de copier, de démonter, de remonter, de distribuer, de publier, D'ingénierie inverse, de construire un dérivé ou de dupliquer l'application, ses composants, ses services ou ses fonctionnalités. L'utilisateur est autorisé à utiliser KréoCarte  uniquement pour son propre bénéfice et n'est pasautorisé à mettre l'application à la disposition de tiers. L'utilisation de l’application mobile à des fins commerciales est interdite.
                 </Text>
            </View>

    {/* 3 -------------------------------------------------------------------------------!!!! */}    

            <Text style={styles.titles}>
                  3. Responsabilité
            </Text>

            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"3.1 "}
                    </Text>
                    MEDIAFID décline toute responsabilité pour tout dommage (dommages matériels ou immatériels et perte de profit) causé par l'utilisation ou la dépendance des informations fournies par l’application mobile ou causées par des informations inexactes ou incomplètes, à moins que l'utilisateur ne subisse des dommages directement et manifestement attribuables à la Négligence grave ou défaut délibéré de MEDIAFID.
                </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"3.2 "}
                    </Text>
                    Toutes les offres, coupons, services,...., de KréoCarte  ne sont pas contraignantes. MEDIAFID ne garantit pas l'adéquation de l'application et ses services, sa qualité marchande, son aptitude à un usage particulier, ou que les exigences ou attentes particulières de l'utilisateur seront remplies.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"3.3 "}
                    </Text>
                    MEDIAFID ne garantit aucune garantie et n'assume aucune responsabilité pour le contenu lié ou externe au sens de la section 4 de ces termes. Sauf dans les cas prévus par la loi applicable, la responsabilité de ce contenu est exclue dans toute la mesure du possible.
                 </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"3.4 "}
                    </Text>
                    MEDIAFID décline toute responsabilité et ne peut être tenu pour responsable de la duplication ou de l'utilisation non autorisée de coupons, d'offres ou d'autres contenus ou de graphiques, de textes préparés, de logos et de marques protégés par des droits de tiers.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"3.5 "}
                    </Text>
                    La limitation de responsabilité précitée ne s'applique pas aux dommages résultant de dommages corporels ou de décès ou lorsque la limitation est contraire à la loi applicable.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"3.6 "}
                    </Text>
                    L'utilisateur doit indemniser et protéger KréoCarte  des dommages causés par les tiers contre les coûts, les dommages ou les réclamations de tiers découlant de l'utilisation illégale de KréoCarte  ou de la violation par l'utilisateur de ces conditions de service.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"3.7 "}
                    </Text>
                    Une utilisation non autorisée conformément à l'article 3.6 est spécialement constituée par l'enregistrement par l'utilisateur de cartes de clients sous un faux nom, ce qui permet d'obtenir des avantages frauduleux de l'opérateur de carte concerné. Dans ce cas, c'est exclusivement l'utilisateur responsable de l'opérateur de carte. Dans le cas où MEDIAFID est endommagé par un tel comportement d'un utilisateur, l'utilisateur doit entièrement indemniser MEDIAFID et le tenir inoffensif.
               </Text>
            </View>


    {/* 4 -------------------------------------------------------------------------------!!!! */}    

            <Text style={styles.titles}>
                  4. Publicité
            </Text>

            <View >
                <Text style={styles.paragraph}>
                MEDIAFID permet à ses Partenaires et aux tiers de placer une publicité dans la demande. En s'inscrivant avec l’application mobile, l'utilisateur accepte expressément que la publicité, y compris le contenu personnalisé, puisse être envoyée à l'utilisateur. MEDIAFID déclare expressément que les Partenaires restent responsables des publicités placées en ce qui concerne le contenu et le type de placement, et MEDIAFID n'assume aucune responsabilité quant à la responsabilité. 
               </Text>
            </View>


   {/* 5 -------------------------------------------------------------------------------!!!! */}    

             <Text style={styles.titles}>
                 5. Confidentialité des Données Personnelles
            </Text>

            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"5.1 "}
                    </Text>
                    Après avoir complété l'inscription (Email et Mot de passe ou Facebook connect ou Gmail connect), l'utilisateur accepte que les données nécessaires pour faciliter l'utilisation de KréoCarte  soient stockées, informatisées et traitées. D'autres caractéristiques de KréoCarte  peuvent nécessiter des données personnelles supplémentaires “Nom, Prénom, date de naissance, sexe, code postal et numéro de téléphone. La saisie de ces données supplémentaires sera facultative. L'utilisation et la divulgation de ces données à un tiers seront assujetties aux exigences de confidentialité des données. KréoCarte  et MEDIAFID doivent être conformes à toutes les lois applicables en matière de protection des données privées.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"5.2 "}
                    </Text>
                    Certaines offres et informations ne seront traitées qu'avec le consentement de l'utilisateur. Un tel consentement, MEDIAFID est autorisé à transférer les données aux partenaires.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"5.3 "}
                    </Text>
                    L'utilisation de l'application est possible sans entrer de données personnelles. Si, dans l'ensemble, les données personnelles de nos sites (par exemple, nom, prénom, code postal ou la date de naissance) sont collectées, il sera facultatif dans la mesure du possible. D’autres données telles que (Date de création du compte, date de dernière connexion, Nombre de carte, Nombre de points collectés, Nombre de cadeau attribue) sont collectées pour améliorer au mieu l’expérience KréoCarte  et ses fonctionnalités. Ces données personnelles ne seront pas transférées à un tiers sans le consentement explicite de l'utilisateur. L’utilisateur pourra actionner son droit de regard, de modification, de téléchargement, de suppression de leurs données personnelles directement dans l’application. Ces données personnelles seront stockées tant que l'utilisateur utilise l’application. Dès la réception de la demande de suppression du compte de l’utilisateur, toutes les données utilisateur seront supprimées.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"5.4 "}
                    </Text>
                    L'utilisation de nos données de contact publiées dans le cadre de l'obligation d'impression d'un tiers pour l'envoi d'informations publicitaires et d'informations non expressément demandées par nous est strictement interdite. MEDIAFID se réserve le droit de prendre des mesures judiciaires dans le cas de la réception de publicité ou d'informations non sollicitées, par ex. Courriers indésirables.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"5.5 "}
                    </Text>
                    L'utilisateur reconnaît que les données décrites dans cette section 5 peuvent être collectées directement par KréoCarte , pour support de carte de fidélité.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"5.6 "}
                    </Text>
                    En s'inscrivant avec KréoCarte , l'utilisateur accepte et consent expressément à ce que les Partenaires puissent collecter des informations sur l'utilisateur et l'appareil mobile de l'utilisateur sur une base anonyme. {"\n\n"}Les fournisseurs de cartes utilisent ces données pour fournir des services basés sur la communication, tels que les publicités, les résultats de recherche et d'autres contenus personnalisés, à condition que cette fonction soit activée par l'utilisateur et son appareil.
               </Text>
            </View>


    {/* 5 -------------------------------------------------------------------------------!!!! */}    

            <Text style={styles.titles}>
                6. Application et amendements
            </Text>

            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"6.1 "}
                    </Text>
                    MEDIAFID se réserve le droit d'ajuster ces conditions d'utilisation à la nouvelle législation, à la technologie, aux services ou à les modifier pour d'autres raisons. Si, en raison de modifications des termes d'utilisation, les intérêts des utilisateurs pourraient être compromis, les utilisateurs recevront un préavis de deux semaines selon la méthode de contact indiquée lors de l'inscription (courrier électronique). Au bout de deux semaines, l'utilisation de KréoCarte  et de ses services sera assujettie aux conditions d'utilisation modifiées. {"\n\n"}Si un utilisateur n'est pas d'accord avec les modifications, il doit cesser immédiatement d'utiliser l’application mobile. {"\n\n"}Dans ce cas, MEDIAFID est autorisé à suspendre le compte de l'utilisateur. Si KréoCarte  est encore utilisée après une période de deux semaines après la publication des modifications, cela sera considéré comme l'approbation implicite des termes d'utilisation modifiés.
               </Text>
            </View>
            <View >
                <Text style={styles.paragraph}>
                    <Text style={styles.subindex}>
                            {"6.2 "}
                    </Text>
                    Sauf disposition contraire de la loi obligatoire, les présentes conditions d'utilisation sont interprétées conformément à la loi européenne.
               </Text>
            </View>


            </View>
            </ScrollView>
        )
    

}


export default CguScreen;

const styles = StyleSheet.create({
    screenContainer: {
        flex: 1,
        marginHorizontal: 16,
        height:"100%", 
      },
      title:{
        textAlign: 'left',  
        fontFamily: 'MontserratSemiBold',
        fontSize: 16,
        color: '#174B9D',
        marginBottom: 19,
        paddingTop:40
      },
      titles:{
        textAlign: 'left',  
        fontFamily: 'MontserratSemiBold',
        fontSize: 16,
        color: '#174B9D',
        marginBottom: 19
      },
      paragraph: {
          fontFamily: 'MontserratLight',
          fontSize: 16,
          color: '#858585',
          marginBottom:19

      },
      subindex: {
        fontFamily: 'MontserratMedium',
        fontSize: 16,
        color: '#343434',

    }
    })