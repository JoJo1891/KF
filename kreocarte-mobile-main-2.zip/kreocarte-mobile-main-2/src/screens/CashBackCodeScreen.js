import React,{useState} from 'react';

import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    Image,
    Alert,
    TouchableOpacity
} from 'react-native';

import {GradientComponent,SimpleHeaderComponent,CustomButtonComponent,ModalComponent,ConfirmationModal, Loader} from '../components';
import { windowHeight } from '../themes';
import CashBackIcon from '../assets/icons/cashback_big_white.svg';
import RefreshIcon from '../assets/icons/refresh2.svg';
import { moderateVerticalScale, moderateScale } from 'react-native-size-matters';
import Barcode from "react-native-barcode-builder";
import { cancelCashBackCode, getCashBackById } from '../api/card';
import { useMutation, useQueryClient } from 'react-query';
import { authInputInsc } from '../themes/authPages';
import { useDispatch, useSelector } from 'react-redux';
import { selectCashBackUsed, setCashBackUsed } from '../state/notificationsReceived';
import AnimationSuccess from '../components/partials/AnimationSuccess';

const CashBackCodeScreen = ({navigation,route}) =>{

    const { id , cardId,urlCode,code,recompense } = route?.params

    const notificationReceived = useSelector(selectCashBackUsed);
    const dispatch = useDispatch()
    const [modalVisible, setModalVisible] = useState(false);
    const queryClient = useQueryClient();

    const handlerSuccess = () => {
        setModalVisible(!modalVisible)
        navigation.pop(2)
    }

    const { mutate, isLoading } = useMutation(cancelCashBackCode,{
        onSuccess : data =>{ 
            Alert.alert("Cashback","Cashback annulé",[
                {
                  text: "Ok",
                  onPress: () => handlerSuccess()
                },
              ]) 
        },
        onError : error => {
            if(error.message === 'Request failed with status code 400'){
                Alert.alert("Error","Vous n'êtes pas autorisé à annuler ce cashback, il a peut-être déjà été utilisé.",[
                    {
                    text: "Ok",
                    onPress: () => setModalVisible(!modalVisible)
                    },
                ])
            }else{
                Alert.alert("Error","Quelque chose s'est mal passé",[
                    {
                    text: "Ok",
                    onPress: () => setModalVisible(!modalVisible)
                    },
                ])
            }
        },
        onSettled : ()=>{
          queryClient.invalidateQueries('cancelCashBackCode')
        }
      });


    const handlerOk = async () => {
        dispatch(setCashBackUsed(false));
        navigation.navigate("Home");
    }
    const handlerOui = async () => {
        mutate({id});
    }


    return (<View style={styles.screenContainer}>
        <ModalComponent modalVisible={modalVisible}>
            <ConfirmationModal 
                            isLoading={isLoading}
                            value='Êtes vous sûr de vouloir annuler votre opération ?' 
                            onCancel={()=>setModalVisible(!modalVisible)} 
                            onSubmit={()=>handlerOui()}
            />
        </ModalComponent>
        <ScrollView >
        {notificationReceived ? (
          <TouchableOpacity onPress={()=>handlerOk()}>
            <AnimationSuccess message="Vous venez d'utiliser votre cashback !"  />
          </TouchableOpacity>
        ) :(
        <>
        <View style={styles.blueBackground}>
            <GradientComponent colors={['#0697DC','#174B9D']} style={styles.gradient}/>
        </View>
        <View style={styles.contentContainer}>
            
                <View>
                    <SimpleHeaderComponent title="Cashback code" tintColor='white' notArrow={true}/>
                </View>
                <View style={styles.cashBackIconContainer}>
                    <CashBackIcon width={moderateScale(60)} height={moderateVerticalScale(60)} />
                </View>
                <Text style={[styles.textSemiBold,styles.title]}>Cashback valable</Text>
                <Text style={[styles.textSemiBold,styles.amount]}> {recompense}€</Text>
               
                <View style={styles.barCodeContainer}>
                    {/* <Barcode value={code.toString()} format={format}/> */}
                    <Image
                        style={styles.image}
                        source={{
                            uri: urlCode,
                          }}
                         
                        />
                    <Text style={styles.code}>
                        {code}
                    </Text>  
                </View>
                <Text style={[styles.textRegular,styles.conditions]}>Transmettez votre code de sécurité à votre commerçant afin de valider l’opération.</Text>        
        </View>
        <View style={styles.buttonContainer}>
            <CustomButtonComponent type="round-secondary" value="Annuler" onPress={()=>setModalVisible(!modalVisible)}/>
        </View> 
        </>)}
        </ScrollView>
    </View>)
}

export default CashBackCodeScreen;

const styles = StyleSheet.create({
    screenContainer :{
        flex :  1,
        backgroundColor : 'white',
    },
    blueBackground : {
        height : windowHeight/moderateVerticalScale(1.19),
        borderBottomRightRadius : 46,
        borderBottomLeftRadius : 46,
        overflow : 'hidden'
    },
    gradient : {
        flex : 1
    },
    contentContainer: {
        position: "absolute",
        top: 0,
        left: 0,
        right : 0,
        bottom: 0,
    },
    cashBackIconContainer : {
        marginTop : moderateVerticalScale(30),
        alignItems : 'center'
    },
    textSemiBold :{
        fontFamily : 'MontserratSemiBold'
    },
    textRegular : {
        fontFamily : 'MontserratRegular',
    },
    barCodeContainer : {
        padding : 15,
        paddingBottom: 10,
        marginTop: moderateVerticalScale(10),
        backgroundColor : 'white',
        marginHorizontal : moderateScale(50),
        borderRadius : 15,
        alignItems: 'center',
        overflow: "hidden",
    },
    title :{
        fontSize : moderateScale(22),
        textAlign : 'center',
        color : 'white',
        marginTop : moderateVerticalScale(10)
    },
    amount : {
        fontSize : moderateScale(60),
        textAlign : 'center',
        color : 'white',
    },
    conditions :{
        color : 'white',
        textAlign : 'center',
        fontSize : moderateScale(12),
        marginTop : moderateVerticalScale(15),
        marginHorizontal : moderateScale(16)
    },
    code:{
        color:'black',
        fontSize: 25,
        fontFamily : 'MontserratMedium',
        textAlign: 'center'
    },
    buttonContainer : {
        marginTop : moderateVerticalScale(50),
        marginHorizontal : moderateScale(16),
        marginBottom: 50,
    },
    image:{
        height: moderateVerticalScale(150) ,
        width:moderateScale(150),
        marginBottom:moderateVerticalScale(5)
    },
    buttonContainerAlert:{
        alignItems:"center",
        justifyContent:"flex-end",
        flex: 1,
        marginTop: moderateVerticalScale(25),
        marginBottom: 70,
    },
    buttonOK:{
        alignSelf: 'stretch',
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 25,
        flexDirection: 'row',
        marginHorizontal: moderateScale(16),
        backgroundColor: '#5ED96A',
    },
    alertContainer:{
        width:'100%',
        height:moderateVerticalScale(65),
        backgroundColor: "#5ED96A",
        marginTop: moderateVerticalScale(25),
        justifyContent:'center'
    },
    alertTxt:{
        marginHorizontal: moderateScale(16),
        color:'#FFFFFF',
        fontSize:18,
        fontFamily:'MontserratRegular',
        textAlign:'center'
    }

});