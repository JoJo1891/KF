import React, { useState, useEffect } from "react";
import {
  Text,
  View,
  Alert,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  ScrollView,
} from "react-native";
import { useMutation, useQueryClient } from "react-query";
import { useDispatch, useSelector } from "react-redux";
import { updateUser } from "../api/user";
import { selectUser, editUser } from "../state/auth";

import { SimpleHeaderComponent } from "../components";
import Avatar1 from "../assets/icons/avatar_1M.svg";
import Avatar2 from "../assets/icons/avatar_2M.svg";
import CalendarIcon from "../assets/icons/calendar.svg";
import GofidButton from "../components/partials/GofidButton";
import * as Yup from "yup";
import dayjs from "dayjs";
import "dayjs/locale/fr";
import { Formik, yupToFormErrors } from "formik";
import DateTimePicker from "@react-native-community/datetimepicker";
import { moderateScale } from "react-native-size-matters";
import SelectDropdown from "react-native-select-dropdown";
import Drop from "../assets/icons/drop.svg";

const ProfileScreen = () => {
  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const user = useSelector(selectUser);
  const [showCalendar, setShow] = useState(false);

  const sexe = [
    {
      name: "Femme",
      value: "femme",
    },
    { name: "Homme", value: "homme" },
  ];

  const [dateUser, setDateUser] = useState(
    dayjs(user?.datenaissance ? user.datenaissance : new Date())
      .add(12, "h")
      .toDate()
  );

  const updateUserValidationSchema = Yup.object().shape({
    prenom: Yup.string(),
    nom: Yup.string(),
    sexe: Yup.string(),
    datenaissance: Yup.date(),
    codepostal: Yup.string().matches("^[0-9]*$", {
      message: "seulement les chiffres",
    }),
    telephone: Yup.string().matches("^[0-9]*$", {
      message: "seulement les chiffres",
    }),
  });

  const { mutate, isLoading, isError } = useMutation(updateUser, {
    onSuccess: (response) => {
      dispatch(editUser(response));
      Alert.alert("Succès", "Opération réussie !");
    },
    onError: (error) => {
      console.log(error);
      Alert.alert(
        "Error",
        "Une erreur s'est produite lors de la tentative de mise à jour de l'utilisateur"
      );
    },
    onSettled: () => {
      queryClient.invalidateQueries("updateUser");
    },
  });

  function returnImg() {
    if (user?.sexe === "femme") {
      return <Avatar1 />;
    } else {
      return <Avatar2 />;
    }
  }

  const pickerStyle = {
    inputIOS: {
      fontSize: 14,
      fontFamily: "MontserratMedium",
      textAlign: "left",
      color: "#174B9D",
      height: moderateScale(40),
      paddingHorizontal: 10,
      width: moderateScale(330),
    },
    inputAndroid: {
      fontSize: 14,
      fontFamily: "MontserratMedium",
      textAlign: "left",
      color: "#174B9D",
      height: moderateScale(20),
      width: moderateScale(340),
      paddingBottom: moderateScale(60),
    },
  };

  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <SimpleHeaderComponent title="Profil" />
      <View style={styles.screenContainer}>
        <View style={styles.userBorder}>
          <View
            style={{
              width: "30%",
              alignContent: "center",
              alignItems: "center",
            }}
          >
            {returnImg()}
          </View>
          <View style={{ width: "70%" }}>
            <Text style={styles.userName}>
              {user.prenom || ""} {user.nom || ""}
            </Text>
            <Text style={styles.date}>
              {"Inscrit depuis le " +
                dayjs(
                  user?.inscription_date?.date
                    ? user.inscription_date.date
                    : user?.inscription_date
                )
                  .locale("fr")
                  .format("DD MMMM YYYY")}
            </Text>
          </View>
        </View>
        <Formik
          initialValues={{
            prenom: user.prenom || "",
            nom: user.nom || "",
            sexe: user.sexe || "",
            codepostal: user.codepostal || "",
            datenaissance: user.datenaissance
              ? dayjs(user.datenaissance).add(12, "h").toDate()
              : new Date(),
            telephone: user.telephone ? user.telephone : "",
          }}
          onSubmit={(values) => {
            mutate(values);
          }}
          validationSchema={updateUserValidationSchema}
        >
          {({
            handleChange,
            setFieldValue,
            handleBlur,
            handleSubmit,
            values,
            errors,
          }) => (
            <>
              <View style={styles.label}>
                <Text style={styles.labelTxt}> Prénom</Text>
              </View>
              <View style={styles.inputContainer}>
                <TextInput
                  type="text"
                  style={styles.inputTxt}
                  placeholder={user.prenom || ""}
                  onChangeText={handleChange("prenom")}
                  onBlur={handleBlur("prenom")}
                  placeholderTextColor="#174B9D"
                />
              </View>

              <View style={styles.label}>
                <Text style={styles.labelTxt}> Nom</Text>
              </View>
              <View style={styles.inputContainer}>
                <TextInput
                  type="text"
                  style={styles.inputTxt}
                  placeholder={user.nom || ""}
                  onChangeText={handleChange("nom")}
                  onBlur={handleBlur("nom")}
                  placeholderTextColor="#174B9D"
                />
              </View>

              <View style={styles.label}>
                <Text style={styles.labelTxt}> moi</Text>
              </View>
              <View style={styles.inputContainer2}>
                <View
                  style={{
                    justifyContent: "center",
                    width: "100%",
                    display: "flex",
                    flexDirection: "row",
                    height: "100%",
                  }}
                >
                  <SelectDropdown
                    data={sexe}
                    buttonStyle={styles.buttonStyle}
                    buttonTextStyle={styles.buttonTextStyle}
                    rowTextStyle={{ color: "#174B9D" }}
                    defaultButtonText={user.sexe || "Sélectionnez le sexe"}
                    dropdownStyle={{ backgroundColor: "white" }}
                    onSelect={(selectedItem, index) => {
                      handleChange("sexe");
                    }}
                    buttonTextAfterSelection={(selectedItem, index) => {
                      return (values.sexe = selectedItem.value);
                    }}
                    rowTextForSelection={(item, index) => {
                      return (values.sexe = item.value);
                    }}
                  />
                  <Drop style={styles.dropStyle} />
                </View>
              </View>

              <View style={styles.label}>
                <Text style={styles.labelTxt}>Date de naissance</Text>
              </View>

              <TouchableOpacity
                onPress={() => setShow(!showCalendar)}
                style={styles.inputContainer}
              >
                <View
                  style={{
                    display: "flex",
                    width: "100%",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Text style={styles.inputDate}>
                    {dayjs(dateUser).locale("fr").format("DD MMMM YYYY") || ""}
                  </Text>
                  <View style={styles.icon}>
                    <CalendarIcon />
                  </View>
                </View>
              </TouchableOpacity>

              {showCalendar && (
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "stretch",
                    marginTop: 15,
                    height: 50,
                    width: "100%",
                    alignItems: "center",
                    justifyContent: "flex-start",
                  }}
                >
                  <View>
                    <Text
                      style={{
                        fontSize: 14,
                        fontFamily: "MontserratMedium",
                        textAlign: "left",
                        color: "#174B9D",
                        paddingHorizontal: 10,
                      }}
                    >
                      Touchez ici pour changer la date:
                    </Text>
                  </View>
                  <View
                    style={{
                      flex: 1,
                      alignItems: "stretch",
                      marginLeft: moderateScale(5),
                      marginRight: moderateScale(20),
                    }}
                  >
                    <DateTimePicker
                      testID="dateTimePicker"
                      mode="date"
                      value={dateUser}
                      maximumDate={new Date()}
                      style={{ flex: 1 }}
                      display="default"
                      locale="fr-FR"
                      onChange={(event, selectedDate) => {
                        setShow(!showCalendar);
                        setDateUser(new Date(selectedDate));
                        setFieldValue("datenaissance", new Date(selectedDate));
                      }}
                    />
                  </View>
                </View>
              )}

              <View style={styles.label}>
                <Text style={styles.labelTxt}> Code postal</Text>
              </View>
              <View style={styles.inputContainer}>
                <TextInput
                  keyboardType="numeric"
                  style={styles.inputTxt}
                  onChangeText={handleChange("codepostal")}
                  onBlur={handleBlur("codepostal")}
                  placeholder={user.codepostal || ""}
                  placeholderTextColor="#174B9D"
                />
              </View>

              <View style={styles.label}>
                <Text style={styles.labelTxt}> Téléphone</Text>
              </View>
              <View style={styles.inputContainer}>
                <TextInput
                  keyboardType="numeric"
                  style={styles.inputTxt}
                  onChangeText={handleChange("telephone")}
                  onBlur={handleBlur("telephone")}
                  placeholder={user.telephone || ""}
                  placeholderTextColor="#174B9D"
                />
              </View>

              <View style={{ marginTop: 80, marginBottom: 50 }}>
                <GofidButton
                  disabled={isLoading}
                  press={handleSubmit}
                  name="blue"
                  value="Enregistrer"
                />
              </View>
            </>
          )}
        </Formik>
      </View>
    </ScrollView>
  );
};

export default ProfileScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    marginHorizontal: 16,
    height: "100%",
    alignContent: "center",
  },
  userBorder: {
    alignItems: "center",
    flexDirection: "row",
    paddingTop: 26,
    width: "100%",
    marginBottom: 23,
  },
  userName: {
    fontFamily: "MontserratBold",
    fontSize: 20,
    color: "#174B9D",
    paddingBottom: 4,
    textAlign: "left",
  },
  date: {
    fontFamily: "MontserratMedium",
    fontSize: 10,
    color: "#989898",
    textAlign: "left",
  },
  label: {
    alignItems: "flex-start",
    marginTop: 18,
  },
  labelTxt: {
    fontSize: 14,
    color: "#174B9D",
    fontFamily: "HelveticaNeueBold",
    textAlign: "left",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "stretch",
    backgroundColor: "#0697DC0A",
    borderWidth: 1,
    borderColor: "#0697DC",
    borderRadius: 8,
    marginTop: 6.69,
    height: 50,
    width: "100%",
    alignItems: "center",
  },
  inputContainer2: {
    backgroundColor: "#0697DC0A",
    borderWidth: 1,
    borderColor: "#0697DC",
    borderRadius: 8,
    marginTop: 6.69,
    height: 50,
  },
  inputTxt: {
    fontSize: 14,
    fontFamily: "MontserratMedium",
    textAlign: "left",
    color: "#174B9D",
    height: 50,
    paddingHorizontal: 10,
    paddingVertical: 5,
    width: "100%",
  },
  inputDate: {
    fontSize: 14,
    fontFamily: "MontserratMedium",
    textAlign: "left",
    color: "#174B9D",
    width: "100%",
    paddingHorizontal: 10,
    top: 12,
  },
  icon: {
    display: "flex",
    width: "100%",
    alignItems: "flex-end",
    right:6,
    bottom:8
  },
  buttonTextStyle: {
    color: "#174B9D",
    fontFamily: "MontserratMedium",
    fontSize: 14,
    textAlign: "left",
  },
  buttonStyle: {
    width: "100%",
    borderRadius: 10,
    backgroundColor: "#0697DC0A",
    height: "90%",
    top: 2,
    position: "relative",
    left: 10,
  },
  dropStyle: {
    position: "relative",
    display: "flex",
    width: "100%",
    flexDirection: "row-reverse",
    right: 15,
    top: 20,
  },
});
