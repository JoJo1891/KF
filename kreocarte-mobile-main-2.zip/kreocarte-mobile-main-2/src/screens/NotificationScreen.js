import React, { useState, useEffect } from "react";
import {
  View,
  FlatList,
  StyleSheet,
  Alert,
  TouchableOpacity,
  Text,
} from "react-native";

import {
  GradientComponent,
  SimpleHeaderComponent,
  NotificationListItem,
  Loader,
} from "../components";
import { windowHeight, windowWidth } from "../themes";
import {
  moderateVerticalScale,
  moderateScale,
} from "react-native-size-matters";
import {
  deleteNotificationById,
  getNotifications,
  deleteNotificationByUser,
} from "../api/notifications";

import { useMutation, useQuery, useQueryClient } from "react-query";
import { useSelector } from "react-redux";
import { selectIsLogged } from "../state/auth";

const NotificationScreen = ({ navigation }) => {
  const queryClient = useQueryClient();
  const isLogged = useSelector(selectIsLogged);
  const [isLoaded, setLoaded] = useState(isLogged ? false : true);
  const [notifData, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  if (isLogged) {
    const data = useQuery("getNotifications", getNotifications, {
      onSuccess: (data) => {
        setData(data);
        setLoaded(true);
      },
      onError: (error) => {
        setLoaded(true);
        if (error.message === "Request failed with status code 401") {
          Alert.alert("Error");
        } else {
          Alert.alert("Error");
        }
      },
      cacheTime: 0,
    });
  } else {
    //
  }

  const deleteNotificationMutation = useMutation(deleteNotificationById, {
    onSuccess: (response) => {
      queryClient.refetchQueries("getNotifications");
    },
    onError: (error) => {
      Alert.alert("Erreur de suppression de la notification");
      queryClient.refetchQueries("getNotifications");
    },
    onSettled: () => {
      queryClient.invalidateQueries("deleteNotificationById");
    },
  });

  const deleteNotificationMutations = useMutation(deleteNotificationByUser, {
    onSuccess: (response) => {
      Alert.alert("Toutes les notifications ont été supprimées");
      queryClient.refetchQueries("getNotifications");
      setLoading(false);
    },
    onError: (error) => {
      Alert.alert("Erreur de suppression de toutes les notifications");
      setLoading(false);
    },
    onSettled: () => {
      queryClient.invalidateQueries("deleteNotificationByUser");
    },
  });

  const deleteNotification = (id) => {
    setData(notifData.filter((notification) => notification.id !== id));
    deleteNotificationMutation.mutate(id);
  };

  const deleteAllNotification = () => {
    deleteNotificationMutations.mutate();
    setLoading(true);
  };

  return (
    <View style={styles.screenContainer}>
      <GradientComponent
        colors={["#E2F2FF", "#FFFFFF"]}
        style={styles.backgroundGradient}
      />
      <View style={styles.contentContainer}>
        <FlatList
          ListHeaderComponent={
            <View style={styles.headerContainer}>
              <SimpleHeaderComponent title="Notifications" />
              {!isLoaded && (
                <View style={{ flex: 1, justifyContent: "center" }}>
                  <Loader />
                </View>
              )}
            </View>
          }
          ListFooterComponent={<View />}
          ListFooterComponentStyle={{ marginBottom: 40 }}
          data={notifData ? notifData : []}
          extraData={notifData}
          renderItem={({ item }) => (
            <NotificationListItem
              type={item?.type}
              source_details={item?.source_details}
              name={item?.source_details?.nom}
              deleteItem={deleteNotification}
              {...item}
            />
          )}
          keyExtractor={(notification) => notification.id}
          showsVerticalScrollIndicator={false}
        />
      </View>

      {isLogged === true && (
        <>
          {loading === false ? (
            <View style={styles.clearAll}>
              <TouchableOpacity
                onPress={() => deleteAllNotification()}
                style={styles.floating}
              >
                <Text style={styles.clearAllText}>
                  Supprimer toutes les notifications
                </Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.clearAll}>
              <View style={styles.floating}>
                <Text style={styles.clearAllText}>
                  Supprimer toutes les notifications
                </Text>
              </View>
            </View>
          )}
        </>
      )}
    </View>
  );
};

export default NotificationScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    justifyContent: "flex-start",
  },
  headerContainer: {
    marginBottom: 20,
  },
  clearAll: {
    position: "absolute",
    top: "85%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    borderTopColor: "#CED4D9",
  },
  clearAllText: {
    alignSelf: "center",
    fontSize: moderateScale(15),
    color: "#3c3c3c",
    fontWeight: "bold",
  },
  floating: {
    width: moderateScale(260),
    height: moderateScale(40),
    backgroundColor: "#dadee3",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 50,
    opacity: 0.5,
  },
});
