import React from "react";
import {
  Text,
  View,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { ScrollView } from "react-native";
import Clock from "../assets/icons/historique-clock.svg";
import UserIcon from "../assets/icons/user_available.svg";
import UnfollowIcon from "../assets/icons/unfollow.svg";
import DemanderIcon from "../assets/icons/demander_menu.svg";
import { SimpleHeaderComponent } from "../components";
import { useNavigation } from "@react-navigation/native";

const CompteScreen = () => {
  const navigation = useNavigation();

  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <SimpleHeaderComponent title="Compte" />

      <View style={styles.screenContainer}>
        <TouchableOpacity
          style={styles.labelBorder}
          onPress={() => navigation.navigate("ProfileScreen")}
        >
          <View style={styles.icon}>
            <UserIcon />
          </View>
          <Text style={styles.label}>Profil</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.labelBorder}
          onPress={() => navigation.navigate("HistoryPointsPrograms")}
        >
          <View style={styles.icon}>
            <Clock />
          </View>
          <Text style={styles.label}>Historique des activités</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.labelBorder}
          onPress={() => navigation.navigate("RequestAccountScreen")}
        >
          <View style={styles.icon}>
            <DemanderIcon />
          </View>
          <Text style={styles.label}>Demander infos du compte</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.labelBorder}
          onPress={() => navigation.navigate("DeleteAccountScreen")}
        >
          <View style={styles.icon}>
            <UnfollowIcon />
          </View>
          <Text style={styles.label}>Supprimer mon compte</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

export default CompteScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    marginHorizontal: 16,
    alignItems: "center",
    height: "100%",
    alignContent: "center",
    paddingTop: 30,
  },
  labelBorder: {
    alignItems: "center",
    alignContent: "center",
    borderColor: "#EBEBEB",
    borderBottomWidth: 1,
    flexDirection: "row",
    width: "100%",
    height: 68.3,
  },
  icon: {
    width: "20%",
    alignItems: "center",
  },
  label: {
    fontFamily: "MontserratSemiBold",
    fontSize: 20,
    color: "#174B9D",
    flexDirection: "row",
    width: "80%",
  },
});
