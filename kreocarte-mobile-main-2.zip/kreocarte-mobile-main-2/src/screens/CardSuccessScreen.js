import React from 'react';

import { 
    View,
    Text,
    TouchableOpacity,
    StyleSheet
} from 'react-native';

import CloseIcon from '../assets/icons/close_white.svg';
import GreenCircle from '../assets/icons/green-circle.svg';
import CardSuccessIcon from '../assets/icons/card-success.svg';
import { moderateVerticalScale, moderateScale } from 'react-native-size-matters';
import { windowHeight } from '../themes';

const CardSuccessScreen = ({navigation,route}) => {
    const {id} = route.params
 return <View style={styles.screenContainer}>
     
     <View style={styles.greenCircle}>
         <GreenCircle height={windowHeight-90}/>
     </View>
     <View style={styles.contentContainer}>
        <CardSuccessIcon/>
        <Text style={styles.text}>votre carte a été ajoutée avec succès</Text>
     </View>
     <TouchableOpacity onPress={()=>navigation.navigate('CardsScreen')}style={styles.headerContainer}>
        <CloseIcon/>
     </TouchableOpacity>
 </View>
}

export default CardSuccessScreen;

const styles = StyleSheet.create({
    screenContainer :{
        flex : 1,
        backgroundColor : '#5ED96A'
    },
    headerContainer : {
        top : moderateVerticalScale(60),
        right : moderateScale(40),
        alignSelf : 'flex-end',
        position : 'absolute',
    },
    greenCircle : {
        position : 'absolute',
        left : -moderateScale(93),
        top : moderateVerticalScale(55),
        bottom : 0,
    },
    contentContainer : {
        position : 'absolute',
        left : 0,
        top : 0,
        right : 0,
        bottom : 0,
        justifyContent : 'center',
        alignItems : 'center'
    },
    text : {
        textAlign : 'center',
        marginHorizontal : 30,
        marginTop : 10,
        fontFamily : 'MontserratMedium',
        fontSize : moderateScale(25),
        color : 'white'
    }
});