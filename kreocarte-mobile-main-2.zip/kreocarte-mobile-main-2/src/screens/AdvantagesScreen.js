import React,{useState} from "react";

import { View, Text, StyleSheet } from "react-native";
import { useQuery } from "react-query";
import { getAdventages } from "../api/adventages";

import {
  CatalogListComponent,
  SimpleHeaderComponent,
  AdventagesListItem,
  ModalComponent,
  AdvantagesModal,
  Loader
} from "../components";
import { windowHeight } from "../themes";

const AdvantagesScreen = ({route}) => {

  const {id} = route.params

  const [modalVisible,setModalVisible] = useState(false);

  const [adventage,setAdventage] = useState(null)

  const {data,isLoading} = useQuery(['rewards',id],({queryKey})=> getAdventages(queryKey[1]))

  return (
    <View style={styles.screenContainer}>
      <ModalComponent modalVisible={modalVisible}>
        <AdvantagesModal {...adventage} onClose={()=>setModalVisible(!modalVisible)}/>
      </ModalComponent>
      <CatalogListComponent
        header={
          <View>
            <SimpleHeaderComponent title="Avantages" />
            <View style={styles.descriptionContainer}>
              <Text style={styles.description}>
                Retrouvez vos avantages fidélités
              </Text>
            </View>
            {isLoading && <View style={{flex : 1 , justifyContent : 'center',alignItems : 'center'}}>
              <Loader/>
            </View>}
          </View>
        }
        ItemComponent={(item)=><AdventagesListItem onPress={()=>{
          setAdventage(item)
          setModalVisible(!modalVisible)
        }} type='advantages' {...item}/>}
        data={data}
        extraData={data}
      />
    </View>
  );
};

export default AdvantagesScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
  },
  listContainer: {
    marginTop: 20,
  },
  descriptionContainer: {
    marginTop: 20,
    marginHorizontal: 15,
  },
  description: {
    fontFamily: "MontserratRegular",
    color: "#7D7D7D",
    fontSize: 14,
  },
});
