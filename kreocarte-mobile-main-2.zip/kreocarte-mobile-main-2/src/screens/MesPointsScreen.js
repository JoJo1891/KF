import React, { useEffect, useState } from "react";
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity
} from "react-native";
import { ScrollView, RefreshControl } from "react-native";

import GrupoIcon from "../assets/icons/Grupo-888.svg";
import GrupoIcon2 from "../assets/icons/Grupo-1818.svg";

import { CompositeHeaderComponent } from "../components";
import { useNavigation } from "@react-navigation/native";
import { GradientComponent } from "../components";

import { windowHeight } from "../themes";

import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { getUser } from "../api/user";
import { selectIsLogged } from "../state/auth";
import { useSelector } from "react-redux";
import AsyncStorage from "@react-native-async-storage/async-storage";

const MesPointsScreen = () => {
  const navigation = useNavigation();

  const isLogged = useSelector(selectIsLogged);

  const [visible, setVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [poitns, setPoints] = useState(0);
  const queryClient = useQueryClient();

  const getData = async () => {
    try {
        const value = await AsyncStorage.getItem('points')
        if(value !== null )  {
           //sconsole.log(value)
        }else{
            navigation.navigate('MesPointsTutorial1');
        }
    } catch(e) {
        // return value = false;
    }
}

  useEffect(() => {
    getData();
  }, []); 

  useEffect(()=>{
    if (isLogged){
      queryClient.refetchQueries('users')
      setPoints(data.points_gofid)
    }else{
      setPoints(0)
    }
  },[])

  const onRefresh = () => {
    setRefreshing(true);
    if (isLogged){
      queryClient.refetchQueries(["users"]);
      setPoints(data.points_gofid)
    }else{
      setPoints(0)
    }
    setRefreshing(false);
  };

  const { data } = useQuery(
    ["users"],
    ({ queryKey }) => getUser(queryKey[1]),
    { 
      cacheTime: 0,
    }
  );

  return (
    <View style={styles.screenContainer}>
      <GradientComponent
        colors={["#E2F2FF", "#FFFFFF"]}
        style={styles.backgroundGradient}
      />
      <View style={styles.contentContainer}>
        <ScrollView
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          showsVerticalScrollIndicator={false}
        >
          <CompositeHeaderComponent title="MesPoints" />

          <View
            style={{
              justifyContent: "center",
              alignItems: "center",
              paddingTop: 10,
            }}
          >
            <GrupoIcon />
          </View>

          <View
            style={{
              justifyContent: "center",
              alignItems: "center",
              borderBottomColor: "#e9ecef",
              borderBottomWidth: 1,
              width: "100%",
              paddingBottom: 29,
            }}
          >
            <Text style={styles.title3}>
              {poitns}
              <View style={{ paddingBottom: 15 }}>
                <Text style={styles.title4}> PTS </Text>
              </View>
            </Text>
          </View>

          <View
            style={{
              marginTop: 10,
              marginBottom: 30,
              paddingLeft: 15,
              alignItems: "center",
              justifyContent: "center",
              paddingBottom: 10,
            }}
          >
            <Text style={styles.paragraph}>
              <Text style={styles.title2}>
                Vos actions sont récompensées ! Cumulez des points Kréocarte’ et
                débloquez des Deals !{"\n\n"}
              </Text>
              {
                "Gagnez vos Points Kréocarte’ à chaque action et échangez vos points en Deal du moment. "
              }
            </Text>
          </View>

          <TouchableOpacity
            style={styles.containerBox}
            onPress={() => navigation.navigate("DealsScreen")}
          >
            <View style={{ paddingLeft: 30 }}>
              <GrupoIcon2 />
            </View>
            <View style={{ flexShrink: 1 }}>
              <Text style={styles.title}>DEALS</Text>
              <Text
                style={{ color: "#7D7D7D", paddingRight: moderateScale(40) }}
              >
                Découvrez la liste de vos Deals, juste ici.
              </Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              paddingTop: 1,
              justifyContent: "center",
              alignItems: "center",
            }}
            onPress={() => navigation.navigate("DefisPointsScreen")}
          >
            <Text style={[styles.paragraph2, { marginBottom: 10 }]}>
              Voulez vous en savoir plus sur les points Kréocarte' ?
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </View>
  );
};

export default MesPointsScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
    marginTop: moderateVerticalScale(7),
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  title: {
    fontFamily: "MontserratSemiBold",
    fontSize: 25,
    color: "#174B9D",
  },
  title2: {
    fontFamily: "MontserratMedium",
    fontSize: 20,
    color: "#174B9D",
    textAlign: "left",
  },
  title3: {
    fontFamily: "MontserratBold",
    fontSize: 60,
    color: "#174B9D",
    textAlign: "left",
  },
  title4: {
    fontFamily: "MontserratExtraBold",
    fontSize: 25,
    color: "#174B9D",
    textAlign: "left",
  },
  paragraph: {
    fontFamily: "MontserratRegular",
    fontSize: 14,
    color: "#7D7D7D",
  },
  paragraph2: {
    fontFamily: "MontserratRegular",
    fontSize: moderateVerticalScale(13),
    color: "#174B9D",
    textAlign: "center",
  },
  containerBox: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    borderColor: "#FBBF16",
    borderWidth: 3,
    paddingVertical: 20,
    margin: 11,
    borderRadius: 20,
    flexDirection: "row",
  },
  middle: {
    backgroundColor: "#FFFFFF",
    borderRadius: 20,
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    justifyContent: "flex-start",
    marginHorizontal: moderateScale(16),
  },
});
