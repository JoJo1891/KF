import React, { useEffect, useState } from "react";

import { View, StyleSheet, Text, Alert } from "react-native";

import { StoreHeaderComponentRatingPage } from "../components";
import { windowHeight } from "../themes";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";
import { useMutation } from "react-query";
import { GradientComponent } from "../components";
import { CompositeHeaderComponentRating } from "../components";
import { review } from "../api/review";
import { Rating } from "react-native-rating-component";

const RatingPage = ({ navigation, route }) => {
  const data = route.params.data;
  const storeId = data.id;
  const [rate, setRate] = useState(0);

  const { mutate, isError } = useMutation(review, {
    onSuccess: async (response) => {
      Alert.alert("Succès", "Opération réussie !");
      navigation.navigate("HomeScreen");
    },
  });

  const RatingHandler = async (note, storeId) => {
    mutate({
      note,
      storeId,
    });
  };

  return (
    <View style={styles.screenContainer}>
      <GradientComponent
        colors={["#E2F2FF", "#FFFFFF"]}
        style={styles.backgroundGradient}
      />

      <View style={styles.contentContainer}>
        <CompositeHeaderComponentRating title="Rating" />

        <View style={styles.headerContainer}>
          <StoreHeaderComponentRatingPage
            name={data ? data.nom : ""}
            imageUrl={data ? data.image_url : null}
          />
        </View>

        <Text style={styles.middletext}>Évaluez ce Magasin</Text>

        <View style={{ paddingTop: 20 }}>
          <Rating
            initialValue={rate}
            minimumStars={1}
            fillColorActive="#fcba03"
            fillColorInactive="#E2F2FF"
            distance={20}
            onChangeValue={async (value) => {
              {
                RatingHandler(value, storeId);
              }
            }}
          />
        </View>
      </View>
    </View>
  );
};

export default RatingPage;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
    marginTop: moderateVerticalScale(7),
  },
  headerContainer: {
    marginTop: 0,
    height: moderateVerticalScale(110),
    justifyContent: "center",
    alignItems: "center",
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  text: {
    textAlign: "center",
    fontSize: 50,
    marginTop: 20,
  },
  middletext: {
    marginTop: 10,
    color: "#174B9D",
    textAlign: "center",
    fontSize: moderateScale(20),
    fontFamily: "MontserratSemiBold",
  },
});
