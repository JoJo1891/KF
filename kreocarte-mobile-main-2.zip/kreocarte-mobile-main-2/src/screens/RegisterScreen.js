import React, { useEffect, useState } from 'react';
import {
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Alert,
  StyleSheet,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { useMutation, useQueryClient } from 'react-query';
import {
  moderateVerticalScale,
  verticalScale,
} from 'react-native-size-matters';
import AsyncStorage from '@react-native-async-storage/async-storage';

import { defaultAuthForm } from '../themes/authPages';
import { ScrollView } from 'react-native';
import GofidIcon from '../assets/icons/gofid_logo_white.svg';
import EyeIcon from '../assets/icons/eye_icon_white_active.svg';
import Mailcon from '../assets/icons/email_white.svg';
import Securitycon from '../assets/icons/padlock.svg';
import GoogleIcon from '../assets/icons/google_icon.svg';
import AppleIcon from '../assets/icons/apple_logo.svg';

import { registerQuickly } from '../api/register';
import BackArrowIcon from '../assets/icons/backArrow-white.svg';
import { setIsLogged, setUser } from '../state/auth';
import * as Yup from 'yup';
import { Formik } from 'formik';
import {
  authAppleApi,
  authFacebookApi,
  authGoogleApi,
  login,
} from '../api/login';
import { useDispatch } from 'react-redux';
import BouncyCheckbox from 'react-native-bouncy-checkbox';

//For social auth
import * as Google from 'expo-auth-session/providers/google';
import * as AuthSession from 'expo-auth-session';
import Constants from 'expo-constants';
import { GradientComponent } from '../components';
import * as AppleAuthentication from 'expo-apple-authentication';

const RegisterScreen = ({ navigation }) => {
  const EXPO_REDIRECT_PARAMS = {
    useProxy: true,
    projectNameForProxy: '@jonitro18/kreocarte',
  };
  const NATIVE_REDIRECT_PARAMS = { native: 'com.whaaat.gofid://' };
  const REDIRECT_PARAMS =
    Constants.appOwnership === 'expo'
      ? EXPO_REDIRECT_PARAMS
      : NATIVE_REDIRECT_PARAMS;
  const redirectUri = AuthSession.makeRedirectUri(REDIRECT_PARAMS);

  const [isSelected, setSelection] = useState(false);
  const [emailAux, setEmail] = useState('');
  const [passwordAux, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(true);
  const [loadingSocial, setLoadingSocial] = useState(false);
  // OAuth updated
  const [request, response, promptAsync] = Google.useIdTokenAuthRequest({
    clientId:
      '645264247547-sfgv5a54tnkrlp7oks0hhr3qrvt38lt1.apps.googleusercontent.com',
    iosClientId:
      '645264247547-u26h9dqlka5phqrjshislet52qt9hj8e.apps.googleusercontent.com',
    androidClientId:
      '645264247547-7kld5gds4t20njetdf80j0kic82pufu4.apps.googleusercontent.com',
    redirectUri,
  });
  // const [requestFb, responseFb, promptAsyncFb] = Facebook.useAuthRequest({
  //   clientId: '850777265941976',
  //   responseType: ResponseType.Token,
  //   redirectUri: AuthSession.makeRedirectUri({ useProxy: true }),
  // },
  // { useProxy: true }
  // );

  const queryClient = useQueryClient();
  const dispatch = useDispatch();

  const authGoogleMutation = useMutation('authGoogleApi', authGoogleApi, {
    onSuccess: async (response) => {
      const { token, data } = response;
      await AsyncStorage.setItem('token', token);
      await AsyncStorage.setItem('inscription', 'true');
      dispatch(setIsLogged(true));
      dispatch(setUser(data));
      const referal = await AsyncStorage.getItem('referal');
      setLoadingSocial(false);

      if (referal === 'true') {
        navigation.navigate('HomeScreen');
      } else {
        navigation.navigate('ReferalScreen');
      }
    },
    onError: (error) => {
      setLoadingSocial(false);
      Alert.alert(
        "Oups, une erreur s'est produits, veuillez réessayer ultérieurement"
      );
    },
  });

  const authAppleMutation = useMutation('authAppleApi', authAppleApi, {
    onSuccess: async (response) => {
      const { token, data } = response;
      await AsyncStorage.setItem('token', token);
      await AsyncStorage.setItem('inscription', 'true');
      dispatch(setIsLogged(true));
      dispatch(setUser(data));
      const referal = await AsyncStorage.getItem('referal');
      setLoadingSocial(false);

      if (referal === 'true') {
        navigation.navigate('HomeScreen');
      } else {
        navigation.navigate('ReferalScreen');
      }
    },
    onError: (error) => {
      setLoadingSocial(false);
      Alert.alert(
        "Oups, une erreur s'est produits, veuillez réessayer ultérieurement"
      );
    },
  });

  const authFacebookMutation = useMutation('authFacebookApi', authFacebookApi, {
    onSuccess: async (response) => {
      const { token, data } = response;
      await AsyncStorage.setItem('token', token);
      await AsyncStorage.setItem('inscription', 'true');
      dispatch(setIsLogged(true));
      dispatch(setUser(data));
      const referal = await AsyncStorage.getItem('referal');
      setLoadingSocial(false);

      if (referal === 'true') {
        navigation.navigate('HomeScreen');
      } else {
        navigation.navigate('ReferalScreen');
      }
    },
    onError: (error) => {
      setLoadingSocial(false);
      Alert.alert(
        "Oups, une erreur s'est produits, veuillez réessayer ultérieurement"
      );
    },
  });

  const fetchUserInfo = async () => {
    // let data = await fetch("https://www.googleapis.com/userinfo/v2/me",{
    //   headers: {
    //     Authorization: `Bearer ${accessToken}`
    //   }
    // });
    setLoadingSocial(true);
    authGoogleMutation.mutate(response.params.id_token);
  };

  const useLoginMutation = useMutation(login, {
    onSuccess: async (response) => {
      const { token, data } = response;
      await AsyncStorage.setItem('token', token);
      dispatch(setIsLogged(true));
      dispatch(setUser(data));

      const referal = await AsyncStorage.getItem('referal');
      if (referal === 'true') {
        navigation.navigate('HomeScreen');
      } else {
        navigation.navigate('ReferalScreen');
      }
    },
    onError: (error) => {
      if (error.message === 'Request failed with status code 401') {
        Alert.alert('Email ou mot de passe invalide');
      } else {
        Alert.alert(
          "Oups, une erreur s'est produits, veuillez réessayer ultérieurement"
        );
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries('loginRegister');
    },
  });

  const { mutate, isLoading } = useMutation(registerQuickly, {
    onSuccess: async (data) => {
      await AsyncStorage.setItem('inscription', 'true');
      Alert.alert(
        'Inscription réussie',
        'Votre inscription à bien été prise en compte, vous allez recevoir un email de validation'
      );
      useLoginMutation.mutate({ email: emailAux, password: passwordAux });
    },
    onError: (error) => {
      if (error.message === 'Request failed with status code 401') {
        Alert.alert('Email ou mot de passe invalide');
      } else if (error?.response?.data?.error === 'this user already exist') {
        Alert.alert(
          'Vous avez déjà un compte',
          'Vous pouvez récupérer votre mot de passe en cliquant sur Mot de Passe oublié, depuis la page de connexion'
        );
      } else {
        Alert.alert(
          "Oups, une erreur s'est produits, veuillez réessayer ultérieurement"
        );
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries('registerQuickly');
    },
  });

  const loginValidationSchema = Yup.object().shape({
    email: Yup.string()
      .email('Merci d’entrer une adresse e-mail valable')
      .required('Adresse e-mail est nécessaire'),
    password: Yup.string()
      .min(
        6,
        ({ min }) => `Le mot de passe doit être au moins de ${min} caractères`
      )
      .required('Mot de passe requis'),
  });

  const showPasswordHandler = () => {
    if (showPassword) {
      setShowPassword(false);
    } else {
      setShowPassword(true);
    }
  };

  const registerHandler = async (email, plainPassword) => {
    setEmail(email);
    setPassword(plainPassword);
    mutate({
      email,
      plainPassword,
    });
  };

  useEffect(() => {
    if (response?.type === 'success') {
      fetchUserInfo();
    }
  }, [response]);

  // useEffect(() => {
  //   if(responseFb?.type === "success"){
  //     let {accessToken} = responseFb.authentication
  //     setLoadingSocial(true);
  //     authFacebookMutation.mutate(accessToken);
  //   }
  // }, [responseFb])

  return (
    <View style={styles.container}>
      <View style={styles.screenContainer}>
        <GradientComponent
          colors={['#0697DC', '#174B9D']}
          style={styles.backgroundGradient}
        />
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={styles.contentContainer}
        >
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={{ marginStart: 19, marginTop: moderateVerticalScale(40) }}
          >
            <BackArrowIcon />
          </TouchableOpacity>
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              paddingTop: 50,
            }}
          >
            <GofidIcon />
          </View>

          <View
            style={{
              marginTop: moderateVerticalScale(50),
              marginBottom: moderateVerticalScale(20),
            }}
          >
            <Text style={defaultAuthForm.enregistrer}>
              S'enregistrer rapidement
            </Text>
          </View>

          <View
            style={{
              alignContent: 'center',
              justifyContent: 'center',
              marginTop: 10,
              marginBottom: -20,
            }}
          >
            {loadingSocial ? (
              <>
                <ActivityIndicator size="large" color="#FFFFFF" />
              </>
            ) : (
              <View></View>
            )}
          </View>
          {/*------------------------------------------------Google AUTH--------------------------------------------  */}

          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              marginTop: 40,
              paddingVertical: 10,
              marginVertical: 10,
            }}
          >
            <TouchableOpacity
              style={defaultAuthForm.authButton}
              onPress={() => promptAsync({ showInRevents: true })}
              disabled={isLoading || loadingSocial}
            >
              <View style={{ marginRight: 7 }}>
                <GoogleIcon />
              </View>
              <Text style={defaultAuthForm.authButtText}>Google </Text>
            </TouchableOpacity>
          </View>
          {/*------------------------------------------------FACEBOOK AUTH--------------------------------------------  */}

          {/* {Platform.OS === "ios" && (
            <View
              style={{
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: 10,
              }}
            >
              <TouchableOpacity
                style={defaultAuthForm.authButton}
                onPress={
                  () =>
                    Alert.alert(
                      "Oups, la connexion Facebook est en maintenance."
                    )

                  // promptAsyncFb()
                }
                // disabled={isLoading || loadingSocial}
              >
                <View style={{ marginRight: 1 }}>
                  <SocialIcon
                    style={{ width: 30, height: 30 }}
                    type="facebook"
                  />
                </View>
                <Text style={defaultAuthForm.authButtText}>Facebook</Text>
              </TouchableOpacity>
            </View>
          )} */}
          {/*------------------------------------------------APPLE AUTH ONLY FOR IOS--------------------------------------------  */}
          {Platform.OS === 'ios' && (
            <TouchableOpacity
              style={defaultAuthForm.authButton}
              onPress={async () => {
                try {
                  if (isLoading || loadingSocial) return;
                  const credential = await AppleAuthentication.signInAsync({
                    requestedScopes: [
                      AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
                      AppleAuthentication.AppleAuthenticationScope.EMAIL,
                    ],
                  });
                  if (!credential.identityToken)
                    return alert('Error, not apple token found.');
                  setLoadingSocial(true);
                  authAppleMutation.mutate(credential.identityToken);
                  // signed in
                } catch (e) {
                  console.log(e);
                  if (e.code === 'ERR_CANCELED') {
                    // handle that the user canceled the sign-in flow
                  } else {
                    // handle other errors
                  }
                }
              }}
              disabled={isLoading || loadingSocial}
            >
              <View style={{ marginRight: 7 }}>
                <AppleIcon />
              </View>
              <Text style={defaultAuthForm.authButtText}>Apple</Text>
            </TouchableOpacity>
          )}
          <View
            style={{
              marginTop: 35,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Text style={defaultAuthForm.enregistrer}>
              ...ou avec votre email
            </Text>
          </View>

          {/*------------------------------------------------FORM--------------------------------------------  */}

          <Formik
            initialValues={{ email: '', password: '' }}
            onSubmit={(values) => {
              registerHandler(values.email, values.password);
            }}
            validationSchema={loginValidationSchema}
          >
            {({ handleChange, handleBlur, handleSubmit, values, errors }) => (
              <>
                <View style={defaultAuthForm.inputContainer}>
                  <Mailcon />
                  <TextInput
                    type="text"
                    style={defaultAuthForm.inputTxt}
                    placeholder="Email"
                    placeholderTextColor="#FFFFFF"
                    color="#FFFFFF"
                    name="email"
                    autoCapitalize="none"
                    onChangeText={handleChange('email')}
                    onBlur={handleBlur('email')}
                    value={values.email}
                  />
                </View>
                {errors.email && (
                  <Text style={{ fontSize: 10, color: 'red', marginLeft: 16 }}>
                    {errors.email}
                  </Text>
                )}

                <View style={defaultAuthForm.inputContainer}>
                  <View style={defaultAuthForm.inputTxtPassword}>
                    <Securitycon />
                    <TextInput
                      type="text"
                      style={defaultAuthForm.inputTxt}
                      placeholder="Mot de passe"
                      placeholderTextColor="#FFFFFF"
                      color="#FFFFFF"
                      secureTextEntry={showPassword}
                      name="password"
                      onChangeText={handleChange('password')}
                      onBlur={handleBlur('password')}
                      value={values.password}
                    />
                  </View>
                  <TouchableOpacity
                    style={{
                      display: 'flex',
                      marginLeft: 10,
                      width: '10%',
                      marginBottom: 2,
                    }}
                    onPress={showPasswordHandler}
                  >
                    <EyeIcon />
                  </TouchableOpacity>
                </View>
                {errors.password && (
                  <Text style={{ fontSize: 10, color: 'red', marginLeft: 16 }}>
                    {errors.password}
                  </Text>
                )}

                <View
                  style={{
                    marginTop: verticalScale(25),
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    display: 'flex',
                  }}
                >
                  <View style={styles.CheckBoxStyle}>
                    <BouncyCheckbox
                      fillColor="#174B9D"
                      iconStyle={{ borderColor: 'white', borderRadius: 5 }}
                      checked={isSelected}
                      onPress={(value) => {
                        setSelection(!isSelected);
                      }}
                    />
                  </View>
                  <View style={styles.textStyle}>
                    <Text
                      style={{
                        color: 'white',
                        fontFamily: 'MontserratLight',
                        fontSize: 16,
                      }}
                      onPress={() => navigation.navigate('CguScreen')}
                    >
                      En cochant cette case, j’accepte Toutes les{' '}
                      <Text style={styles.underline}>
                        conditions générales d’utilisation{' '}
                      </Text>
                      de l’application KréoCarte'
                    </Text>
                  </View>
                </View>

                <View
                  style={{
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginTop: verticalScale(40),
                  }}
                >
                  <TouchableOpacity
                    style={defaultAuthForm.authButton}
                    disabled={isLoading || loadingSocial}
                    onPress={() => {
                      if (isSelected) handleSubmit();
                    }}
                  >
                    <Text
                      style={
                        isLoading || loadingSocial
                          ? defaultAuthForm.authButtTextDisabled
                          : defaultAuthForm.authButtText
                      }
                    >
                      S'inscrire
                    </Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </Formik>
          {/*------------------------------------------------FORM--------------------------------------------  */}

          <TouchableOpacity
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              marginTop: 30,
              paddingVertical: 10,
              marginBottom: 100,
            }}
            onPress={() => navigation.navigate('LoginScreen')}
          >
            <Text
              style={{
                color: 'white',
                fontFamily: 'MontserratRegular',
                fontSize: 16,
                marginBottom: verticalScale(150),
              }}
            >
              Vous avez déjà un compte ?
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  underline: {
    textDecorationLine: 'underline',
  },

  CheckBoxStyle: {
    paddingBottom: moderateVerticalScale(25),
    paddingLeft: moderateVerticalScale(130),
    position: 'relative',
    top: 10,
  },
  textStyle: {
    paddingRight: moderateVerticalScale(120),
  },

  backgroundGradient: {
    width: '100%',
    height: '100%',
    borderColor: '#4DBDF2',
  },
  screenContainer: {
    flex: 1,
    width: '100%',
  },
  container: {
    alignItems: 'center',
    height: '100%',
    width: '100%',
  },
  contentContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
  },
});

export default RegisterScreen;
