import React, { useState } from "react";
import { Text, View, StyleSheet, Image } from "react-native";
import { ScrollView } from "react-native";

import CAPNordIcon from "../assets/icons/Logo_CAP_Nord_Martinique_result.svg";
import CCIIcon from "../assets/icons/CCI_MARTINIQUE.svg";
import LEuropeIcon from "../assets/icons/l_europe_s_engage.svg";
import LeaderUnionIcon from "../assets/icons/LEADER__union_europea_final (1).svg";
import RepublicFrancaiseIcon from "../assets/icons/republique_francaise_logo.svg";
import NosRualitesIcon from "../assets/icons/nos_ruralites_logo.svg";

import CollectiviteIcon from "../assets/icons/Logo_Collectivite_Territoriale_de_Martinique.svg";

import { SimpleHeaderComponent } from "../components";
import { useNavigation } from "@react-navigation/native";

const WhoWeAreScreen = () => {
  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <SimpleHeaderComponent title="Qui sommes-nous" />
      <View style={styles.screenContainer}>
        <View>
          <Text style={styles.paragraph}>
            “Gonord” est une plateforme numérique de fidélisation multi-boutique
            destinée aux territoires du nord de la Martinique. {"\n\n"}La
            société MEDIAFID sous l'impulsion de CAP Nord, met à disposition son
            Application KréoCarte qui permet au commerçant d’innover en
            digitalisant leur programme de fidélité classique. {"\n\n"}Nous
            tenons à remercier les différents financeurs :
          </Text>
        </View>

        <View style={styles.iconsRow}>
          <View style={{ width: "50%", paddingHorizontal: 30 }}>
            <CAPNordIcon style={styles.icon} />
          </View>
          <View style={{ width: "50%" }}>
            <CCIIcon style={styles.icon} />
          </View>
        </View>

        <View style={styles.iconsRow}>
          <View style={{ width: "50%", paddingHorizontal: 15 }}>
            <LEuropeIcon style={styles.icon} />
          </View>
          <View style={{ width: "50%", paddingHorizontal: 20 }}>
            <LeaderUnionIcon style={styles.icon} />
          </View>
        </View>

        <View style={styles.iconsRow}>
          <View style={{ width: "50%", paddingHorizontal: 20 }}>
            <RepublicFrancaiseIcon style={styles.icon} />
          </View>
          <View style={{ width: "50%", paddingHorizontal: 10 }}>
            <NosRualitesIcon style={styles.icon} />
          </View>
        </View>

        <View style={{ width: "100%", height: 150, paddingHorizontal: 110 }}>
          <CollectiviteIcon style={styles.icon} />
        </View>
      </View>
    </ScrollView>
  );
};

export default WhoWeAreScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    marginHorizontal: 16,
    alignItems: "center",
    alignContent: "center",
    paddingTop: 30,
    height: "100%",
  },
  paragraph: {
    fontFamily: "MontserratRegular",
    fontSize: 16,
    color: "#707070",
    marginBottom: 16,
  },
  iconsRow: {
    width: "100%",
    display: "flex",
    flexDirection: "row",
    height: 130,
  },
  icon: {
    width: "100%",
    height: "100%",
  },
});
