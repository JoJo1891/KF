import React, { useState } from "react";
import { useNavigation } from "@react-navigation/native";
import {useDispatch} from 'react-redux'
import {
  Text,
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import {
  moderateScale,
  moderateVerticalScale,
  verticalScale,
} from "react-native-size-matters";
import * as Yup from "yup";
import { Formik } from "formik";
import { useMutation, useQueryClient } from "react-query";
import AsyncStorage from '@react-native-async-storage/async-storage';

import {
  ConfirmationModal,
  ModalComponent,
  SimpleHeaderComponent,
} from "../components";
import { setIsLogged, setUser } from '../state/auth';
import GofidButton from "../components/partials/GofidButton";
import SadEmoji from "../assets/icons/emoji_sad.svg";
import { deleteAccount } from "../api/user";

const DeleteAccountScreen = () => {
  const navigation = useNavigation();
  const queryClient = useQueryClient();
  const dispatch = useDispatch()

  const [modalVisible, setModalVisible] = useState(false);
  const [reason1, setReason1] = useState(false);
  const [reason2, setReason2] = useState(false);
  const [reason3, setReason3] = useState(false);

  const { isLoading,mutate } = useMutation(deleteAccount, {
    onSuccess: (data) => {
      logOut()
    },
    onError: (data) => {},
    onSettled: () => {
      queryClient.invalidateQueries("deleteAccount");
    },
  });

  const handleSubmit = () =>{
    mutate()
  }

  const logOut = async () =>{
    setModalVisible(false)
    navigation.navigate('AccountDeletedScreen')
    await AsyncStorage.removeItem('token')
    dispatch(setIsLogged(false))
    dispatch(setUser(null))
  }

  const formSchema = Yup.object().shape({
    reason1: Yup.string()
      .min(2, "Too Short!")
      .max(50, "Too Long!")
      .required("Required"),
    reason2: Yup.string()
      .min(2, "Too Short!")
      .max(50, "Too Long!")
      .required("Required"),
    reason3: Yup.string()
      .min(2, "Too Short!")
      .max(50, "Too Long!")
      .required("Required"),
    reason4: Yup.string()
      .min(2, "Too Short!")
      .max(50, "Too Long!")
      .required("Required"),
  });

  const handlerModalVisible = () => {
    setModalVisible(!modalVisible);
  };
  const handlerR1 = () => {
    setReason1(!reason1);
  };
  const handlerR2 = () => {
    setReason2(!reason2);
  };
  const handlerR3 = () => {
    setReason3(!reason3);
  };
  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <ModalComponent modalVisible={modalVisible}>
        <ConfirmationModal
          type="inverse"
          isLoading={isLoading}
          value="Etes-vous sûr de vouloir supprimer votre compte?"
          onCancel={() => handleSubmit()}
          onSubmit={() => setModalVisible(!modalVisible)}
        />
      </ModalComponent>
      <SimpleHeaderComponent title="Supprimer votre compte" />
      <View style={styles.screenContainer}>
        <View>
          <SadEmoji />
        </View>

        <View style={styles.textContainer}>
          <Text style={styles.paragraph}>
            <Text style={styles.title}>
            Vous nous quittez déjà ?{"\n\n"}
            </Text>
            {
              "En supprimant votre compte, nous supprimerons toutes les données liées à votre compte. Mais avant cela, pouvez-vous nous dire la raison de votre départ ?\n\n"
            }
          </Text>
        </View>

        <View style={styles.inputContainer}>
          <TouchableOpacity style={styles.touch} onPress={handlerR1}>
            <Text style={reason1 ? styles.selected : styles.inputTxt}>
            L’expérience utilisateur ou client était mauvaise
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.touch} onPress={handlerR2}>
            {!reason2 && (
              <Text style={reason2 ? styles.selected : styles.inputTxt}>
                J’ai rencontré trop de bugs
              </Text>
            )}
            {reason2 && (
              <Text style={reason2 ? styles.selected : styles.inputTxt}>
                Quelque chose était cassé
              </Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity style={styles.touch} onPress={handlerR3}>
            <Text style={reason3 ? styles.selected : styles.inputTxt}>
            J’ai des problèmes de confidentialité 
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.touch}
            onPress={() => navigation.navigate("DeleteAccount1Screen")}
          >
            <Text style={styles.inputTxt}>Autre raison</Text>
          </TouchableOpacity>

          {/* <TextInput 
                            type="text"
                            style={styles.inputTxt}
                            placeholder="Autre raison" 
                          
                        /> */}

          <View style={styles.button}>
            <GofidButton
              type="submit"
              name="red"
              value="Supprimer mon compte"
              disabled={isLoading}
              press={()=>{
                if(reason1||reason2||reason3){
                  setModalVisible(!modalVisible)
                }
              }}
            />
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

export default DeleteAccountScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    marginHorizontal: moderateScale(16),
    alignItems: "center",
    height: "100%",
    alignContent: "center",
    paddingTop: 40,
  },
  textContainer: {
    marginTop: 16,
  },
  title: {
    fontFamily: "MontserratSemiBold",
    fontSize: 25,
    color: "#FE6869",
    flexDirection: "row",
    textAlign: "center",
  },
  paragraph: {
    fontFamily: "MontserratRegular",
    fontSize: 14,
    color: "#7D7D7D",
    marginBottom: 0,
    textAlign: "center",
  },
  button: {
    marginTop: 30,
    marginBottom: 50,
  },
  inputContainer: {
    width: "100%",
  },
  inputTxt: {
    fontSize: 14,
    fontFamily: "MontserratMedium",
    textAlign: "left",
    color: "#989898",
    paddingHorizontal: moderateScale(10),
    borderWidth: 1,
    borderColor: "#989898",
    borderRadius: 8,
    paddingVertical: moderateVerticalScale(10),
  },
  selected: {
    fontSize: 14,
    fontFamily: "MontserratMedium",
    textAlign: "left",
    color: "#FE6869",
    paddingHorizontal: moderateScale(10),
    backgroundColor: "#FF87881A",
    borderWidth: 1,
    borderColor: "#FE6869",
    borderRadius: 8,
    paddingVertical: moderateVerticalScale(10),
  },
  touch: {
    marginBottom: 20,
  },
});
