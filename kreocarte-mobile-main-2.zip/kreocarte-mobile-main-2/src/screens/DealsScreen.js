import React, { useState, useEffect } from "react";

import { View, Text, StyleSheet, RefreshControl, Alert } from "react-native";
import { useMutation, useQuery, useQueryClient } from "react-query";

import { getDealsList } from "../api/challenges";
import { verticalScale } from "react-native-size-matters";

import {
  GradientComponent,
  VerticalListComponent,
  SimpleHeaderComponent,
  RewardListItem,
  Loader,
} from "../components";
import { windowHeight } from "../themes";
import { moderateScale } from "react-native-size-matters";
import { getUser } from "../api/user";

const DealsScreen = ({ navigation }) => {
  const [dealList, setDealList] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(false);
  const queryClient = useQueryClient();
  const [points, setPoints] = useState(0);

  const { isLoading } = useQuery("deals", getDealsList, {
    onSuccess: (data) => {
      filterDeal(data.reverse());
    },
    onError: (error) => {
      if (error.message === "Request failed with status code 401") {
        Alert.alert("Error");
      } else {
        Alert.alert("Error");
      }
    },
  });

  const updateDeal = async () => {
    setLoading(true);
    await queryClient.refetchQueries("deals");
    await queryClient.refetchQueries("users");
    setPoints(data.points_gofid);
    setLoading(false);
  };

  const filterDeal = async (unfilteredList) => {
    let filteredList = unfilteredList?.filter((element) => {
      if (element.type === "deal") {
        return element;
      }
      // else if (element.actual_deal) {
      //   return element;
      // }
    });

    setDealList(filteredList);
  };

  useEffect(() => {
    queryClient.refetchQueries("users");
    setPoints(data.points_gofid);
    filterDeal();
  }, []);

  const onRefresh = () => {
    setLoading(true);
    queryClient.refetchQueries("deals");
    queryClient.refetchQueries("users");
    setPoints(data.points_gofid);
    setLoading(false);
  };

  const { data } = useQuery(["users"], ({ queryKey }) => getUser(queryKey[1]), {
    cacheTime: 0,
  });

  return (
    <View style={styles.screenContainer}>
      <GradientComponent
        colors={["#E2F2FF", "#FFFFFF"]}
        style={styles.backgroundGradient}
      />

      <View style={styles.contentContainer}>
        <VerticalListComponent
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          header={
            <View>
              <SimpleHeaderComponent title="Deals" />
              <View style={styles.descriptionContainer}>
                <Text style={styles.description}>
                  Faites le plein de bonnes offres et bons plans de votre
                  magasin préférés
                </Text>
              </View>
              {loading && (
                <View style={styles.loaderContainer}>
                  <Loader />
                </View>
              )}
              {isLoading && (
                <View style={styles.loaderContainer}>
                  <Loader />
                </View>
              )}
            </View>
          }
          ItemComponent={(item) => (
            <RewardListItem
              updateDeal={updateDeal}
              loading={loading}
              type="deal"
              points={points}
              {...item}
            />
          )}
          data={dealList}
          columns={3}
        />
      </View>
    </View>
  );
};

export default DealsScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  listContainer: {
    marginTop: 20,
  },
  descriptionContainer: {
    marginTop: 20,
    marginHorizontal: moderateScale(15),
  },
  description: {
    fontFamily: "MontserratRegular",
    color: "#7D7D7D",
    fontSize: 14,
  },
  loaderContainer: {
    marginTop: verticalScale(10),
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    justifyContent: "flex-start",
  },
});
