import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from "react-native";

import { SimpleHeaderComponent } from "../components";
import CardIcon from "../assets/icons/card-blue.svg";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";
import Cancel from "../assets/icons/Grupo 1879.svg";

const ScannerScreenError = ({ route, navigation }) => {
  return (
    <View style={styles.screenContainer}>
      <ScrollView nestedScrollEnabled={true}>
        <SimpleHeaderComponent title="Scan carte" />

        <Text style={styles.buttonText4}>Erreur</Text>

        <View style={styles.cardIcon}>
          <CardIcon />
        </View>

        <View style={styles.paddingContainer}>
          <View style={styles.buttonContainer3}>
            <View style={{ paddingLeft: 20 }}>
              <Cancel />
            </View>
            <Text style={styles.buttonText3}>
            Nous n'avons pas pu reconnaître votre carte, veuillez essayer encore.
            </Text>
          </View>
        </View>

        <View style={styles.paddingContainer2}>
          <TouchableOpacity
            onPress={() => navigation.navigate("ScannerScreen")}
          >
            <View style={styles.buttonContainer}>
              <Text style={styles.buttonText}>Essayer à nouveau</Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.paddingContainer3}>
          <TouchableOpacity
            onPress={() => navigation.navigate("ManualCardScreen")}
          >
            <View style={styles.buttonContainer2}>
              <Text style={styles.buttonText2}>Insérez manuellement</Text>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

export default ScannerScreenError;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  cardIcon: {
    alignSelf: "center",
    marginTop: moderateVerticalScale(-40),
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: moderateVerticalScale(10),
    paddingHorizontal: moderateScale(30),
    backgroundColor: "white",
    borderRadius: 1000,
    borderColor: "#174B9D",
    borderWidth: 2,
  },
  buttonContainer2: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: moderateVerticalScale(10),
    paddingHorizontal: moderateScale(30),
    backgroundColor: "#174B9D",
    borderRadius: 1000,
  },
  buttonContainer3: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: moderateVerticalScale(15),
    paddingHorizontal: moderateScale(30),
    backgroundColor: "#FF8788",
    borderRadius: 20,
  },
  paddingContainer: {
    paddingTop: moderateScale(30),
    paddingBottom: moderateScale(10),
    paddingLeft: moderateScale(10),
    paddingRight: moderateScale(10),
  },
  paddingContainer2: {
    paddingTop: moderateScale(250),
    paddingBottom: moderateScale(10),
    paddingLeft: moderateScale(10),
    paddingRight: moderateScale(10),
  },
  paddingContainer3: {
    paddingBottom: moderateScale(10),
    paddingLeft: moderateScale(10),
    paddingRight: moderateScale(10),
  },
  buttonText: {
    color: "#174B9D",
    fontSize: moderateScale(20),
    fontFamily: "MontserratSemiBold",
  },
  buttonText2: {
    color: "white",
    fontSize: moderateScale(20),
    fontFamily: "MontserratSemiBold",
  },
  buttonText3: {
    color: "white",
    fontSize: moderateScale(14),
    fontFamily: "MontserratSemiBold",
    paddingLeft: 5,
    paddingRight: 50,
  },
  buttonText4: {
    color: "#FE6869",
    fontFamily: "MontserratMedium",
    fontSize: moderateScale(25),
    textAlign: "center",
    paddingTop: 15,
  },
});
