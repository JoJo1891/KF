import React, { useState }  from 'react';
import {Text,View,StyleSheet,Alert,TextInput} from 'react-native';
import { Formik } from 'formik';
import * as Yup from 'yup';
import {useMutation,useQueryClient} from 'react-query'
import { TouchableOpacity } from 'react-native';
import { ScrollView } from 'react-native';
import EyeIcon from '../assets/icons/eye_icon_active_2.svg';
import { SimpleHeaderComponent } from '../components';
import GofidButton from '../components/partials/GofidButton';
import { changePassword } from '../api/user';
import { moderateScale, moderateVerticalScale } from "react-native-size-matters";



const SecurityScreen = () => {

    const queryClient = useQueryClient()

    const {mutate,isLoading} = useMutation(changePassword,{
        onSuccess : response => {
            Alert.alert('','Changement de mot de passe réussi')
        },
        onError : error =>{
            Alert.alert('Error','erreur lors de la tentative de modification du mot de passe')
        },
        onSettled : () =>{
            queryClient.invalidateQueries('changePassword')
        }
    })

    const changePasswordValidationSchema = Yup.object().shape({
        currentPassword: Yup.string().required(),
        newPassword: Yup.string().min(6, ({ min }) => `Le mot de passe doit être au moins de ${min} caractères`)
        .required('Mot de passe requis'),
    })

    const [visible , setVisible] = useState(true);

        const handlerPassword=  () => {
            setVisible(!visible);
        }
   
        return (
          <ScrollView style={{ backgroundColor: "white" }}>
            <SimpleHeaderComponent title="Sécurité" />
            <View style={styles.screenContainer}>
              <Text style={styles.title}>Changez votre mot de passe</Text>

              <Formik
                initialValues={{
                    currentPassword : '',
                    newPassword : ''
                }}
                onSubmit={(values) => {
                  mutate(values);
                }}
                validationSchema={changePasswordValidationSchema}
              >
                {({
                  handleChange,
                  setFieldValue,
                  handleBlur,
                  handleSubmit,
                  values,
                  errors,
                }) => (
                  <>
                    <View style={styles.label}>
                      <Text style={styles.labelTxt}>Mot de passe actuel</Text>
                    </View>
                    <View style={styles.inputContainer}>
                      <TextInput
                        type="text"
                        style={styles.inputPassword}
                        placeholder="**********"
                        onChangeText={handleChange('currentPassword')}
                        placeholderTextColor="#174B9D"
                        secureTextEntry={visible}
                      />
                      <TouchableOpacity
                        style={styles.icon}
                        onPress={handlerPassword}
                      >
                        <EyeIcon />
                      </TouchableOpacity>
                    </View>

                    <View style={styles.label}>
                      <Text style={styles.labelTxt}>
                        {" "}
                        Nouveau mot de passe
                      </Text>
                    </View>
                    <View style={styles.inputContainer}>
                      <TextInput
                        type="text"
                        style={styles.inputTxt}
                        placeholder="**********"
                        onChangeText={handleChange('newPassword')}
                        placeholderTextColor="#174B9D"
                        secureTextEntry={true}
                      />
                    </View>
                    {errors.newPassword && (
                        <Text
                          style={{ fontSize: 10, color: "red", marginLeft: 16 }}
                        >
                          {errors.newPassword}
                        </Text>
                      )}

                    <View style={{ marginTop: 250, marginBottom: 50 }}>
                      <GofidButton disabled={isLoading} press={handleSubmit} name="blue" value="Enregistrer" />
                    </View>
                  </>
                )}
              </Formik>
            </View>
          </ScrollView>
        );
    

}


export default SecurityScreen;

const styles = StyleSheet.create({
    screenContainer: {
        flex: 1,
        marginHorizontal: 16,
        height:"100%", 
        alignContent:"center", 
      },
      title:{
        fontFamily: 'MontserratSemiBold',
        fontSize: moderateScale(24),
        color: '#174B9D',
        textAlign: 'left',
        marginTop: 30
      },
      label:{
        alignItems: 'flex-start',
        marginTop: 18,
    },
      labelTxt:{
        fontSize: 14, 
        color:"#174B9D",
        fontFamily: 'HelveticaNeueBold',
        textAlign:'left'
    },
      inputContainer:{
        flexDirection:"row",
        alignItems:'stretch',
        backgroundColor: '#0697DC0A',
        borderWidth:1,
        borderColor:"#0697DC",
        borderRadius: 8,
        marginTop: 6.69,
        height: 50,
        width:'100%',
        alignItems:'center'
    },
      inputTxt:{
        fontSize: 14, 
        fontFamily: 'MontserratMedium',
        textAlign: "left",
        color:'#174B9D',
        height: 50,
        paddingHorizontal: 10,
        paddingVertical:5,
        width:'100%',
    },
    inputPassword:{
        fontSize: 14, 
        fontFamily: 'MontserratMedium',
        textAlign: "left",
        color:'#174B9D',
        height: 50,
        width:'80%',
        paddingHorizontal: 10
    },
    icon:{
        width:'20%',
        alignItems:'center',
    }
      
    
    })