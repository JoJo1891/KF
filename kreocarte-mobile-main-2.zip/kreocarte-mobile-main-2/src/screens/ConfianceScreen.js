import React from "react";
import { Text, View, StyleSheet, TouchableOpacity } from "react-native";
import { ScrollView } from "react-native";

import CAPNordIcon from "../assets/icons/Logo_CAP_Nord_Martinique_result.svg";
import CCIIcon from "../assets/icons/CCI_MARTINIQUE.svg";
import LEuropeIcon from "../assets/icons/l_europe_s_engage.svg";
import LeaderUnionIcon from "../assets/icons/LEADER__union_europea_final (1).svg";
import RepublicFrancaiseIcon from "../assets/icons/republique_francaise_logo.svg";
import NosRualitesIcon from "../assets/icons/nos_ruralites_logo.svg";
import { useNavigation } from "@react-navigation/core";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { windowHeight } from "../themes";
import { GradientComponent } from "../components";

import CollectiviteIcon from "../assets/icons/Logo_Collectivite_Territoriale_de_Martinique.svg";
import { moderateScale } from "react-native-size-matters";

const ConfianceScreen = () => {
  const navigation = useNavigation();

  const storeData = async () => {
    try {
      const bool = "true";
      await AsyncStorage.setItem("slider", bool);
    } catch (e) {
      // saving error
    }
  };

  const pressNext = () => {
    storeData();
    navigation.replace("SelectZoneScreen");
  };

  return (
    <View style={styles.screenContainer}>
      <GradientComponent
        colors={["#E2F2FF", "#FFFFFF"]}
        style={styles.backgroundGradient}
      />

      <View style={styles.screenContainer}>
        <ScrollView style={{ backgroundColor: "white" }}>
          <View style={{ alignItems: "center", marginTop: 55 }}>
            <Text style={styles.pp}>
              Cette application est cofinancée par l’Union Européenne. {`\n\n`}
              L’Europe s’engage en Martinique avec le Fonds Européen Agricole
              pour le Développement Rural (FEADER){`\n\n`}
              L’Europe investit dans les zones rurales.
            </Text>
          </View>

          <View style={styles.iconsRow}>
            <View style={{ width: "50%", paddingHorizontal: 30 }}>
              <CAPNordIcon />
            </View>
            <View style={{ width: "50%" }}>
              <CCIIcon />
            </View>
          </View>

          <View style={styles.iconsRow}>
            <View style={{ width: "50%", paddingHorizontal: 15 }}>
              <LEuropeIcon />
            </View>
            <View style={{ width: "50%", paddingHorizontal: 20 }}>
              <LeaderUnionIcon />
            </View>
          </View>

          <View style={styles.iconsRow}>
            <View style={{ width: "50%", paddingHorizontal: 20 }}>
              <RepublicFrancaiseIcon />
            </View>
            <View style={{ width: "50%", paddingHorizontal: 10 }}>
              <NosRualitesIcon />
            </View>
          </View>

          <View style={{ width: "100%", height: 150, paddingHorizontal: 110 }}>
            <CollectiviteIcon />
          </View>

          <View style={styles.containers}>
            <TouchableOpacity style={styles.button} onPress={pressNext}>
              <Text style={styles.text2}>Suivant</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

export default ConfianceScreen;

const styles = StyleSheet.create({
  screenContainer2: {
    flex: 1,
    backgroundColor: "white",
  },
  screenContainer: {
    position: "absolute",
    top: 0,
    bottom: 0,
    right: 0,
    left: 0,
  },
  containers: {
    flex: 1,
    justifyContent: "flex-end",
    paddingHorizontal: 10,
    marginBottom: 74,
  },
  paragraph: {
    fontFamily: "MontserratRegular",
    fontSize: 16,
    color: "#707070",
    marginBottom: 16,
  },
  iconsRow: {
    width: "100%",
    flex: 1,
    flexDirection: "row",
    height: 130,
  },
  text: {
    fontSize: moderateScale(15),
    color: "#FFFFFF",
    textAlign: "left",
    fontFamily: "Nexa",
    opacity: 0.9,
    marginHorizontal: 16,
    marginTop: 100,
    lineHeight: 22,
    justifyContent: "center",
    height: 140,
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  text2: {
    fontSize: moderateScale(20),
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "MontserratSemiBold",
    alignItems: "center",
  },
  button: {
    width: moderateScale(350),
    textAlign: "center",
    backgroundColor: "#174B9D",
    padding: 10,
    borderRadius: 25,
  },
  pp: {
    fontSize: 15,
    fontFamily: "MontserratRegular",
    color: "#174B9D",
    textAlign: "center",

    fontFamily: "MontserratRegular",
    color: "#174B9D",
  },
});
