import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Alert,
  StyleSheet,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { useMutation, useQueryClient } from 'react-query';

import { setIsLogged, setUser } from '../state/auth';
import {
  authAppleApi,
  authFacebookApi,
  authGoogleApi,
  login,
} from '../api/login';
import EyeIcon from '../assets/icons/eye_icon_white_active.svg';
import Mailcon from '../assets/icons/email_white.svg';
import Securitycon from '../assets/icons/padlock.svg';
import { defaultAuthForm } from '../themes/authPages';
import { ScrollView } from 'react-native';
import GofidIcon from '../assets/icons/gofid_logo_white.svg';
import BackArrowIcon from '../assets/icons/backArrow-white.svg';
import { GradientComponent } from '../components';
import GoogleIcon from '../assets/icons/google_icon.svg';
import AppleIcon from '../assets/icons/apple_logo.svg';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Yup from 'yup';
import { Formik } from 'formik';
import { moderateVerticalScale } from 'react-native-size-matters';
import BouncyCheckbox from 'react-native-bouncy-checkbox';

//For social auth
import * as WebBrowser from 'expo-web-browser';
import * as Google from 'expo-auth-session/providers/google';
import * as AuthSession from 'expo-auth-session';
import Constants from 'expo-constants';
import * as AppleAuthentication from 'expo-apple-authentication';

// CLIENTS ID GOOGLE:

// WEB: 439456010057-haqlprc39c5ea70hqj3ptmnqevqdm01d.apps.googleusercontent.com
// IOS: 439456010057-r5mh2ffihcr3vs8nmr0l0nk595eba7de.apps.googleusercontent.com
// ANDROID: 439456010057-b49gqhpdolh2s2hmvhvtkecsjdsntei2.apps.googleusercontent.com

WebBrowser.maybeCompleteAuthSession();

const LoginScreen = ({ navigation }) => {
  const EXPO_REDIRECT_PARAMS = {
    useProxy: true,
    projectNameForProxy: '@jonitro18/kreocarte',
  };
  const NATIVE_REDIRECT_PARAMS = { native: 'com.whaaat.gofid://' };
  const REDIRECT_PARAMS =
    Constants.appOwnership === 'expo'
      ? EXPO_REDIRECT_PARAMS
      : NATIVE_REDIRECT_PARAMS;
  const redirectUri = AuthSession.makeRedirectUri(REDIRECT_PARAMS);

  const dispatch = useDispatch();
  const queryClient = useQueryClient();
  const [showPassword, setShowPassword] = useState(true);
  const [emailAux, setEmailAux] = useState('');
  const [passwordAux, setPasswordAux] = useState('');
  const [rememberPassword, setRememberPassword] = useState(false);
  const [loadingSocial, setLoadingSocial] = useState(false);
  const [request, response, promptAsync] = Google.useIdTokenAuthRequest({
    clientId:
      '645264247547-sfgv5a54tnkrlp7oks0hhr3qrvt38lt1.apps.googleusercontent.com',
    iosClientId:
      '645264247547-u26h9dqlka5phqrjshislet52qt9hj8e.apps.googleusercontent.com',
    androidClientId:
      '645264247547-7kld5gds4t20njetdf80j0kic82pufu4.apps.googleusercontent.com',
    redirectUri,
  });
  // const [requestFb, responseFb, promptAsyncFb] = Facebook.useAuthRequest(
  //   {
  //     clientId: "850777265941976",
  //     responseType: ResponseType.Token,
  //     redirectUri: AuthSession.makeRedirectUri({ useProxy: true }),
  //   },
  //   { useProxy: true }
  // );

  const getRememberedUser = async () => {
    try {
      const username = await AsyncStorage.getItem('emailGofid');
      const password = await AsyncStorage.getItem('passwordGofid');
      if (username !== null) {
        // We have username!!
        setEmailAux(username);
      }
      if (password !== null) {
        // We have username!!
        setPasswordAux(password);
      }
    } catch (error) {
      // Error retrieving data
    }
  };

  const authGoogleMutation = useMutation('authGoogleApi', authGoogleApi, {
    onSuccess: async (response) => {
      const { token, data } = response;
      await AsyncStorage.setItem('token', token);
      await AsyncStorage.setItem('inscription', 'true');
      dispatch(setIsLogged(true));
      dispatch(setUser(data));
      navigation.navigate('Home');
      setLoadingSocial(false);
    },
    onError: (error) => {
      setLoadingSocial(false);
      Alert.alert(
        "Oups, une erreur s'est produits, veuillez réessayer ultérieurement"
      );
    },
  });

  const authAppleMutation = useMutation('authAppleApi', authAppleApi, {
    onSuccess: async (response) => {
      const { token, data } = response;
      await AsyncStorage.setItem('token', token);
      await AsyncStorage.setItem('inscription', 'true');
      dispatch(setIsLogged(true));
      dispatch(setUser(data));
      navigation.navigate('Home');
      setLoadingSocial(false);
    },
    onError: (error) => {
      setLoadingSocial(false);
      Alert.alert(
        "Oups, une erreur s'est produits, veuillez réessayer ultérieurement"
      );
    },
  });

  const authFacebookMutation = useMutation('authFacebookApi', authFacebookApi, {
    onSuccess: async (response) => {
      const { token, data } = response;
      await AsyncStorage.setItem('token', token);
      await AsyncStorage.setItem('inscription', 'true');
      dispatch(setIsLogged(true));
      dispatch(setUser(data));
      navigation.navigate('Home');
      setLoadingSocial(false);
    },
    onError: (error) => {
      setLoadingSocial(false);
      Alert.alert(
        "Oups, une erreur s'est produits, veuillez réessayer ultérieurement"
      );
    },
  });

  const fetchUserInfo = async () => {
    // let data = await fetch("https://www.googleapis.com/userinfo/v2/me",{
    //   headers: {
    //     Authorization: `Bearer ${accessToken}`
    //   }
    // });
    setLoadingSocial(true);
    // var userJson = jwtDecode(response.params.id_token);
    // console.log(userJson)
    authGoogleMutation.mutate(response.params.id_token);
  };

  useEffect(() => {
    if (response?.type === 'success') {
      fetchUserInfo();
    }
  }, [response]);

  // useEffect(() => {
  //   if (responseFb?.type === "success") {
  //     let { accessToken } = responseFb.authentication;
  //     setLoadingSocial(true);
  //     authFacebookMutation.mutate(accessToken);
  //   }
  // }, [responseFb]);

  useEffect(() => {
    getRememberedUser();
  }, []);

  const rememberPasswordAStorage = async (email, password) => {
    if (rememberPassword) {
      await AsyncStorage.setItem('emailGofid', email);
      await AsyncStorage.setItem('passwordGofid', password);
    } else {
      await AsyncStorage.removeItem('emailGofid');
      await AsyncStorage.removeItem('passwordGofid');
    }
  };

  const { mutate, isLoading } = useMutation(login, {
    onSuccess: async (response) => {
      const { token, data } = response;
      await AsyncStorage.setItem('token', token);
      await AsyncStorage.setItem('inscription', 'true');
      dispatch(setIsLogged(true));
      dispatch(setUser(data));
      navigation.navigate('Home');
    },
    onError: (error) => {
      if (error.message === 'Request failed with status code 401') {
        Alert.alert('Error', 'Email ou mot de passe invalide');
      } else {
        Alert.alert(
          'Error',
          "Oups, une erreur s'est produite, veuillez réessayer"
        );
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries('login');
    },
  });

  const loginValidationSchema = Yup.object().shape({
    email: Yup.string()
      .email('Merci d’entrer une adresse e-mail valable')
      .required(`Merci d'entrer une adresse e-mail valide`),
    password: Yup.string()
      .min(
        6,
        ({ min }) => `Le mot de passe doit être au moins de ${min} caractères`
      )
      .required('Mot de passe requis'),
  });

  const showPasswordHandler = () => {
    if (showPassword) {
      setShowPassword(false);
    } else {
      setShowPassword(true);
    }
  };

  const loginHandler = async (email, password) => {
    mutate({
      email,
      password,
    });
    await rememberPasswordAStorage(email, password);
  };

  const changeH = (e) => {
    console.log(e);
  };

  // async function logInFacebook() {
  //   try {
  //     await Facebook.initializeAsync({
  //       appId: '850777265941976',
  //     });
  //     const { type, token, expirationDate, permissions, declinedPermissions } =
  //       await Facebook.logInWithReadPermissionsAsync({
  //         permissions: ['public_profile','email'],
  //       });
  //     if (type === 'success') {
  //       setLoadingSocial(true);
  //       authFacebookMutation.mutate(token);
  //       // Get the user's name using Facebook's Graph API
  //       // const response = await fetch(`https://graph.facebook.com/me?fields=id,name,email,birthday&access_token=${token}`);
  //       // Alert.alert(`Hi ${(await response.json()).name}! login success, but sorry this service is not available now.`);
  //     } else {
  //       // type === 'cancel'
  //     }
  //   } catch ({ message }) {
  //     setLoadingSocial(false);
  //     alert(`Facebook Login Error: ${message}`);
  //   }
  // }

  return (
    <View style={styles.container}>
      <View style={styles.screenContainer}>
        <GradientComponent
          colors={['#0697DC', '#174B9D']}
          style={styles.backgroundGradient}
        />
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={styles.contentContainer}
        >
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={{ marginStart: 17, marginTop: moderateVerticalScale(40) }}
          >
            <BackArrowIcon />
          </TouchableOpacity>
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              paddingTop: 50,
            }}
          >
            <GofidIcon />
          </View>

          <View style={{ marginTop: 50 }}>
            <Text style={defaultAuthForm.bienvenue}>
              Bonjour! {'\n'}
              Bienvenue,
            </Text>
          </View>

          <View
            style={{
              alignContent: 'center',
              justifyContent: 'center',
              marginTop: 30,
              marginBottom: -20,
            }}
          >
            {loadingSocial ? (
              <>
                <ActivityIndicator size="large" color="#FFFFFF" />
              </>
            ) : (
              <View></View>
            )}
          </View>
          {/*------------------------------------------------GOOGLE AUTH--------------------------------------------  */}
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              marginTop: 40,
              paddingVertical: 10,
              marginVertical: 10,
            }}
          >
            <TouchableOpacity
              style={defaultAuthForm.authButton}
              onPress={() => promptAsync({ showInRevents: true })}
              disabled={isLoading || loadingSocial}
            >
              <View style={{ marginRight: 7 }}>
                <GoogleIcon />
              </View>
              <Text style={defaultAuthForm.authButtText}>Google </Text>
            </TouchableOpacity>
          </View>
          {/*------------------------------------------------FACEBOOK AUTH--------------------------------------------  */}
          {/* {Platform.OS === "ios" && (
            <View
              style={{
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: 10,
              }}
            >
              <TouchableOpacity
                style={defaultAuthForm.authButton}
                onPress={
                  () =>
                    Alert.alert(
                      "Oups, la connexion Facebook est en maintenance."
                    )

                  // promptAsyncFb()
                }
                disabled={isLoading || loadingSocial}
              >
                <View style={{ marginRight: 1 }}>
                  <SocialIcon
                    style={{ width: 30, height: 30 }}
                    type="facebook"
                  />
                </View>
                <Text style={defaultAuthForm.authButtText}>Facebook</Text>
              </TouchableOpacity>
            </View>
          )} */}
          {/*------------------------------------------------APPLE AUTH ONLY FOR IOS--------------------------------------------  */}
          {Platform.OS === 'ios' && (
            <TouchableOpacity
              style={defaultAuthForm.authButton}
              onPress={async () => {
                try {
                  if (isLoading || loadingSocial) return;
                  const credential = await AppleAuthentication.signInAsync({
                    requestedScopes: [
                      AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
                      AppleAuthentication.AppleAuthenticationScope.EMAIL,
                    ],
                  });
                  if (!credential.identityToken)
                    return alert('Error, not apple token found.');
                  setLoadingSocial(true);
                  authAppleMutation.mutate(credential.identityToken);
                  // signed in
                } catch (e) {
                  console.log(e);
                  if (e.code === 'ERR_CANCELED') {
                    // handle that the user canceled the sign-in flow
                  } else {
                    // handle other errors
                  }
                }
              }}
              disabled={isLoading || loadingSocial}
            >
              <View style={{ marginRight: 7 }}>
                <AppleIcon />
              </View>
              <Text style={defaultAuthForm.authButtText}>Apple</Text>
            </TouchableOpacity>
          )}
          <View
            style={{
              marginTop: 35,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Text
              style={{
                fontSize: 24,
                color: 'white',
                fontFamily: 'MontserratRegular',
              }}
            >
              ...ou avec votre email
            </Text>
          </View>

          {/*------------------------------------------------FORM--------------------------------------------  */}

          <Formik
            initialValues={{ email: emailAux, password: passwordAux }}
            onSubmit={(values) => {
              loginHandler(values.email, values.password);
            }}
            validationSchema={loginValidationSchema}
            enableReinitialize={true}
            validateOnChange
          >
            {({
              handleChange = { changeH },
              handleBlur,
              handleSubmit,
              values,
              errors,
            }) => (
              <>
                <View style={defaultAuthForm.inputContainer}>
                  <Mailcon />
                  <TextInput
                    type="text"
                    style={defaultAuthForm.inputTxt}
                    placeholder="Email"
                    placeholderTextColor="#FFFFFF"
                    color="#FFFFFF"
                    name="email"
                    autoCapitalize="none"
                    onChangeText={(text) => handleChange('email')(text.trim())}
                    onBlur={handleBlur('email')}
                    value={values.email}
                  />
                </View>
                {errors.email && (
                  <Text
                    style={{
                      fontSize: moderateVerticalScale(13),
                      color: 'red',
                      marginLeft: 16,
                    }}
                  >
                    {errors.email}
                  </Text>
                )}

                <View style={defaultAuthForm.inputContainer}>
                  <View style={defaultAuthForm.inputTxtPassword}>
                    <Securitycon style={{ width: 5 }} />
                    <TextInput
                      type="text"
                      style={defaultAuthForm.inputTxt}
                      placeholder="Mot de passe"
                      placeholderTextColor="#FFFFFF"
                      color="#FFFFFF"
                      secureTextEntry={showPassword}
                      name="password"
                      onChangeText={handleChange('password')}
                      onBlur={handleBlur('password')}
                      value={values.password}
                    />
                  </View>
                  <TouchableOpacity
                    style={{
                      display: 'flex',
                      marginLeft: 10,
                      width: '10%',
                      marginBottom: 2,
                    }}
                    onPress={showPasswordHandler}
                  >
                    <EyeIcon />
                  </TouchableOpacity>
                </View>
                {errors.password && (
                  <Text
                    style={{
                      fontSize: moderateVerticalScale(13),
                      color: 'red',
                      marginLeft: 16,
                    }}
                  >
                    {errors.password}
                  </Text>
                )}

                <View
                  style={{
                    marginTop: moderateVerticalScale(40),
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <BouncyCheckbox
                    fillColor="#174B9D"
                    iconStyle={{ borderColor: 'white', borderRadius: 5 }}
                    checked={rememberPassword}
                    onPress={() => setRememberPassword(!rememberPassword)}
                  />
                  <Text
                    style={{ color: 'white', fontFamily: 'MontserratLight' }}
                  >
                    Se rappeler de moi
                  </Text>
                </View>

                <View
                  style={{
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginTop: 30,
                    paddingVertical: 10,
                  }}
                >
                  <TouchableOpacity
                    style={defaultAuthForm.authButton}
                    disabled={isLoading || loadingSocial}
                    onPress={handleSubmit}
                  >
                    <Text
                      style={
                        isLoading || loadingSocial
                          ? defaultAuthForm.authButtTextDisabled
                          : defaultAuthForm.authButtText
                      }
                    >
                      Connexion
                    </Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </Formik>

          <TouchableOpacity
            style={styles.endTextContainer}
            onPress={() => navigation.navigate('RegisterScreen')}
          >
            <Text style={styles.endText}>Vous n'êtes pas encore membre ?</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.endTextContainer2}
            onPress={() => navigation.navigate('EmailPasswordScreen')}
          >
            <Text style={styles.endText}>
              Vous avez oublié votre mot de passe ?
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </View>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  endTextContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: moderateVerticalScale(10),
    paddingVertical: moderateVerticalScale(10),
  },
  endTextContainer2: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: moderateVerticalScale(30),
    paddingVertical: moderateVerticalScale(10),
    marginBottom: moderateVerticalScale(200),
  },
  endText: {
    color: 'white',
    fontFamily: 'MontserratRegular',
    fontSize: 16,
  },
  backgroundGradient: {
    width: '100%',
    height: '100%',
    borderColor: '#4DBDF2',
  },
  screenContainer: {
    flex: 1,
    width: '100%',
  },
  container: {
    alignItems: 'center',
    height: '100%',
    width: '100%',
  },
  contentContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
  },
});
