import React ,{useState} from 'react';
import {Text,View, TextInput,  TouchableOpacity, Image} from 'react-native';
import { SocialIcon } from 'react-native-elements'
import Icon from '@expo/vector-icons/AntDesign';
// import DatePicker from 'react-native-date-picker'

import { authInputInsc, defaultAuthForm } from '../themes/authPages';
import { ScrollView } from 'react-native';
import { authBackground } from '../themes/authPages';
import * as Yup from 'yup';
import { Formik } from 'formik';

const ForgotPasswordScreen = () => {

    const [showPassword,setShowPassword] = useState(true);

    const loginValidationSchema = Yup.object().shape({
        email: Yup.string()
          .email("Merci d’entrer une adresse e-mail valable")
          .required('Adresse e-mail est nécessaire'),
          password: Yup.string()
          .min(6, ({ min }) => `Le mot de passe doit être au moins de ${min} caractères`)
          .required('Mot de passe requis'),
          password2: Yup.string()
          .min(6, ({ min }) => `Le mot de passe doit être au moins de ${min} caractères`)
          .required('La confirmation du mot de passe est requise'),
      })

    const showPasswordHandler = () =>{
        if(showPassword){
            setShowPassword(false)
        }else{
            setShowPassword(true)
        } 
    }

    const confirmationHandler = async (email,password,password2) =>{
        console.log(email + "  " + password + "  " + password2);
          
      }
  
   
        return(
            <ScrollView style={{backgroundColor:'white'}}>
            <View style={{height:"100%", alignContent:"center"}}>

                
                 <View style={{alignItems: 'center', paddingTop:50}}>
                     <Image source={require('../assets/gofid_logo_2.png')} style={authBackground.logo_background2} />
                </View>

                <View style={{marginTop:50, marginBottom: 27}}>
                    <Text style={authInputInsc.title}>
                    Mot de passe oublié ?
                    </Text>
                </View>


{/*------------------------------------------------FORM--------------------------------------------  */}

    <Formik initialValues={{ email: '', password: '', password2: ''  }}
                            onSubmit={(values) => {confirmationHandler(values.email,values.password,values.password2)}}
                            validationSchema={loginValidationSchema}
                            >
                    {({ handleChange, handleBlur, handleSubmit, values, errors}) => (  
                <>

                <View style={authInputInsc.label}>
                     <Text style={authInputInsc.labelTxt} 
                            > Email
                     </Text>
                </View>
                <View style={ authInputInsc.inputContainer }>
                    <TextInput 
                        type="text"
                        style={authInputInsc.inputTxt}
                        placeholder="your@mail.com"
                        placeholderTextColor="#174B9D"

                        name="email"
                        onChangeText={handleChange('email')}
                        onBlur={handleBlur('email')}
                        value={values.email}
                    />
                </View>
                {errors.email &&
                    <Text style={{ fontSize: 10, color: 'red', marginLeft:20  }}>{errors.email}</Text>
                }

                <View style={authInputInsc.label}>
                     <Text style={authInputInsc.labelTxt} 
                            > Mot de passe 
                     </Text>
                </View>
                <View style={ authInputInsc.inputContainer }>
                    <TextInput 
                        type="text"
                        style={authInputInsc.inputTxt}
                        placeholder="**********"
                        placeholderTextColor="#174B9D"
                        secureTextEntry={true}

                        name="password"
                        onChangeText={handleChange('password')}
                        onBlur={handleBlur('password')}
                        value={values.password}
                    />
                </View>
                {errors.password &&
                    <Text style={{ fontSize: 10, color: 'red', marginLeft:20 }}>{errors.password}</Text>
                }
                

                <View style={authInputInsc.label}>
                     <Text style={authInputInsc.labelTxt} 
                            > Confirmez le mot de passe
                     </Text>
                </View>
                <View style={ authInputInsc.inputContainer }>
                    <TextInput 
                        type="text"
                        style={authInputInsc.inputTxt}
                        placeholder="**********"
                        placeholderTextColor="#174B9D"
                        secureTextEntry={showPassword}

                        name="password2"
                        onChangeText={handleChange('password2')}
                        onBlur={handleBlur('password2')}
                        value={values.password2}
                    />
                    <TouchableOpacity style={ {display: 'flex', marginLeft: 10, width:'10%', marginBottom:2}} onPress={showPasswordHandler}>
                        <Icon name="eye"  color="#4DBDF2" size={20}/>
                    </TouchableOpacity>
                </View>
                {errors.password2 &&
                    <Text style={{ fontSize: 10, color: 'red', marginLeft:20 }}>{errors.password2}</Text>
                }

                <View 
                 style={{
                    alignItems:"center",
                    justifyContent:"center",
                    marginTop:66,
                    paddingBottom: 100
                  }}>
                    <TouchableOpacity style={authInputInsc.authButton} onPress={handleSubmit}>
                        <Text style={authInputInsc.authButtText}>Enregistrer</Text>
                    </TouchableOpacity>
                </View>

                </>
                )}
      </Formik>
 {/*------------------------------------------------FORM--------------------------------------------  */}


            </View>
            </ScrollView>
        )
    

}


export default ForgotPasswordScreen;