import { useNavigation } from "@react-navigation/native";
import React from "react";
import { Text, View, TouchableOpacity, StyleSheet } from "react-native";
import { ScrollView } from "react-native";
import { SimpleHeaderComponent } from "../components";

const HelpScreen = () => {
  const navigation = useNavigation();

  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <SimpleHeaderComponent title="Aide" />

      <View style={styles.screenContainer}>
        <TouchableOpacity
          style={styles.labelBorder}
          onPress={() => navigation.navigate("FaqsScreen")}
        >
          <Text style={styles.label}>FAQs</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.labelBorder}
          onPress={() => navigation.navigate("WhoWeAreScreen")}
        >
          <Text style={styles.label}>Qui sommes-nous</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.labelBorder}
          onPress={() => navigation.navigate("ProgramesFidelitesScreen")}
        >
          <Text style={styles.label}>Programmes de fidélités</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.labelBorder}
          onPress={() => navigation.navigate("PointsAideScreen")}
        >
          <Text style={styles.label}>Points KréoCarte'</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

export default HelpScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    marginHorizontal: 16,
    alignItems: "center",
    height: "100%",
    alignContent: "center",
    paddingTop: 30,
  },
  labelBorder: {
    alignItems: "center",
    borderColor: "#EBEBEB",
    borderBottomWidth: 1,
    flexDirection: "row",
    width: '100%',
    height: 68.3,
  },
  label: {
    fontFamily: "MontserratSemiBold",
    fontSize: 20,
    color: "#174B9D",
    paddingTop: 21.47,
    paddingBottom: 14.83,
    flexDirection: "row",
    paddingLeft: 8,
  },
});
