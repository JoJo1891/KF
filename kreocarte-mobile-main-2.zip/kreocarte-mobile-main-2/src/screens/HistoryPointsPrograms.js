import React, { useState, useEffect } from "react";
import { View, FlatList, StyleSheet, Text, Alert } from "react-native";

import {
  GradientComponent,
  SimpleHeaderComponent,
  Loader,
} from "../components";
import { windowHeight, windowWidth } from "../themes";
import { useQuery } from "react-query";
import { selectIsLogged } from "../state/auth";
import { useSelector } from "react-redux";
import { getHistoryPrograms } from "../api/user";
import HistoryPointsComponent from "../components/HistoryPointsComponent";

const HistoryPointsPrograms = ({ navigation }) => {
  const isLogged = useSelector(selectIsLogged);
  const [defisData, setData] = useState([]);
  const [isLoaded, setLoaded] = useState(false);

  const { data, isLoading } = useQuery("programsHistory", getHistoryPrograms, {
    onSuccess: (data) => {
      setData(data.reverse());
      setLoaded(true);
    },
    onError: (error) => {
      if (error.message === "Request failed with status code 401") {
        Alert.alert("Error");
      } else {
        Alert.alert("Error");
      }
    },
    cacheTime: 0,
  });

  return (
    <>
      <View style={styles.screenContainer}>
        <GradientComponent
          colors={["#E2F2FF", "#FFFFFF"]}
          style={styles.backgroundGradient}
        />

        <View style={styles.contentContainer}>
          <FlatList
            ListHeaderComponent={
              <View style={styles.headerContainer}>
                <SimpleHeaderComponent title="Historique des Activités" />
              </View>
            }
            ListFooterComponent={<View />}
            ListFooterComponentStyle={{ marginBottom: 40 }}
            data={defisData}
            renderItem={({ item }) => <HistoryPointsComponent {...item} />}
            keyExtractor={(notification) => notification.id}
            showsVerticalScrollIndicator={false}
          />
        </View>
      {!isLoaded && (
        <View
          style={{
            display: "flex",
            width: "100%",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Loader />
        </View>
      )}
      </View>
    </>
  );
};

export default HistoryPointsPrograms;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    justifyContent: "flex-start",
  },
  headerContainer: {
    marginBottom: 20,
  },
  text: {
    marginTop: 30,
    alignItems: "center",
    justifyContent: "center",
  },
  textStyle: {
    fontFamily: "MontserratSemiBold",
    fontSize: 16,
    color: "#174B9D",
  },
});
