import {
  View,
  Alert,
  StyleSheet,
  RefreshControl,
  BackHandler,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import React, { useState, useEffect } from "react";

import {
  StoriesListComponent,
  SearchBarComponent,
  CarouselComponent,
  CustomSwitchComponent,
  VerticalListComponent,
  HomeHeaderComponent,
  GradientComponent,
  ActionButtonComponent,
  HomeListItem,
  StoriesModalComponent,
  ModalComponent,
  ConfirmationModal,
  Loader,
} from "../components";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { selectIsLogged } from "../state/auth";
import { windowHeight } from "../themes";
import { getStores, getStoresAuth } from "../api/store";
import { createCardByStoreId } from "../api/card";
import { moderateVerticalScale } from "react-native-size-matters";
import { getStories, getStoriesauth } from "../api/stories";
import { getSlider } from "../api/slider";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { getUser } from "../api/user";
import {
  selectNewStories,
  setNewStories,
} from "../state/notificationsReceived";

const HomeScreen = ({ navigation }) => {
  const queryClient = useQueryClient();

  const isLogged = useSelector(selectIsLogged);
  const newStories = useSelector(selectNewStories);
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(true);

  const [switchValue, setSwitchValue] = useState(false);
  const getZoneSelected = async () => {
    try {
      const value = await AsyncStorage.getItem("zone");
      if (value == "gonord") {
        setSwitchValue(true);
      } else if (value == "gofid") {
        setSwitchValue(false);
      }
    } catch (e) {
      // return value = false;
    }
  };

  const [modalVisible, setModalVisible] = useState(false);
  const [cardModalVisible, setCardModalVisible] = useState(false);
  const [storeId, setStoreId] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [goNordFilteredList, setGoNordFilteredList] = useState([]);
  const [goFidFilteredList, setGoFidFilteredList] = useState([]);
  const [stories, setStories] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const backAction = () => {
    if (navigation.isFocused()) {
      Alert.alert(
        "Attendez!",
        "Êtes-vous sûr de vouloir quitter l’application ?",
        [
          {
            text: "Annuler",
            onPress: () => null,
            style: "cancel",
          },
          { text: "Oui", onPress: () => BackHandler.exitApp() },
        ]
      );
      return true;
    }
  };

  const backHandler = BackHandler.addEventListener(
    "hardwareBackPress",
    backAction
  );

  useEffect(() => {
    getZoneSelected();
    filterStores(goNordQuery.data, setGoNordFilteredList, searchTerm);
    filterStores(goFidQuery.data, setGoFidFilteredList, searchTerm);
  }, [searchTerm]);

  useEffect(() => {
    if (isLogged) {
      queryClient.refetchQueries("users");
    }
  }, [isLogged]);

  useEffect(() => {
    if (newStories) {
      if (isLogged) {
        queryClient.refetchQueries("storiesAuth");
      } else {
        queryClient.refetchQueries("stories");
      }
      dispatch(setNewStories(false));
    }
  }, [newStories]);

  const getDataTutorial = async () => {
    try {
      const value = await AsyncStorage.getItem("home_tutorial");
      if (value !== null) {
        //console.log(value);
      } else {
        navigation.navigate("HomeTutorialStep1");
      }
    } catch (e) {
      // saving error
    }
  };

  useEffect(() => {
    getDataTutorial();
  }, []);

  const filterStores = (data, setData, searchTerm) => {
    if (!data) return;
    const regex = new RegExp(searchTerm, "i");
    setData(
      data.filter(
        (store) => regex.test(store.nom) || regex.test(store.description)
      )
    );
  };

  const storiesQuery = isLogged
    ? useQuery("storiesAuth", getStoriesauth)
    : useQuery("stories", getStories);

  const sliderQuery = useQuery("slider", getSlider);

  const goNordQuery = isLogged
    ? useQuery("goNordStoresAuth", async () => await getStoresAuth("gonord"), {
        onSuccess: (data) => {
          setGoNordFilteredList(data);
        },
      })
    : useQuery("goNordStores", async () => await getStores("gonord"), {
        onSuccess: (data) => {
          setGoNordFilteredList(data);
        },
      });
  const goFidQuery = isLogged
    ? useQuery("goFidStoresAuth", async () => await getStoresAuth("gofid"), {
        onSuccess: (data) => {
          setGoFidFilteredList(data);
        },
      })
    : useQuery("goFidStores", async () => await getStores("gofid"), {
        onSuccess: (data) => {
          setGoFidFilteredList(data);
        },
      });

  // HACERLE FIX A ESTO PARA CUANDO NO ESTE LOGUEADO, PORQUE SE HARA LA CONSULTA PERO NO EXITOSA POR SER UNA CONSTANT
  const { data } = useQuery(["users"], ({ queryKey }) => getUser(queryKey[1]), {
    cacheTime: 0,
  });

  const onRefresh = () => {
    setRefreshing(true);
    queryClient.refetchQueries("slider");
    if (isLogged) {
      queryClient.refetchQueries("users");
      queryClient.refetchQueries("storiesAuth");
      queryClient.refetchQueries("goNordStoresAuth");
      queryClient.refetchQueries("goFidStoresAuth");
    } else {
      queryClient.refetchQueries("stories");
      queryClient.refetchQueries("goNordStores");
      queryClient.refetchQueries("goFidStores");
    }
    setRefreshing(false);
  };

  const { mutate, isLoading } = useMutation(createCardByStoreId, {
    onSuccess: (data) => {
      if (data.error) {
        Alert.alert(data.error);
      } else {
        navigation.navigate("CardScreen", {
          id: data.id,
        });
      }
      setCardModalVisible(!cardModalVisible);
      queryClient.refetchQueries("goNordStoresAuth");
      queryClient.refetchQueries("goFidStoresAuth");
      queryClient.refetchQueries("getCardsByUser");
    },
    onError: (error) => {
      setCardModalVisible(false);
      Alert.alert("Error", "Quelque chose s'est mal passé");
    },
    onSettled: () => {
      queryClient.invalidateQueries("createCardByStoreId");
    },
  });

  const handleCreateCart = async (storeId) => {
    mutate({
      storeId,
    });
  };

  return (
    <View style={styles.screenContainer}>
      <ModalComponent modalVisible={cardModalVisible}>
        <ConfirmationModal
          value="Voulez-vous ajouter cette carte à votre collection?"
          isLoading={isLoading}
          onSubmit={() => handleCreateCart(storeId)}
          onCancel={() => setCardModalVisible(!cardModalVisible)}
        />
      </ModalComponent>
      <ModalComponent modalVisible={modalVisible} bgType={true}>
        <StoriesModalComponent
          data={stories}
          modalVisible={modalVisible}
          setModalVisible={setModalVisible}
        />
      </ModalComponent>
      <GradientComponent
        colors={["#E2F2FF", "#FFFFFF"]}
        style={styles.backgroundGradient}
      />
      <View style={styles.contentContainer}>
        <VerticalListComponent
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          header={
            <View>
              <View style={styles.headerContainer}>
                <HomeHeaderComponent
                  name="Invite"
                  data={isLogged ? data : null}
                />
              </View>
              {storiesQuery.data && storiesQuery.data.length > 0 && (
                <View style={styles.storiesContainer}>
                  <StoriesListComponent
                    stories={storiesQuery.data}
                    setStories={setStories}
                    isLoading={storiesQuery.isLoading}
                    modalVisible={modalVisible}
                    setModalVisible={setModalVisible}
                  />
                </View>
              )}
              <View style={styles.searchBarContainer}>
                <SearchBarComponent onChange={setSearchTerm} />
              </View>
              {!searchTerm && sliderQuery.data && (
                <View style={styles.carouselContainer}>
                  <CarouselComponent data={sliderQuery.data} />
                </View>
              )}
              <View style={styles.switchContainer}>
                <CustomSwitchComponent
                  title1="Go Nord"
                  title2="Kréocarte'"
                  value={switchValue}
                  onChange={setSwitchValue}
                />
              </View>
              {switchValue && goNordQuery.isLoading && (
                <View style={{ flex: 1, marginTop: moderateVerticalScale(30) }}>
                  <Loader />
                </View>
              )}
              {!switchValue && goFidQuery.isLoading && (
                <View style={{ flex: 1, marginTop: moderateVerticalScale(30) }}>
                  <Loader />
                </View>
              )}
            </View>
          }
          columns={2}
          data={switchValue ? goNordFilteredList : goFidFilteredList}
          extraData={switchValue ? goNordFilteredList : goFidFilteredList}
          ItemComponent={(item) => (
            <HomeListItem
              {...item}
              onPress={() => {
                if (!isLogged) {
                  navigation.navigate("LoginScreen");
                  return;
                }
                if (item.has_card) {
                  navigation.navigate("CardScreen", {
                    id: item.card_id,
                  });
                } else {
                  setStoreId(item.id);
                  setCardModalVisible(!cardModalVisible);
                }
              }}
            />
          )}
        />
        {isLogged && <ActionButtonComponent />}
      </View>
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  headerContainer: {
    marginTop: 15,
  },
  storiesContainer: {
    flexDirection: "row",
  },
  searchBarContainer: {
    marginTop: 20,
    height: windowHeight / 17,
    marginHorizontal: 15,
    marginBottom: 20,
  },
  carouselContainer: {},
  switchContainer: {
    height: windowHeight / 16,
    marginHorizontal: 15,
  },
  verticalListContainer: {
    marginTop: 10,
    marginHorizontal: 5,
    marginBottom: 10,
  },
});
