import React, { useEffect, useState } from 'react';

import {
  View,
  StyleSheet,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  RefreshControl,
} from 'react-native';

import {
  CardCarouselComponent,
  GradientComponent,
  StoreHeaderComponent,
  CustomButtonComponent,
  StoreInfoComponent,
  ModalComponent,
  StoreInfoModal,
  Loader,
  FidelityListComponent,
  GameShopListComponent,
  ConfirmationModal,
} from '../components';
import { windowHeight, windowWidth } from '../themes';
import {
  moderateScale,
  moderateVerticalScale,
} from 'react-native-size-matters';
import CatalogIcon from '../assets/icons/catalogue_icon.svg';
import AdventagesIcon from '../assets/icons/advantages-icon.svg';
import MedalIcon from '../assets/icons/medal_big.svg';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { deleteCard, getCard } from '../api/card';
import Barcode from '@kichiyaki/react-native-barcode-generator';

const CardScreen = ({ route, navigation }) => {
  const { id } = route.params;
  const queryClient = useQueryClient();
  const [cardState, setCardState] = useState(0);
  const [cardType, setCardType] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [deleteCardModal, setDeleteCardModal] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [stamps, setStamps] = useState([]);

  const getDataTutorial = async () => {
    try {
      const value = await AsyncStorage.getItem('cards_tutorial');
      if (value !== null) {
        //alert(value);
      } else {
        navigation.navigate('CardScreenTurorial1');
      }
    } catch (e) {
      // saving error
    }
  };

  const { data, isLoading } = useQuery(
    ['card', id],
    ({ queryKey }) => getCard(queryKey[1]),
    {
      cacheTime: 0,
    }
  );

  function completeStampons() {
    let arr = [];
    if (data?.point_fidelite) {
      for (let x = 0; x < data.point_fidelite; x++) {
        arr.push({ type: '1' });
      }
      return arr;
    }
  }

  const onRefresh = () => {
    setRefreshing(true);
    queryClient.refetchQueries(['card', id]);
    setRefreshing(false);
  };

  const deleteCardMutation = useMutation(deleteCard, {
    onSuccess: (response) => {
      setDeleteCardModal(!deleteCardModal);
      queryClient.refetchQueries('goNordStoresAuth');
      queryClient.refetchQueries('goFidStoresAuth');
      queryClient.refetchQueries('getCardsByUser');
      navigation.navigate('HomeScreen');
    },
    onError: (error) => {
      setDeleteCardModal(false);
      Alert.alert(
        'Error',
        'Erreur lors de la tentative de suppression de la carte'
      );
    },
    onSettled: () => {
      queryClient.invalidateQueries('deleteCard');
    },
  });

  useEffect(() => {
    getDataTutorial();
    //console.log(data)
  }, []);

  return (
    <View style={styles.screenContainer}>
      {!isLoading && (
        <ModalComponent modalVisible={modalVisible}>
          <StoreInfoModal
            data={data?.enseigne}
            onClose={() => setModalVisible(!modalVisible)}
          />
        </ModalComponent>
      )}
      <ModalComponent modalVisible={deleteCardModal}>
        <ConfirmationModal
          value="voulez-vous supprimer votre carte ?"
          type="inverse"
          isLoading={deleteCardMutation.isLoading}
          onSubmit={() => setDeleteCardModal(!deleteCardModal)}
          onCancel={() => deleteCardMutation.mutate({ id })}
        />
      </ModalComponent>
      <GradientComponent
        colors={['#E2F2FF', '#FFFFFF']}
        style={styles.backgroundGradient}
      />
      <View style={styles.contentContainer}>
        <ScrollView
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        >
          <View style={styles.headerContainer}>
            <StoreHeaderComponent
              name={data ? data?.enseigne.nom : ''}
              imageUrl={data ? data?.enseigne.image_url : null}
              status={data ? data?.enseigne.type_carte : ''}
            />
          </View>
          {!isLoading && (
            <View style={{ flex: 1 }}>
              {data?.enseigne?.status === 'VALIDE' && (
                <View>
                  {/*----------------------------------------------------------- CASHBACK CARD CASE ------------------------------------------------------  */}
                  {data?.enseigne?.type_carte == 'CASHBACK' && (
                    <View
                      style={[styles.cashContainer, styles.marginHorizontal]}
                    >
                      <View style={styles.cashInfo}>
                        <Text
                          style={[
                            styles.textBold,
                            styles.blueText,
                            styles.gains,
                          ]}
                        >
                          Gains
                        </Text>
                        <Text
                          style={[
                            styles.textBold,
                            styles.blueText,
                            styles.amount,
                          ]}
                        >
                          {`${
                            data?.point_fidelite_total
                              ? data?.point_fidelite_total
                              : 0
                          }€`}
                        </Text>
                      </View>

                      <View>
                        <CustomButtonComponent
                          type="round-primary"
                          value="Utiliser mon cashback"
                          onPress={() =>
                            navigation.navigate('CashBackScreen', {
                              cardId: id,
                              currentAmount: data?.point_fidelite_total
                                ? data?.point_fidelite_total
                                : 0,
                            })
                          }
                        />
                      </View>
                    </View>
                  )}

                  {/*----------------------------------------------------------- TAMPONS CARD CASE ------------------------------------------------------  */}
                  {data?.enseigne?.type_carte == 'TAMPONS' && (
                    <View>
                      <FidelityListComponent
                        rewards={data?.point_fidelite ? completeStampons() : []}
                        maxItem={data?.treshold || 6}
                      />
                    </View>
                  )}

                  {/*----------------------------------------------------------- POINTS CARD CASE ------------------------------------------------------  */}
                  {data?.enseigne?.type_carte == 'POINTS' && (
                    <View>
                      <View style={{ alignItems: 'center' }}>
                        <GameShopListComponent
                          rewards={data?.point_fidelite || 0}
                          maxItem={data?.treshold || 2}
                        />
                      </View>
                    </View>
                  )}
                </View>
              )}

              <TouchableOpacity
                onPress={() => setModalVisible(!modalVisible)}
                style={[styles.infoContainer, styles.marginHorizontal]}
              >
                <StoreInfoComponent card={data} />
              </TouchableOpacity>
              {/* <TouchableOpacity activeOpacity={1} onLongPres={()=>setDeleteCardModal(!deleteCardModal)}> */}
              <View style={styles.cardCarouselContainer}>
                <CardCarouselComponent
                  handleDeleteCard={() => setDeleteCardModal(!deleteCardModal)}
                  card={data}
                  onChange={setCardState}
                />
              </View>
              {data?.enseigne?.status !== 'VALIDE' && (
                <View style={styles.barCodeContainer}>
                  <Barcode value={data?.numero_carte.toString() || ' '} />
                  <Text style={styles.barCode}>{data?.numero_carte || ''}</Text>
                </View>
              )}

              {/* </TouchableOpacity> */}
              {cardState === 0 && (
                <TouchableOpacity
                  onPress={() =>
                    navigation.navigate('CatalogScreen', {
                      id: data?.enseigne?.id,
                    })
                  }
                >
                  <View style={styles.rewardItemContainer}>
                    <View style={styles.rewardIcon}>
                      <CatalogIcon width={moderateScale(70)} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text
                        style={[
                          styles.textSemiBold,
                          styles.rewardTitle,
                          styles.blueText,
                        ]}
                      >
                        Catalogue
                      </Text>
                      <Text
                        style={[
                          styles.textRegular,
                          styles.rewardDescription,
                          styles.grayText,
                        ]}
                      >
                        Découvrez le catalogue de votre commerçant.
                      </Text>
                    </View>
                  </View>
                </TouchableOpacity>
              )}
              {cardState === 1 && (
                <View style={styles.rewardContainer}>
                  <TouchableOpacity
                    onPress={() =>
                      navigation.navigate('AdvantagesScreen', {
                        id,
                      })
                    }
                    style={styles.rewardItemContainer}
                  >
                    <View style={styles.rewardIcon}>
                      <AdventagesIcon width={moderateScale(70)} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text
                        style={[
                          styles.textSemiBold,
                          styles.rewardTitle,
                          styles.blueText,
                        ]}
                      >
                        Avantages
                      </Text>
                      <Text
                        style={[
                          styles.textRegular,
                          styles.rewardDescription,
                          styles.grayText,
                        ]}
                      >
                        Découvrez tous les avantages qu’offre votre commerçant
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() =>
                      navigation.navigate('BonusPlansScreen', {
                        id,
                      })
                    }
                    style={styles.rewardItemContainer}
                  >
                    <View style={styles.rewardIcon}>
                      <MedalIcon width={moderateScale(60)} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text
                        style={[
                          styles.textSemiBold,
                          styles.rewardTitle,
                          styles.blueText,
                        ]}
                      >
                        Bons plans
                      </Text>
                      <Text
                        style={[
                          styles.textRegular,
                          styles.rewardDescription,
                          styles.grayText,
                        ]}
                      >
                        Découvrez les bons plans qu’offre votre commerçant
                      </Text>
                    </View>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}
        </ScrollView>
      </View>
      {isLoading && (
        <View
          style={{
            display: 'flex',
            width: '100%',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <Loader />
        </View>
      )}
    </View>
  );
};

export default CardScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: 'white',
  },
  headerContainer: {
    marginTop: 0,
    height: moderateVerticalScale(110),
  },
  contentContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  cashContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  infoContainer: {
    marginTop: 25,
  },
  marginHorizontal: {
    marginHorizontal: 15,
  },
  cashInfo: {
    alignItems: 'center',
  },
  gains: {
    fontSize: moderateScale(17),
  },
  amount: {
    fontSize: moderateScale(35),
  },
  blueText: {
    color: '#174B9D',
  },
  cardCarouselContainer: {
    marginTop: 20,
  },
  text: {
    fontFamily: 'MontserratRegular',
  },
  textBold: {
    fontFamily: 'MontserratBold',
  },
  textSemiBold: {
    fontFamily: 'MontserratSemiBold',
  },
  textRegular: {
    fontFamily: 'MontserratRegular',
  },
  rewardContainer: {
    marginBottom: 30,
  },
  rewardItemContainer: {
    height: windowHeight / 4.5,
    marginHorizontal: 15,
    marginTop: 20,
    borderWidth: 2,
    borderColor: '#FBBF16',
    borderRadius: 15,
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 10,
    alignItems: 'center',
  },
  rewardIcon: {
    marginRight: 10,
  },
  rewardTitle: {
    fontSize: moderateScale(20),
  },
  rewardDescription: {
    fontSize: moderateScale(14),
  },
  grayText: {
    color: '#7D7D7D',
  },
  barCodeContainer: {
    alignItems: 'center',
  },
  barCode: {
    fontFamily: 'MontserratRegular',
    fontSize: moderateScale(17),
    letterSpacing: moderateScale(10),
  },
});
