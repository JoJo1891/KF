import React, { useEffect, useState } from "react";

import { View, Text, StyleSheet } from "react-native";
import { verticalScale } from "react-native-size-matters";
import { useQuery } from "react-query";
import { getRewards } from "../api/rewards";

import {
  VerticalListComponent,
  SimpleHeaderComponent,
  RewardListItem,
  ModalComponent,
  BonusPlanModal,
  Loader
} from "../components";
import { windowHeight } from "../themes";

const BonusPlansScreen = ({ navigation, route }) => {
  const { id } = route.params 
  const [modalVisible, setModalVisible] = useState(false);
  const [reward,setReward] = useState(null)
  const [recompenses,setRecompenses] = useState([]);



  const { data ,isLoading } = useQuery(["bonusPlans", id], ({ queryKey }) => getRewards(queryKey[1]),{
      cacheTime : 0
    }
);

  return (
    <View style={styles.screenContainer}>
      <ModalComponent modalVisible={modalVisible}>
        <BonusPlanModal
          data={reward}
          onClose={() => {
            setModalVisible(!modalVisible);
            navigation.goBack();
          }}
        />
      </ModalComponent>
      <VerticalListComponent
        header={
          <View>
            <SimpleHeaderComponent title="Bons plans" />
            {!isLoading && <View style={styles.descriptionContainer}>
              <Text style={styles.description}>
              Choisissez le Bon Plan que vous souhaitez débloquer et cliquez sur le bouton "Utiliser".
              </Text>
            </View>}
            {isLoading && <View style={styles.loaderContainer}>
              <Loader/>  
            </View>}
          </View>
        }
        ItemComponent={(item) => (
          <RewardListItem
            onPress={() => {
              setReward(item);
              setModalVisible(!modalVisible);
            }}
            type={"gift"}
            recompense={item}
            card_id={id}
          />
        )}
        data={data}
        extraData={data}
        columns={3}
      />
    </View>
  );
};

export default BonusPlansScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
  },
  listContainer: {
    marginTop: 20,
  },
  descriptionContainer: {
    marginTop: 20,
    marginBottom:10,
    marginHorizontal: 15,
  },
  description: {
    fontFamily: "MontserratRegular",
    color: "#7D7D7D",
    fontSize: 14,
  },
  loaderContainer :{
    marginTop : verticalScale(windowHeight/2-100)
  }
});
