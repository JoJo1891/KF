import React, { useState, useEffect } from 'react';

import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { CameraView, Camera } from 'expo-camera';
import {
  moderateScale,
  moderateVerticalScale,
} from 'react-native-size-matters';
import { useMutation, useQueryClient } from 'react-query';

import {
  BonusPlanModal,
  Loader,
  ModalComponent,
  SimpleHeaderComponent,
} from '../components';
import ScannerIcon from '../assets/icons/scan_qr_serial_icon.svg';

import Selector from '../assets/icons/selector_guide.svg';
import { useBonPlanScanning } from '../api/rewards';

const ScannerBPScreen = ({ navigation, route }) => {
  const [hasPermission, setHasPermission] = useState(null);
  const [scanned, setScanned] = useState(false);
  const [gift, setGift] = useState({});
  const [modalVisible, setModalVisible] = useState(false);
  const queryClient = useQueryClient();
  const [cardIdScanned, setId] = useState(0);

  const { isBonPlan, idBonPlan, cardId } = route?.params || {
    idBonPlan: 0,
    cardId: 0,
    isBonPlan: false,
  };

  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, []);

  const { mutate, isLoading } = useMutation(
    'useBonPlanScanning',
    useBonPlanScanning,
    {
      onSuccess: (response) => {
        //console.log(response)
        if (response.status === 'UTILISE') {
          Alert.alert('Félicitations', 'Utilisé avec succès.', [
            {
              text: 'Ok',
              onPress: () => navigation.navigate('Home'),
            },
          ]);
        }
      },
      onError: (error) => {
        if (error.message === 'Request failed with status code 400') {
          Alert.alert('Error', 'Récompense utilisée.');
        } else {
          Alert.alert('Error ');
        }
      },
      onSettled: () => {
        queryClient.invalidateQueries('useBonPlanScanning');
      },
    }
  );

  const apiHandler = (id) => {
    mutate(id);
  };

  const handlerSuccess = () => {
    navigation.navigate('HomeScreen');
  };

  const handleBarCodeScanned = ({ type, data }) => {
    //console.log(data + " "+type)
    setScanned(true);
    //console.log(data)

    //When is scanning a bon blan
    if (isBonPlan) {
      if (data.startsWith('[{"id":') || data.startsWith('[{"qrcode":')) {
        if (idBonPlan && cardId) {
          apiHandler(idBonPlan);
        } else {
          alert('Error: Incorrect Qr code.');
        }
      } else {
        alert('Error: Incorrect Qr code.');
      }
    }
  };

  if (hasPermission === null) {
    return (
      <View style={styles.previewScreen}>
        <Text>Requesting for camera permission</Text>
      </View>
    );
  }

  if (hasPermission === false) {
    Alert.alert(
      'Accès Refusé',
      "L'application KréoCarte doit accéder à votre appareil photo pour que vous puissiez scanner le code Qr.",
      [
        {
          text: 'Ok',
          onPress: () => handlerSuccess(),
        },
      ]
    );
  }

  return (
    <View style={styles.screenContainer}>
      <ModalComponent modalVisible={modalVisible}>
        <BonusPlanModal
          data={gift}
          card_id={cardIdScanned}
          onClose={() => {
            setModalVisible(!modalVisible);
          }}
        />
      </ModalComponent>
      <CameraView
        onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
        style={StyleSheet.absoluteFillObject}
      />
      <View style={styles.contentContainer}>
        <View style={styles.headerContainer}>
          <SimpleHeaderComponent tintColor="white" title="Scan Bon Plan" />
        </View>

        <View style={styles.selectorContainer}>
          {isLoading ? (
            <>
              <Loader />
            </>
          ) : (
            <Selector />
          )}
        </View>

        <TouchableOpacity
          onPress={() => setScanned(false)}
          style={styles.scannerButton}
        >
          <ScannerIcon />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ScannerBPScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
  },
  contentContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'space-between',
  },
  previewScreen: {
    flex: 1,
    justifyContent: 'center',
    alignContent: 'center',
  },
  headerContainer: {},
  scannerButton: {
    backgroundColor: '#174B9D',
    padding: 15,
    width: moderateScale(70),
    height: moderateVerticalScale(70),
    borderRadius: moderateScale(70),
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    marginBottom: moderateVerticalScale(100),
  },
  selectorContainer: {
    alignContent: 'center',
    alignItems: 'center',
  },
});
