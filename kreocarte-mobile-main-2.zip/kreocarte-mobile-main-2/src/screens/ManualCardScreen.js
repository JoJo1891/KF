import React, { useEffect, useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

import {
  SimpleHeaderComponent,
  CustomInputComponent,
  CustomButtonComponent,
} from '../components';
import CardIcon from '../assets/icons/card-blue.svg';
import {
  moderateScale,
  moderateVerticalScale,
} from 'react-native-size-matters';
import { getStoresWithoutCards } from '../api/store';
import { createCardManually } from '../api/card';
import * as Yup from 'yup';
import { Formik } from 'formik';
import { AutocompleteDropdown } from 'react-native-autocomplete-dropdown';

const ManualCardScreen = ({ route, navigation }) => {
  const idScanned = route.params?.id || '';

  const queryClient = useQueryClient();

  const { data, isLoading } = useQuery(
    'getStoresWithoutCards',
    getStoresWithoutCards,
    { initialData: [], cacheTime: 0 }
  );

  const createCardMutation = useMutation(createCardManually, {
    onSuccess: (response) => {
      navigation.navigate('CardSuccessScreen', { id: response.id });
    },
    onError: (error) => {
      navigation.navigate('CardErrorScreen');
    },
    onSettled: () => {
      queryClient.invalidateQueries('createCardManually');
    },
  });

  const createCardValidationSchema = Yup.object().shape({
    storeId: Yup.string().required('Sélectionner une carte'),
    cardNumber: Yup.string().required('Un id de carte est requis'),
    //.matches(/^[0-9]*$/,{message : 'Seulement les chiffres'})
  });

  const [suggestionsList, setSuggestionsList] = useState(null);

  const getSuggestions = (q) => {
    const filterToken = q.toLowerCase();
    if (typeof q !== 'string') {
      setSuggestionsList(null);
      return;
    }
    const suggestions = data
      .filter((item) => item.name.toLowerCase().includes(filterToken))
      .sort((a, b) => {
        if (a.name > b.name) {
          return 1;
        }
        if (a.name < b.name) {
          return -1;
        }
        return 0;
      })
      .map((item) => ({
        id: item.id,
        title: item.name,
      }));

    setSuggestionsList(suggestions);
  };

  useEffect(() => {
    getSuggestions('');
  }, [data]);

  return (
    <>
      <View style={styles.screenContainer}>
        <ScrollView
          nestedScrollEnabled={true}
          keyboardShouldPersistTaps="never"
        >
          <SimpleHeaderComponent title="Cartes Importées" />
          <View style={styles.cardIcon}>
            <CardIcon />
          </View>
          <Formik
            initialValues={{ storeId: '', cardNumber: idScanned }}
            onSubmit={(values) => {
              createCardMutation.mutate({
                storeId: parseInt(values.storeId),
                cardNumber: values.cardNumber,
              });
            }}
            validationSchema={createCardValidationSchema}
          >
            {({
              handleChange,
              setFieldValue,
              handleBlur,
              handleSubmit,
              values,
              errors,
            }) => (
              <>
                <View style={[styles.nameInput, styles.searchBarStyle]}>
                  <AutocompleteDropdown
                    clearOnFocus={false}
                    closeOnBlur={true}
                    showClear={false}
                    onSelectItem={(item) =>
                      setFieldValue('storeId', item?.id ? item?.id : null)
                    }
                    dataSet={suggestionsList}
                    onChangeText={getSuggestions}
                    ignoreAccents
                    useFilter={false} // set false to prevent rerender twice
                    emptyResultText="Aucun résultat trouvé"
                    textInputProps={{
                      placeholder: 'Sélectionner une carte',
                      style: {
                        backgroundColor: '#FFF',
                        color: '#174B9D',
                      },
                    }}
                    rightButtonsContainerStyle={{
                      backgroundColor: '#FFF',
                    }}
                    inputContainerStyle={{
                      backgroundColor: '#FFF',
                    }}
                  />
                </View>
                {errors.storeId && (
                  <Text style={{ fontSize: 10, color: 'red', marginLeft: 16 }}>
                    {errors.storeId}
                  </Text>
                )}

                <View style={styles.cardNumberInput}>
                  <Text style={styles.inputLabel}>Numéro de carte</Text>
                  <CustomInputComponent
                    keyboardType="text"
                    onChange={handleChange('cardNumber')}
                    value={values.cardNumber}
                  />
                </View>
                {errors.cardNumber && (
                  <Text style={{ fontSize: 10, color: 'red', marginLeft: 16 }}>
                    {errors.cardNumber}
                  </Text>
                )}
                <View style={styles.buttonContainer}>
                  <CustomButtonComponent
                    disabled={createCardMutation.isLoading}
                    value="Ajouter la carte"
                    onPress={handleSubmit}
                  />
                </View>
              </>
            )}
          </Formik>
        </ScrollView>
      </View>
    </>
  );
};

export default ManualCardScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: 'white',
    paddingTop: 20,
  },
  cardIcon: {
    alignSelf: 'center',
    marginTop: moderateVerticalScale(-40),
  },
  nameInput: {
    justifyContent: 'center',
    overflow: 'hidden',
    marginHorizontal: 15,
    padding: 5,
    marginTop: moderateVerticalScale(60),
  },
  cardNumberInput: {
    marginHorizontal: 15,
    marginTop: moderateVerticalScale(20),
  },
  inputLabel: {
    color: '#174B9D',
    fontFamily: 'HelveticaNeueBold',
    fontSize: moderateScale(15),
  },
  buttonContainer: {
    marginHorizontal: 15,
    marginTop: moderateVerticalScale(150),
  },
  searchBarStyle: {
    borderWidth: 1,
    borderColor: '#0697DC',
    borderRadius: 8,
  },
  selectorStyles: {
    backgroundColor: 'white',
    elevation: 0,
    borderColor: 'white',
  },
});
