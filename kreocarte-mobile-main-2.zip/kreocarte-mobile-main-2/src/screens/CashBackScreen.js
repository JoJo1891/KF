import React, { useState } from "react";
import { useMutation, useQueryClient } from "react-query";
import * as Yup from "yup";
import { Formik } from "formik";
import { View, TextInput, StyleSheet, Text, Alert, ScrollView } from "react-native";

import { CheckBox } from 'react-native-elements';
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";

import {
  SimpleHeaderComponent,
  GradientComponent,
  CustomButtonComponent,
} from "../components";
import { windowHeight } from "../themes";
import { createCashBackCode } from "../api/card";
import BouncyCheckbox from "react-native-bouncy-checkbox";

const CashBackScreen = ({ navigation, route }) => {
  const { cardId, currentAmount } = route.params;

  const queryClient = useQueryClient();
  const [isSelected, setSelection] = useState(false);

  const chashBackValidationSchema = Yup.object().shape({
    amount: Yup.number('Le montant doit être un nombre')
      .required('Indiquer une somme'),
  })

  const addSpaceToCode = (code, space) => {
    let codeSpace = "";
    const length = code.length;
    for (let i = 0; i < length; i += space) {
        if (i + space < length) {
          codeSpace += code.substring(i, i + space) + ' ';
        } else {
          codeSpace += code.substring(i, length);
        }
    }
    return codeSpace;
}

  const { mutate, isLoading } = useMutation(createCashBackCode,{
    onSuccess : data =>{
      navigation.navigate('CashBackCodeScreen',{
        id:data.id,
        cardId,
        urlCode : data.qr_code_url,
        code : addSpaceToCode(data.code.toString(), 1) ,
        recompense : data.recompense
      })
    },
    onError : error => {
      Alert.alert("Error","Quelque chose s'est mal passé")
    },
    onSettled : ()=>{
      queryClient.invalidateQueries('createCashBackCode')
    }
  });

  const submitHandler = ({amount}) =>{
    if(parseInt(amount) > 0 && parseInt(amount) <= currentAmount){
    mutate({
      cardId,
      amount
    })
    }else if( parseInt(amount) > currentAmount) {
      Alert.alert("Il n'est pas possible d'entrer plus que ce qui est disponible.")
    }else if( parseInt(amount) < 1){
          Alert.alert("Vous devez racheter un minimum de 1€.")
      }
  }

  return (
    <View style={styles.screenContainer}>
      <GradientComponent
        colors={["#E2F2FF", "#FFFFFF"]}
        style={styles.backgroundGradient}
      />
      <View style={styles.contentContainer}>
        <ScrollView>
          <View style={styles.headerContainer}>
            <SimpleHeaderComponent title="Cashback" />
          </View>
          <View style={styles.cashBackIconContainer}></View>
          <Formik
            initialValues={{amount : ''}}
            onSubmit={ submitHandler}
            validationSchema={chashBackValidationSchema}
          >
            {({handleChange,handleSubmit,handleBlur,setValues,values,errors}) => (
              <>
                <View style={styles.amounInputContainer}>
                  <TextInput
                    value={values.amount.toString()}
                    keyboardType="numeric"
                    onChangeText={handleChange('amount')}
                    onBlur={handleBlur("amount")}
                    placeholder='0'
                    placeholderTextColor={"#174B9D"}
                    style={[styles.text, styles.textInput]}
                  />
                  <Text style={[styles.text, styles.euro]}>€</Text>
                  
                </View>
                {errors.amount &&
                    <Text style={{ fontSize: moderateScale(14), color: 'red',marginLeft : moderateScale(60),marginTop:10}}>{errors.amount}</Text>
                }
                <Text style={styles.or}>ou</Text>

                <View style={styles.checkboxContainer}>
                  <BouncyCheckbox
                    fillColor="#174B9D"
                    iconStyle={{ borderColor: "#174B9D" , borderRadius: 5}}
                    checked={isSelected}
                    onPress={(value) => {
                      if(!isSelected){
                        setSelection(true)
                        values.amount = currentAmount
                      }else{
                        setSelection(false)
                        values.amount = ''
                      }}
                    }
                  />
                  <Text style={[styles.text, styles.label]}>
                    Utiliser tout votre cashback
                  </Text>
                </View>

                <View style={styles.buttonContainer}>
                <CustomButtonComponent
                  disabled={isLoading}
                  type="round-primary"
                  value="Cashback"
                  onPress={handleSubmit}
                  // onPress={() => navigation.navigate("CashBackCodeScreen")}
                />
              </View>
              </>
            )}
          </Formik>
        </ScrollView>
      </View>
    </View>
  );
};

export default CashBackScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  cashBackIconContainer: {
    marginTop: moderateVerticalScale(200),
  },
  backgroundGradient: {
    height: windowHeight / 1.2,
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
  },
  amounInputContainer: {
    marginHorizontal: moderateScale(60),
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#4DBDF2",
    flexDirection: "row",
    paddingHorizontal: 15,
    paddingVertical: 15,
    justifyContent: "center",
  },
  text: {
    color: "#174B9D",
    fontFamily: "MontserratSemiBold",
  },
  or: {
    color: "#7D7D7D",
    fontFamily: "MontserratRegular",
    fontSize: moderateScale(15),
    alignSelf: "center",
    marginTop: moderateVerticalScale(10),
  },
  textInput: {
    fontSize: moderateScale(40),
    textAlign: "right",
    flexDirection: "column",
    width:'60%',
  },
  euro: {
    fontSize: moderateScale(25),
    flexDirection: "column",
    width:'40%',
    textAlign:'left',
    alignSelf: "center",
  },
  checkboxContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: 15,
  },
  label: {
    fontSize: moderateScale(18),
  },
  buttonContainer: {
    marginHorizontal: 15,
    marginTop: moderateVerticalScale(150),
  },
});
