import React from "react";
import { Text, View, TextInput, TouchableOpacity, Image } from "react-native";
import { SocialIcon } from "react-native-elements";
import Icon from "@expo/vector-icons/AntDesign";

import { authInputInsc, defaultAuthForm } from "../themes/authPages";
import { ScrollView } from "react-native";
import { authBackground } from "../themes/authPages";

const InscriptionScreen = () => {
  return (
    <ScrollView>
      <View style={{ height: "100%", alignContent: "center;" }}>
        <View style={{ alignItems: "center", paddingTop: 50 }}>
          <Image
            source={require("../assets/gofid_logo_2.png")}
            style={authBackground.logo_background2}
          />
        </View>

        <View style={{ marginTop: 50, marginBottom: 27 }}>
          <Text style={authInputInsc.title}>Complétez votre inscription</Text>
        </View>

        <View style={authInputInsc.label}>
          <Text style={authInputInsc.labelTxt}> Nom complet</Text>
        </View>
        <View style={authInputInsc.inputContainer}>
          <TextInput
            type="text"
            style={authInputInsc.inputTxt}
            placeholder="Gabrielle"
            placeholderTextColor="#174B9D"
          />
        </View>

        <View style={authInputInsc.label}>
          <Text style={authInputInsc.labelTxt}> Date de naissance</Text>
        </View>
        <View style={authInputInsc.inputContainer}>
          <TextInput
            type="text"
            style={authInputInsc.inputTxt}
            placeholder="24 December 2020"
            placeholderTextColor="#174B9D"
          />
          <Icon name="calendar" color="#FFFFFF" size={20} />
        </View>

        <View style={authInputInsc.label}>
          <Text style={authInputInsc.labelTxt}> Email</Text>
        </View>
        <View style={authInputInsc.inputContainer}>
          <TextInput
            type="text"
            style={authInputInsc.inputTxt}
            placeholder="your@mail.com"
            placeholderTextColor="#174B9D"
          />
        </View>

        <View style={authInputInsc.label}>
          <Text style={authInputInsc.labelTxt}> Mot de passe</Text>
        </View>
        <View style={authInputInsc.inputContainer}>
          <TextInput
            type="text"
            style={authInputInsc.inputTxt}
            placeholder="**********"
            placeholderTextColor="#174B9D"
          />
        </View>

        <View style={authInputInsc.label}>
          <Text style={authInputInsc.labelTxt}> Confirmez le mot de passe</Text>
        </View>
        <View style={authInputInsc.inputContainer}>
          <TextInput
            type="text"
            style={authInputInsc.inputTxt}
            placeholder="**********"
            placeholderTextColor="#174B9D"
          />
        </View>

        <View
          style={{
            alignItems: "center",
            justifyContent: "center",
            marginTop: 66,
            paddingBottom: 100,
          }}
        >
          <TouchableOpacity style={authInputInsc.authButton}>
            <Text style={authInputInsc.authButtText}>Enregistrer</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

export default InscriptionScreen;
