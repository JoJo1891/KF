import React, { useState } from "react";
import {
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
  Alert,
  TextInput,
  Linking,
} from "react-native";
import { useSelector } from "react-redux";

import { ScrollView } from "react-native";
import { SimpleHeaderComponent } from "../components";
import GofidButton from "../components/partials/GofidButton";
import { Formik } from "formik";
import * as Yup from "yup";
import { requestContactForm, requestContactFormAuth } from "../api/contact";
import { useMutation, useQueryClient } from "react-query";
import { selectIsLogged } from "../state/auth";
import { moderateScale } from "react-native-size-matters";
import SelectDropdown from "react-native-select-dropdown";
import Drop from "../assets/icons/drop.svg";
import AnimationSuccess from "../components/partials/AnimationSuccess";

const ContactScreen = ({ navigation }) => {
  const queryClient = useQueryClient();
  const [showAnimation, setShowAnimation] = useState(false);

  const isLogged = useSelector(selectIsLogged);

  const subject = [
    { name: "Adhésion de mon entreprise", value: "Adhésion de mon entreprise" },
    {
      name: "Une question sur l'application",
      value: "Une question sur l'application",
    },
    { name: "Problèmes d'utilisation", value: "Problèmes d'utilisation" },
    {
      name: "Suggestion d'ajout d'enseigne",
      value: "Suggestion d'ajout d'enseigne",
    },
  ];

  const { mutate, isLoading } = isLogged
    ? useMutation(requestContactFormAuth, {
        onSuccess: async (response) => {
          setShowAnimation(true);
        },
        onError: (error) => {
          Alert.alert("Oups, Vos informations n'ont pas pu être reçues");
        },
        onSettled: () => {
          queryClient.invalidateQueries("requestContactFormAuth");
        },
      })
    : useMutation(requestContactForm, {
        onSuccess: async (response) => {
          setShowAnimation(true);
        },
        onError: (error) => {
          Alert.alert("Oups, Vos informations n'ont pas pu être reçues");
        },
        onSettled: () => {
          queryClient.invalidateQueries("requestContactForm");
        },
      });

  const contactValidationSchema = Yup.object().shape({
    email: Yup.string()
      .email("Merci d’entrer une adresse e-mail valable")
      .required("Adresse e-mail est nécessaire"),
    subject: Yup.string(),
    message: Yup.string().required("La description est obligatoire"),
  });

  const contactHandler = async ({ email, subject, message }) => {
    mutate({
      subject,
      email,
      message,
    });
  };

  const handlerOk = () => {
    navigation.goBack();
    setShowAnimation(false);
  };

  const pickerStyle = {
    inputIOS: {
      fontSize: 14,
      fontFamily: "MontserratMedium",
      textAlign: "left",
      color: "#174B9D",
      height: moderateScale(40),
      paddingHorizontal: 10,
      width: moderateScale(330),
    },
    inputAndroid: {
      fontSize: 14,
      fontFamily: "MontserratMedium",
      textAlign: "left",
      color: "#174B9D",
      width: "50%",
    },
  };

  return (
    <>
      {showAnimation ? (
        <View style={{ backgroundColor: "white" }}>
          <SimpleHeaderComponent title="Contactez-nous" />
          <TouchableOpacity onPress={() => handlerOk()}>
            <AnimationSuccess message="Email de contact envoyé" />
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView style={{ backgroundColor: "white" }}>
          <SimpleHeaderComponent title="Contactez-nous" />

          <Formik
            initialValues={{
              subject: "Sélectionnez le Sujet",
              email: "",
              message: "",
            }}
            onSubmit={(values) => {
              if (values.subject === "Sélectionnez le Sujet") {
                alert("Error: Sélectionnez le Sujet");
              } else {
                contactHandler({
                  subject: values.subject,
                  email: values.email,
                  message: values.message,
                });
              }
            }}
            validationSchema={contactValidationSchema}
          >
            {({ handleChange, handleSubmit, values, errors }) => (
              <>
                <View style={styles.screenContainer}>
                  <View>
                    <Text style={styles.title}>
                      Besoin d’aide ? {"\n"}Écrivez-nous !
                    </Text>
                  </View>

                  <View style={styles.label}>
                    <Text style={styles.labelTxt}> Sujet</Text>
                  </View>
                  <View style={styles.inputContainer}>
                    <View
                      style={{
                        justifyContent: "center",
                        width: "100%",
                        display: "flex",
                        flexDirection: "row",
                        height: "100%",
                      }}
                    >
                      <SelectDropdown
                        data={subject}
                        buttonStyle={styles.buttonStyle}
                        buttonTextStyle={styles.buttonTextStyle}
                        rowTextStyle={{ color: "#174B9D" }}
                        defaultButtonText="Sélectionnez le Sujet"
                        defaultValue={"Sélectionnez le Sujet"}
                        dropdownStyle={{ backgroundColor: "white" }}
                        onSelect={(selectedItem, index) => {
                          handleChange("subject");
                        }}
                        buttonTextAfterSelection={(selectedItem, index) => {
                          return (values.subject = selectedItem.name);
                        }}
                        rowTextForSelection={(item, index) => {
                          return (values.subject = item.name);
                        }}
                      />
                      <Drop style={styles.dropStyle} />
                    </View>
                  </View>

                  <View style={styles.label}>
                    <Text style={styles.labelTxt}> Email</Text>
                  </View>
                  <View style={styles.inputContainer}>
                    <TextInput
                      type="email"
                      style={styles.inputTxt}
                      placeholder="exemple@votreemail.com"
                      placeholderTextColor="#174B9D"
                      onChangeText={handleChange("email")}
                      value={values.email}
                    />
                  </View>
                  {errors.email && (
                    <Text
                      style={{ fontSize: 10, color: "red", marginLeft: 16 }}
                    >
                      {errors.email}
                    </Text>
                  )}

                  <View style={styles.label}>
                    <Text style={styles.labelTxt}> Description</Text>
                  </View>
                  <View style={styles.inputContainer2}>
                    <TextInput
                      type="text"
                      style={styles.bigInput}
                      multiline={true}
                      onChangeText={handleChange("message")}
                      value={values.message}
                    />
                    {errors.message && (
                      <Text
                        style={{ fontSize: 10, color: "red", marginLeft: 0 }}
                      >
                        {errors.message}
                      </Text>
                    )}
                  </View>

                  <View style={styles.button}>
                    <GofidButton
                      name="blue"
                      value="Envoyer"
                      press={handleSubmit}
                      disabled={isLoading}
                    />
                  </View>

                  <TouchableOpacity
                    style={styles.endContainer}
                    onPress={() => Linking.openURL("http://gonordmartinique.fr")}
                  >
                    <Text style={styles.endTxt}>
                      Notre Web: http://gonordmartinique.fr/
                    </Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </Formik>
        </ScrollView>
      )}
    </>
  );
};

export default ContactScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    height: "100%",
  },
  title: {
    fontFamily: "MontserratSemiBold",
    fontSize: 25,
    color: "#174B9D",
    textAlign: "left",
    paddingTop: 30,
    marginHorizontal: 16,
  },
  label: {
    alignItems: "flex-start",
    marginTop: 18,
    marginHorizontal: 16,
  },
  labelTxt: {
    fontSize: 14,
    color: "#174B9D",
    fontFamily: "HelveticaNeueBold",
  },
  inputContainer: {
    backgroundColor: "#0697DC0A",
    borderWidth: 1,
    borderColor: "#0697DC",
    borderRadius: 8,
    marginTop: 6.69,
    height: 50,
    marginHorizontal: 16,
  },
  inputTxt: {
    fontSize: 14,
    fontFamily: "MontserratMedium",
    textAlign: "left",
    color: "#174B9D",
    height: 50,
    width: "100%",
    paddingHorizontal: 10,
  },
  inputContainer2: {
    justifyContent: "flex-start",
    marginHorizontal: 16,
    alignItems: "stretch",
    backgroundColor: "#0697DC0A",
    borderWidth: 1,
    borderColor: "#0697DC",
    borderRadius: 8,
    marginTop: 6.69,
    height: 279,
    marginBottom: 40,
  },
  bigInput: {
    fontSize: 14,
    fontFamily: "MontserratMedium",
    textAlign: "left",
    color: "#174B9D",
    height: 279,
    paddingHorizontal: 10,
    width: "100%",
    textAlignVertical: "top",
    marginTop: 10,
  },
  button: {
    marginBottom: 26,
    marginHorizontal: 16,
  },
  endContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#0697DC0A",
    marginHorizontal: 16,
    borderWidth: 1,
    borderColor: "#0697DC",
    borderRadius: 5,
    marginTop: 6.69,
    height: 40,
    marginBottom: 50,
  },
  endTxt: {
    fontSize: 14,
    fontFamily: "MontserratMedium",
    textAlign: "center",
    color: "#174B9D",
    width: "100%",
  },
  alertContainer: {
    width: "100%",
    height: 51,
    backgroundColor: "#5ED96A",
    marginBottom: 40,
  },
  alertTxt: {
    color: "#FFFFFF",
    fontSize: 18,
    fontFamily: "MontserratRegular",
    textAlign: "center",
  },
  buttonTextStyle: {
    color: "#174B9D",
    fontFamily: "MontserratMedium",
    fontSize: 14,
    textAlign: "left",
  },
  buttonStyle: {
    width: "100%",
    borderRadius: 10,
    backgroundColor: "#0697DC0A",
    height: "90%",
    top: 2,
    position: "relative",
    left: 10,
  },
  dropStyle: {
    position: "relative",
    display: "flex",
    width: "100%",
    flexDirection: "row-reverse",
    right: 15,
    top: 20,
  },
});
