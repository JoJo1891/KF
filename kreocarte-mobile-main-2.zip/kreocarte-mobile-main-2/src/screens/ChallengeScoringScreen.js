import React, { useState, useEffect } from "react";
import { View, FlatList, StyleSheet, Linking,
  TouchableOpacity,
  Text} from "react-native";

import {
  GradientComponent,
  SimpleHeaderComponent,
  ChallengeScoringListItems,
  
} from "../components";

import { windowHeight, windowWidth } from "../themes";

const ChallengeScoringScreen = ({ navigation }) => {
  const [mockData, setMockData] = useState([

    {
      id : 1,
      description: 'Ajout de carte partenaire',
      points:"+2"
    },
    {
      id : 2,
      imageUrl:"data:image/svg+xml,%3Csvg id='Grupo_1087' data-name='Grupo 1087' xmlns='http://www.w3.org/2000/svg' width='86.425' height='86.425' viewBox='0 0 86.425 86.425'%3E%3Ccircle id='Elipse_66' data-name='Elipse 66' cx='43.213' cy='43.213' r='43.213' fill='%235ed96a'/%3E%3Cg id='Grupo_1086' data-name='Grupo 1086' transform='translate(7.871 12.594)'%3E%3Cg id='flyer'%3E%3Cpath id='Trazado_981' data-name='Trazado 981' d='M70.453,395.128v8.256H0v-8.256L8.256,391H66.325Z' transform='translate(0 -341.463)' fill='%23174b9d'/%3E%3Cpath id='Trazado_982' data-name='Trazado 982' d='M291.227,395.128v8.256H256V391h31.1Z' transform='translate(-220.773 -341.463)' fill='%23174b9d'/%3E%3Cpath id='Trazado_983' data-name='Trazado 983' d='M70.453,31V84.665H45.547l-10.32,8.256-10.32-8.256H0V31Z' transform='translate(0 -31)' fill='%23fff'/%3E%3Cpath id='Trazado_984' data-name='Trazado 984' d='M291.227,31V84.665H266.32L256,92.922V31Z' transform='translate(-220.773 -31)' fill='%23ebebeb'/%3E%3Cpath id='Trazado_985' data-name='Trazado 985' d='M80.778,171.641H60V151H80.778Z' transform='translate(-51.744 -134.488)' fill='%230697dc'/%3E%3Cg id='Grupo_1085' data-name='Grupo 1085' transform='translate(41.524 12.594)'%3E%3Crect id='Rectángulo_415' data-name='Rectángulo 415' width='20.466' height='3.673' transform='translate(0 0)' fill='%23cacaca'/%3E%3Crect id='Rectángulo_416' data-name='Rectángulo 416' width='20.466' height='4.198' transform='translate(0 12.069)' fill='%23cacaca'/%3E%3Crect id='Rectángulo_417' data-name='Rectángulo 417' width='20.466' height='4.198' transform='translate(0 24.664)' fill='%23cacaca'/%3E%3C/g%3E%3C/g%3E%3C/g%3E%3C/svg%3E%0A",
      description: 'Ajout de carte partenaire GoNord',
      points:"+3"
    },
    {
      id : 3,
      description: 'Importation de Carte Physique',
      points:"+2"
    },
    {
      id : 4,
      description: 'Connexion hebdomadaire',
      points:"+1"
    },
    {
      id : 5,
      description: 'Compte personnel compléter',
      points:"+15"
    },
    {
      id : 6,
      description: 'Scan partenaire de la carte nord',
      points:"+5"
    },
    {
      id : 7,
      description: "Partager l'article",
      points:"+5"
    },
    {
      id : 8,
      description: 'Recommander vers des contacts',
      points:"+1"
    },
    {
      id : 9,
      description: 'Anniversaire utilisateur KréoCarte',
      points:"+10"
    },
    {
      id : 10,
      description: 'Notation de carte partenaire',
      points:"+1"
    },
    {
      id : 11,
      description: 'Utilisation du bouton "utiliser mon bon plan"',
      points:"+2"
    }, 
    {
      id : 12,
      description: 'Recommander vers des contacts',
      points:"+5"
    },  
  ]);


  return (
    <View style={styles.screenContainer}>
      <GradientComponent
        colors={["#E2F2FF", "#FFFFFF"]}
        style={styles.backgroundGradient}
      />
      <View style={styles.contentContainer}>
     
        <FlatList
         ListHeaderComponent={
          <View style={styles.headerContainer}>
            <SimpleHeaderComponent title="Défis Point Kréocarte'" />
            <Text style={styles.subTitle}> Comment cagnotter des points Kréocarte' ? </Text>
          </View>
         }
          ListFooterComponent={<TouchableOpacity onPress={() => console.log("go deals")}>
          <Text style={styles.link}>
            Consulter vos DEAL
          </Text>
      </TouchableOpacity>}
          ListFooterComponentStyle={{ marginBottom: 10 }}
          data={mockData}
          extraData={mockData}
          renderItem={({ item }) => (
            <ChallengeScoringListItems {...item} />
          )}
          keyExtractor={(notification) => notification.id}
          showsVerticalScrollIndicator={false}
        />
      </View>
     
    </View>
  );
};

export default ChallengeScoringScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    justifyContent: "flex-start",
    flex:1,
  },
  headerContainer: {
    justifyContent:'center',
  },
  subTitle:{
    fontSize:14,
    fontWeight:'bold',
    color:"#174B9D",
    textAlign:'center',
    paddingTop:20,
    paddingBottom:25,
    paddingLeft:50,
    paddingRight:50
  },
  link:{
    fontSize:14,
    color:"#174B9D",
    textAlign:'center',
    textDecorationLine: "underline",
    textDecorationStyle: "solid",
    textDecorationColor: "#000",
    marginBottom:40,
    marginTop:30
  }
});
