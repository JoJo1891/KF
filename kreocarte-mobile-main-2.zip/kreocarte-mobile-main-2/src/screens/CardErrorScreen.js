import React from 'react';

import { 
    View,
    Text,
    TouchableOpacity,
    StyleSheet
} from 'react-native';

import CloseIcon from '../assets/icons/close_white.svg';
import RedCircle from '../assets/icons/red-circle.svg';
import CardError from '../assets/icons/card-error.svg';
import { moderateVerticalScale, moderateScale } from 'react-native-size-matters';
import { windowHeight } from '../themes';

const CardErrorScreen = ({navigation}) => {
 return <View style={styles.screenContainer}>
     <TouchableOpacity onPress={()=>navigation.goBack()} style={styles.headerContainer}>
        <CloseIcon fill='#ffffff'/>
     </TouchableOpacity>
     <View style={styles.greenCircle}>
         <RedCircle height={windowHeight-90}/>
     </View>
     <View style={styles.contentContainer}>
        <CardError/>
        <Text style={styles.text}>Une erreur s'est produite, Veuillez réessayer</Text>
     </View>
 </View>
}

export default CardErrorScreen;

const styles = StyleSheet.create({
    screenContainer :{
        flex : 1,
        backgroundColor : '#FE6869'
    },
    headerContainer : {
        marginTop : 40,
        marginRight : 20,
        alignSelf : 'flex-end'
    },
    greenCircle : {
        marginTop : moderateVerticalScale(20),
        left : -moderateScale(105),
    },
    contentContainer : {
        position : 'absolute',
        left : 0,
        top : 0,
        right : 0,
        bottom : 0,
        justifyContent : 'center',
        alignItems : 'center',
    },
    text : {
        textAlign : 'center',
        marginHorizontal : 30,
        fontFamily : 'MontserratMedium',
        marginTop : 17,
        fontSize : moderateScale(22),
        color : 'white'
    }
});