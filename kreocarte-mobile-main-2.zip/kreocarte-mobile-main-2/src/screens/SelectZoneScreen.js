import React ,{ useEffect, useState} from 'react';
import {
    View,
    StyleSheet,
    Text,ScrollView, BackHandler, Alert
} from 'react-native';

import GofidButton from '../components/partials/GofidButton';
import GoNord from '../components/SelectZone/GoNord';
import Gofid from '../components/SelectZone/Gofid';
import { GradientComponent } from '../components';
import { useNavigation } from "@react-navigation/core";
import { windowHeight } from "../themes";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { requestTrackingPermissionsAsync } from "expo-tracking-transparency";


const SelectZoneScreen = () => {

    // 1 for GoNord ; 2 for Gofid
    const [zone , setZone] = useState(1);

    const setGofidHandler =  () => {
            setZone(2);
    }

    const setGoNorddHandler =  () => {
        setZone(1);
    }  

    const storeZone = async (item) => {
        try {
            await AsyncStorage.setItem('zone', item)
          } catch (e) {
            // saving error
          }
    }  

    const setZoneHandler =  () => {
        if (zone == 1){
            storeZone('gonord')
        }else if(zone == 2){
            storeZone('kréocarte')
        }
        navigation.replace('Home')
    }  

    const navigation = useNavigation();

    const backAction = () => {
        if (navigation.isFocused()) {
          Alert.alert("Attendez!", "Êtes-vous sûr de vouloir quitter l’application ?", [
            {
              text: "Annuler",
              onPress: () => null,
              style: "cancel"
            },
            { text: "Oui", onPress: () => BackHandler.exitApp() }
          ]);
          return true;
        }
    };
      
    const backHandler = BackHandler.addEventListener(
        "hardwareBackPress",
        backAction
    );

    useEffect(() => {
        (async () => {
          const { status } = await requestTrackingPermissionsAsync();
          if (status === "granted") {
            console.log("Yay! I have user permission to track data");
          }
        })();
      }, []);


    return (


        <View style={styles.screenContainer}>
        <GradientComponent colors={['#E2F2FF','#FFFFFF']} style={styles.backgroundGradient}/>
            <View style={styles.contentContainer}>
                <ScrollView>
                             {zone === 1 &&
                                    <View >
                                        < GoNord setGofid={setGofidHandler} />
                                    </View>
                                }
                                {zone === 2 &&
                                    <View >
                                        < Gofid setGoNord={setGoNorddHandler}/>
                                    </View>
                                }


                                <View style={{alignItems:'center', marginTop:1}}>
                                    <Text style={styles.martinique}>
                                        Martinique
                                    </Text>
                                </View>

                                <View style={{ alignItems:'center', marginTop:40, }}>
                                    <Text style={styles.p}>
                                    (*) Vous pourrez changer de zone plus tard
                                    </Text>
                                </View>

                                <View 
                                    style={{ marginVertical:60, marginHorizontal:16 }}>
                                        <GofidButton
                                            name="blue"
                                            value="Continuer"
                                            press={setZoneHandler}
                                            />
                                </View>
                </ScrollView>
            </View>
        </View>

 )
}

export default SelectZoneScreen;

const styles = StyleSheet.create({
    screenContainer: {
        flex: 1,
        backgroundColor: "white",
      },
      backgroundGradient : {
        height : windowHeight/2
      },
      contentContainer : {
        position : 'absolute',
        top : 0,
        bottom : 0,
        right:0,
        left:0
      },
    title:{
        marginTop:69,
        fontSize: 40, 
        fontFamily: 'MontserratRegular',
        color: '#174B9D'
    },
    subtitle:{
        marginTop:0,
        fontSize: 40, 
        fontFamily: 'MontserratBoldItalic',
        color: '#174B9D'
    },
    martinique:{
        fontSize: 16, 
        fontFamily: 'MontserratMedium',
        color: '#174B9D',
        textAlign:'center'
    },
    p:{
        fontSize: 14, 
        fontFamily: 'MontserratRegular',
        color: '#7D7D7D',
        textAlign:'center'

    }

});