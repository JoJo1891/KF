import React, { useEffect, useState } from "react";
import {
  View,
  StyleSheet,
  Text,
  RefreshControl,
  BackHandler,
} from "react-native";
import { useQuery, useQueryClient, useMutation } from "react-query";

import {
  SearchBarComponent,
  VerticalListComponent,
  HomeHeaderComponent,
  GradientComponent,
  ActionButtonComponent,
  CardListItem,
  Loader,
  ModalComponent,
  ConfirmationModal,
} from "../components";
import { getCardsByUser, deleteCard } from "../api/card";
import { windowHeight } from "../themes";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";

import EmptyCardIcon from "../assets/icons/empty-card.svg";
import { useNavigation } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { getUser } from "../api/user";
import { selectIsLogged } from "../state/auth";
import { useSelector } from "react-redux";
import { Alert } from "react-native";

const CardsScreen = () => {
  const navigation = useNavigation();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredList, setFilteredList] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [deleteCardModal, setDeleteCardModal] = useState(false);
  const [selectedCard, setSelectedCard] = useState(null);
  const isLogged = useSelector(selectIsLogged);

  const getDataTutorial = async () => {
    try {
      const value = await AsyncStorage.getItem("home3_tutorial");
      if (value !== null) {
        //alert(value);
      } else {
        navigation.navigate("Home3Tutorial1");
      }
    } catch (e) {
      // saving error
    }
  };

  const backAction = () => {
    if (navigation.isFocused()) {
      Alert.alert(
        "Attendez!",
        "Êtes-vous sûr de vouloir quitter l’application ?",
        [
          {
            text: "Annuler",
            onPress: () => null,
            style: "cancel",
          },
          { text: "Oui", onPress: () => BackHandler.exitApp() },
        ]
      );
      return true;
    }
  };

  const backHandler = BackHandler.addEventListener(
    "hardwareBackPress",
    backAction
  );

  useEffect(() => {
    if (isLogged) {
      queryClient.refetchQueries("users");
    }
  }, []);

  useEffect(() => {
    getDataTutorial();
  }, []);

  useEffect(() => {
    filterCards(data, searchTerm);
  }, [searchTerm]);

  const deleteCardMutation = useMutation(deleteCard, {
    onSuccess: (response) => {
      setDeleteCardModal(!deleteCardModal);
      queryClient.refetchQueries("goNordStoresAuth");
      queryClient.refetchQueries("goFidStoresAuth");
      queryClient.refetchQueries("getCardsByUser");
    },
    onError: (error) => {
      setDeleteCardModal(false);
      Alert.alert(
        "Error",
        "Erreur lors de la tentative de suppression de la carte"
      );
    },
    onSettled: () => {
      queryClient.invalidateQueries("deleteCard");
    },
  });

  const { data, isLoading } = useQuery(
    "getCardsByUser",
    async () => await getCardsByUser(),
    {
      onSuccess: (data) => {
        setFilteredList(data);
      },
    }
  );

  const onRefresh = () => {
    setRefreshing(true);
    queryClient.refetchQueries("getCardsByUser");
    if (isLogged) {
      queryClient.refetchQueries("users");
    }
    setRefreshing(false);
  };

  const filterCards = (data, searchTerm) => {
    if (!data) return;
    const regex = new RegExp(searchTerm, "i");
    setFilteredList(
      data.filter(
        (card) =>
          regex.test(card.enseigne.nom) ||
          regex.test(card.enseigne.description) ||
          regex.test(card.enseigne.zone)
      )
    );
  };

  const user = useQuery(["users"], ({ queryKey }) => getUser(queryKey[1]), {
    cacheTime: 0,
  });

  return (
    <View style={styles.screenContainer}>
      <ModalComponent modalVisible={deleteCardModal}>
        <ConfirmationModal
          value="voulez-vous supprimer votre carte ?"
          type="inverse"
          isLoading={deleteCardMutation.isLoading}
          onSubmit={() => setDeleteCardModal(!deleteCardModal)}
          onCancel={() => deleteCardMutation.mutate({ id: selectedCard })}
        />
      </ModalComponent>
      <GradientComponent
        colors={["#E2F2FF", "#FFFFFF"]}
        style={styles.backgroundGradient}
      />
      <View style={styles.contentContainer}>
        <VerticalListComponent
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          header={
            <View>
              <View style={styles.headerContainer}>
                <HomeHeaderComponent
                  name="Invite"
                  data={isLogged ? user.data : null}
                />
              </View>
              <View style={styles.searchBarContainer}>
                <SearchBarComponent onChange={setSearchTerm} />
              </View>
              {!isLoading && filteredList.length > 0 && (
                <Text style={styles.blueText}>Vos cartes ajoutées</Text>
              )}
              {!isLoading && filteredList.length === 0 && (
                <View>
                  <View style={styles.cardIcon}>
                    <EmptyCardIcon />
                  </View>
                  <View style={styles.whiteTextContainer}>
                    <Text style={styles.whiteText}>
                      vous n'avez aucune carte enregistrée!
                    </Text>
                  </View>
                </View>
              )}
              {isLoading && (
                <View
                  style={{
                    flex: 1,
                    marginTop: moderateVerticalScale(windowHeight / 3),
                  }}
                >
                  <Loader />
                </View>
              )}
            </View>
          }
          columns={2}
          data={filteredList}
          extraData={filteredList}
          ItemComponent={(item) => (
            <CardListItem
              {...item}
              handleDeleteCard={(id) => {
                setSelectedCard(id);
                setDeleteCardModal(!deleteCardModal);
              }}
              refreshing={refreshing}
              isLoading={isLoading}
              myCards={true}
            />
          )}
        />
        <ActionButtonComponent />
      </View>
    </View>
  );
};

export default CardsScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  headerContainer: {
    marginTop: 15,
  },
  searchBarContainer: {
    marginTop: 20,
    height: windowHeight / 17,
    marginHorizontal: 15,
  },
  verticalListContainer: {
    marginTop: 10,
    marginHorizontal: 5,
    marginBottom: 10,
  },
  blueText: {
    fontFamily: "MontserratMedium",
    textAlign: "center",
    color: "#174B9D",
    fontSize: moderateScale(24),
    marginTop: moderateVerticalScale(23),
  },
  cardIcon: {
    alignSelf: "center",
    marginTop: moderateVerticalScale(150),
  },
  whiteText: {
    fontFamily: "MontserratRegular",
    fontSize: moderateVerticalScale(17),
    textAlign: "center",
    color: "white",
  },
  whiteTextContainer: {
    backgroundColor: "#FF8788",
    marginTop: moderateVerticalScale(100),
    marginHorizontal: 15,
    paddingVertical: 2,
    justifyContent: "center",
    alignItems: "center",
  },
});
