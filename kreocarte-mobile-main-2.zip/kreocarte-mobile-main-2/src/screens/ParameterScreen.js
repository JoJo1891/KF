import React from 'react';
import {Text,View, TextInput,  TouchableOpacity,StyleSheet} from 'react-native';
import { ScrollView } from 'react-native';


import SecurityIcon from '../assets/icons/security_menu.svg';
import BellIcon from '../assets/icons/bell1.svg';
import { SimpleHeaderComponent } from '../components';
import { useNavigation } from '@react-navigation/native';


const ParameterScreen = () => {

  const navigation = useNavigation();
   
        return(
            <ScrollView style={{backgroundColor:'white'}}>
            <SimpleHeaderComponent title="Paramètres" />

            <View style={styles.screenContainer}>

            <TouchableOpacity style={ styles.labelBorder} onPress={()=> navigation.navigate('SecurityScreen')}> 
                        <View style={styles.icon}>
                                <SecurityIcon/>
                        </View>
                        <Text style={styles.label}>
                             Sécurité
                        </Text>
            </TouchableOpacity>      

            <TouchableOpacity style={ styles.labelBorder} onPress={()=> navigation.navigate('SetNotificationScreen')}>
                        <View style={styles.icon}>
                                <BellIcon/>
                        </View>
                        <Text style={styles.label}>
                             Notification
                       </Text>
            </TouchableOpacity>   

            </View>
            </ScrollView>
        )
    

}


export default ParameterScreen;

const styles = StyleSheet.create({
    screenContainer: {
        flex: 1,
        marginHorizontal: 16,
        alignItems:'center',
        height:"100%", 
        alignContent:"center", 
        paddingTop:30
      },
      labelBorder:{
            alignItems:'center',
            borderColor: '#EBEBEB',
            borderBottomWidth: 1,
            flexDirection:"row", 
            width:'100%',
            height:68.3,
      },
      icon:{
        width:'20%',
        alignItems: 'center'
      },
      label: {
          fontFamily: 'MontserratSemiBold',
          fontSize: 20,
          color: '#174B9D',
          width:'80%',
          flexDirection:"row", 

      }
    })