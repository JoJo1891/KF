import React from "react";
import { Text, View, StyleSheet, TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";
import GofidButton from "../components/partials/GofidButton";
import { moderateScale } from "react-native-size-matters";
import HandIcon from "../assets/icons/handphone.svg";
import XIcon from "../assets/icons/x.svg";

const Inscription = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.header]}>
      <View style={[styles.container, { borderColor: "#0C3E87" }]}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={{ width: "100%", flexDirection: "row-reverse" }}
        >
          <XIcon fill="#8C8C8C" />
        </TouchableOpacity>
        <View>
          <Text style={styles.text}>
            Vous utilisez votre application en tant qu’invité, pensez à vous
            inscrire.
          </Text>
          <View style={styles.buttonsContainer}>
            <HandIcon />
          </View>
          <View style={{ marginTop: 10 }}>
            <GofidButton
              name="blue"
              value="S’inscrire"
              press={() => navigation.navigate("RegisterScreen")}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

export default Inscription;

const styles = StyleSheet.create({
  container: {
    width: "80%",
    height: "60%",
    paddingHorizontal: 15,
    backgroundColor: "white",
    borderRadius: 30,
    borderWidth: 2,
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
  },
  header: {
    flex: 1,
    backgroundColor: "rgba(0, 7, 17, 0.9)",
    alignItems: "center",
    justifyContent: "center",
  },
  buttonsContainer: {
    justifyContent: "center",
    alignItems: "center",
    marginTop: 25,
    flexDirection: "row",
  },
  text: {
    fontFamily: "MontserratBold",
    textAlign: "center",
    fontSize: moderateScale(25),
    color: "#0C3E87",
  },
});
