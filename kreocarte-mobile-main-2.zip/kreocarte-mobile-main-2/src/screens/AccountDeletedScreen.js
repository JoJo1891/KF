import React ,{ useState} from 'react';
import {Text,View,StyleSheet,TouchableOpacity} from 'react-native';
import { ScrollView } from 'react-native';


import ImgIcon from '../assets/icons/shreder_icon.svg';
import CloseIcon from '../assets/icons/close_gray.svg';


import { SimpleHeaderComponent } from '../components';
import { useNavigation } from '@react-navigation/native';


const AccountDeletedScreen = () => {

    const navigation = useNavigation();

        return(
            
            <ScrollView style={{backgroundColor:'white'}}>
                
                <View style={styles.screenContainer}>
                    <TouchableOpacity style={styles.icon} onPress={()=> navigation.navigate('Home')}>
                        <CloseIcon/>
                    </TouchableOpacity> 
                    <Text style={styles.txt}>
                            Votre compte a été supprimé avec succès
                    </Text>
                    <View style={styles.img}>
                         <ImgIcon/>
                    </View> 
                </View> 
            </ScrollView>

            
        )
    

}


export default AccountDeletedScreen;

const styles = StyleSheet.create({
    screenContainer: {
        flex: 1,
        marginHorizontal: 30,
        height:"100%", 
        marginTop:39
      },
    txt: {
        fontFamily: 'MontserratSemiBold',
        fontSize: 30,
        color: '#174B9D',
        marginBottom:16,
        textAlign:'center',
        marginTop:159

    },
    icon: { 
        flexDirection:"row", 
        justifyContent:'flex-end'
    },
    img:{
        alignItems:'center'
    }
    
    })