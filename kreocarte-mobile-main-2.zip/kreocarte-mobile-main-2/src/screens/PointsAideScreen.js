import React, { useState } from "react";
import { Text, View, StyleSheet } from "react-native";
import { ScrollView } from "react-native";

import { SimpleHeaderComponent } from "../components";
import { useNavigation } from "@react-navigation/native";

const PointsAideScreen = () => {
  const navigation = useNavigation();

  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <SimpleHeaderComponent title="Points KréoCarte" />
      <View style={styles.screenContainer}>
        <View style={styles.textContainer}>
          <Text style={styles.paragraph}>
            <Text style={styles.title}>
              Comment cagnotter des points Kréocarte ? {"\n\n"}
            </Text>

            {
              'Ajout de carte partenaire (2pts) \n\nAjout de carte partenaire GoNord (3pts) \n\nDématérialisation / Importation de carte physique (2pts) \n\nConnexion hebdomadaire (1pts) \n\nCompte personnel compléter (15pts) \n\nUtilisation du scan chez un commerçant partenaire de la carte nord (5pts) \n\nPartager l’article (5pts) \n\nRecommander vers des contacts (5pt) \n\nAnniversaire utilisateur KréoCarte (10pts) \n\nNotation de carte partenaire (1pts) \n\nUtilisation du bouton “utiliser mon bon plan" (2pts)\n\nRecommander vers des contacts (5pts)\n\n'
            }
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

export default PointsAideScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    marginHorizontal: 16,
    alignItems: "center",
    height: "100%",
    alignContent: "center",
    paddingTop: 10,
  },
  textContainer: {
    marginTop: 20,
    width: "100%",
  },
  title: {
    fontFamily: "MontserratSemiBold",
    fontSize: 16,
    color: "#174B9D",
    flexDirection: "row",
    textAlign: "left",
  },
  paragraph: {
    fontFamily: "MontserratRegular",
    fontSize: 16,
    color: "#7D7D7D",
    marginBottom: 19,
  },
});
