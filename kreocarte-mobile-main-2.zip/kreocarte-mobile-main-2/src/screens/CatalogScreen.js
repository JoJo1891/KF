import React from "react";

import { View, Text, StyleSheet } from "react-native";
import { useQuery } from "react-query";
import { getCatalog } from "../api/catalog";

import {
  CatalogListComponent,
  SimpleHeaderComponent,
  CatalogListItem,
  Loader,
} from "../components";
import { windowHeight } from "../themes";

const CatalogScreen = ({route}) => {

  const {id} = route.params

  const {data,isLoading} = useQuery(['catalog',id],({queryKey})=> getCatalog(queryKey[1]))

  return (
    <View style={styles.screenContainer}>
      <CatalogListComponent
        header={
          <View>
            <SimpleHeaderComponent title="Catalogue" />
            <View style={styles.descriptionContainer}>
              <Text style={styles.description}>
                Laissez vous séduire par notre sélection d’articles /
                prestations
              </Text>
            </View>
            {isLoading && <View style={{flex : 1 , justifyContent : 'center',alignItems : 'center'}}>
              <Loader/>
            </View>}
          </View>
        }
        ItemComponent={(item)=><CatalogListItem type='catalogue' {...item}/>}
        data={data}
        extraData={data}
      />
    </View>
  );
};

export default CatalogScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
  },
  listContainer: {
    marginTop: 20,
  },
  descriptionContainer: {
    marginTop: 20,
    marginHorizontal: 15,
  },
  description: {
    fontFamily: "MontserratRegular",
    color: "#7D7D7D",
    fontSize: 14,
  },
});
