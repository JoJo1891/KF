import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-4.svg";
import MenuIcon from "../../assets/icons/AIDE_MENU.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Menu2Tutorial3 = ({ navigation : { goBack } }) => {
   
   const storeData = async () => {
      try {
        await AsyncStorage.setItem('menu_tutorial', 'menu')
      } catch (e) {
        // saving error
      }
    }

    const handlerTutorial = () =>{
      storeData();
      goBack();
    }




  return (  
    
    <TouchableOpacity style={styles.screenContainer} onPress={ handlerTutorial }>
       <Text style={styles.text}>
          En attendant, vous pouvez accéder à notre menu d'aide, lire nos conditions générales d'utilisation et contactez-nous directement par e-mail.
       </Text>
       <View style={styles.arrow}>
          <ArrowIcon />
       </View>
       <View style={styles.menu}>
          <MenuIcon/>
       </View>
    </TouchableOpacity>

  );
};

export default Menu2Tutorial3;

const styles = StyleSheet.create({
    screenContainer: {
        marginTop:moderateVerticalScale(72),
        flex: 1,
        justifyContent: "flex-start",
       paddingBottom : 50,
       alignItems:'center',
       },
    text: {
        marginHorizontal:moderateScale(20),
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
    arrow:{
        marginHorizontal:moderateScale(20),
        marginTop:moderateVerticalScale(36),
        marginBottom:moderateVerticalScale(39),
        transform: [{ rotate: '30deg'}]
       },
    menu:{
        height:moderateVerticalScale(250),
        width:'100%'
       }
});
