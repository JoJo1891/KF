import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-4.svg";
import DealImg from "../../assets/icons/DEAL.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import SkipIcon from "../../assets/icons/backArrow.svg";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { windowHeight } from "../../themes";

const MesPointsTutorial2 = ({ navigation }) => {
  
  const storeData = async () => {
    try {
      await AsyncStorage.setItem('points', 'points2')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }


  return (  
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>
    <TouchableOpacity style={styles.screenContainer} onPress={ () => navigation.replace('MesPointsTutorial3')}>
        <Text style={styles.text}>
          Réductions, promotions où vous pouvez utiliser vos points Kréocarte'.
        </Text>
        <View style={styles.arrow}>
          <ArrowIcon />
        </View>
        <View style={styles.deal}>
          <DealImg />
        </View>
    </TouchableOpacity>
    </>
  );
};

export default MesPointsTutorial2;

const styles = StyleSheet.create({
    screenContainer: {
        flex: 1,
        justifyContent: "flex-end",
        marginHorizontal: moderateScale(16),
       marginBottom : 100,
       alignItems:'center'
       },
    text: {
        marginHorizontal:moderateScale(10),
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
    arrow:{
        alignItems:'flex-end',
        marginStart:moderateScale(80),
        transform: [{ rotate: '-20deg'}],
        marginBottom: -(moderateVerticalScale(25))
       },
    deal:{
        height:moderateVerticalScale(200),
        width:'100%'
    },
  clearAll: {
      marginTop: windowHeight/moderateVerticalScale(19),
      marginBottom:moderateVerticalScale(10),
      marginRight:moderateVerticalScale(10),
      borderTopColor: "#CED4D9",
      alignItems:'flex-end'
    },
  clearAllText: {
      alignSelf: "center",
      fontSize: 16,
      color: "black",
      fontWeight: "bold",
    },
  floating: {
      width: '30%',
      height: 40,
      flexDirection:'row',
      backgroundColor: "white",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: 50,
      opacity: 0.5,
    }, 
});
