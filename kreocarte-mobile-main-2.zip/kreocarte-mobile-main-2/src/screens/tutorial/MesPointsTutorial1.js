import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-4.svg";
import HistoryIcon from "../../assets/icons/history_icon.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import SkipIcon from "../../assets/icons/backArrow.svg";
import { windowHeight } from "../../themes";
import AsyncStorage from "@react-native-async-storage/async-storage";

const MesPointsTutorial1 = ({ navigation }) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('points', 'points1')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }

  return (  
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.screenContainer} onPress={ () => navigation.replace('MesPointsTutorial2')}>
        <View style={styles.history}>
            <HistoryIcon />
          </View>
          <View style={styles.arrow}>
            <ArrowIcon />
          </View>
          <Text style={styles.text}>
              Dans cette section, vous pouvez voir votre historique de points gagnés et des tâches qu'il vous reste à réaliser pour débloquer plus de points Kréocarte'.
        </Text>
      </TouchableOpacity>
    </>
  );
};

export default MesPointsTutorial1;

const styles = StyleSheet.create({
    screenContainer: {
        marginTop:moderateVerticalScale(10),
        flex: 1,
        justifyContent: "flex-start",
        paddingHorizontal: moderateScale(20),
       paddingBottom : 50,
       alignItems:'flex-end'
       },
    text: {
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
    arrow:{
        alignItems:'flex-end',
        marginEnd:moderateScale(13),
        transform: [{ rotate: '50deg'}]
       },
    history:{
        alignItems:'center',
        justifyContent:'center',
        backgroundColor:'white',
        borderRadius:40,
        height:40,
        width:40
       },
    clearAll: {
        marginTop: windowHeight/moderateVerticalScale(19),
        marginBottom:moderateVerticalScale(10),
        marginRight:moderateVerticalScale(10),
        borderTopColor: "#CED4D9",
        alignItems:'flex-end'
      },
    clearAllText: {
        alignSelf: "center",
        fontSize: 16,
        color: "black",
        fontWeight: "bold",
      },
    floating: {
        width: '30%',
        height: 40,
        flexDirection:'row',
        backgroundColor: "white",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 50,
        opacity: 0.5,
      }, 
});
