import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-3.svg";
import LogosIcon from "../../assets/icons/LOGOS_BAR.svg";
import SkipIcon from "../../assets/icons/backArrow.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import { windowHeight, windowWidth } from "../../themes";
import AsyncStorage from "@react-native-async-storage/async-storage";

const HomeTutorialStep4 = ({ navigation }) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('home_tutorial', 'home')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }

  return (
    
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.screenContainer} onPress={()=> navigation.replace('HomeTutorialStep5')}>
          <View style={styles.logos}>
            <LogosIcon/>
          </View>
          <View style={styles.arrow}>
            <ArrowIcon/>
          </View>
          <Text style={styles.text}>
              Ici vous pouvez voir les dernières promotion de GO Nord, Kréocarte' et des magasins.
          </Text>
      </TouchableOpacity>
   </>   
  );
};

export default HomeTutorialStep4;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    alignItems:'center',
    paddingBottom : moderateVerticalScale(50),
  },
  arrow :{
    marginTop: -moderateVerticalScale(50),
    marginLeft:moderateScale(40),
    width:'100%',
  },
  logos :{
    marginHorizontal: moderateScale(1),
    width:windowWidth-20,
    height:moderateVerticalScale(200),
  },
  text: {
    marginHorizontal:moderateScale(30),
    marginTop:moderateVerticalScale(10),
    fontFamily: "MontserratMedium",
    fontSize: moderateScale(24),
    color : 'white',
  },
  clearAll: {
    marginTop: windowHeight/moderateVerticalScale(19),
    marginBottom:moderateVerticalScale(10),
    marginRight:moderateVerticalScale(10),
    borderTopColor: "#CED4D9",
    alignItems:'flex-end'
  },
  clearAllText: {
    alignSelf: "center",
    fontSize: 16,
    color: "black",
    fontWeight: "bold",
  },
  floating: {
    width: '30%',
    height: 40,
    flexDirection:'row',
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 50,
    opacity: 0.5,
  },   
});
