import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-4.svg";
import MenuIcon from "../../assets/icons/COMPTE.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import SkipIcon from "../../assets/icons/backArrow.svg";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { windowHeight } from "../../themes";

const Menu2Tutorial2 = ({ navigation }) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('menu_tutorial', 'menu2')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }


  return (  
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.screenContainer} onPress={ () => navigation.replace('Menu2Tutorial3')}>
        <View style={styles.menu}>
            <MenuIcon/>
          </View>
          <View style={styles.arrow}>
            <ArrowIcon />
          </View>
          <Text style={styles.text}>
              Une fois inscrit, toutes ces options seront automatiquement débloquées.
        </Text>
      </TouchableOpacity>
    </>
  );
};

export default Menu2Tutorial2;

const styles = StyleSheet.create({
    screenContainer: {
        marginTop:moderateVerticalScale(100),
        flex: 1,
        justifyContent: "flex-start",
       paddingBottom : 50,
       alignItems:'flex-start',
       },
    text: {
        marginHorizontal:moderateScale(20),
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
    arrow:{
        marginHorizontal:moderateScale(20),
        marginTop:moderateVerticalScale(15),
        marginBottom:moderateVerticalScale(17),
        transform: [{ rotate: '210deg'}]
       },
    menu:{
        height:moderateVerticalScale(250),
        width:'100%'
       },
    clearAll: {
        marginTop: windowHeight/moderateVerticalScale(19),
        marginBottom:moderateVerticalScale(10),
        marginRight:moderateVerticalScale(10),
        borderTopColor: "#CED4D9",
        alignItems:'flex-end'
      },
    clearAllText: {
        alignSelf: "center",
        fontSize: 16,
        color: "black",
        fontWeight: "bold",
      },
    floating: {
        width: '30%',
        height: 40,
        flexDirection:'row',
        backgroundColor: "white",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 50,
        opacity: 0.5,
      }, 
});
