import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-3.svg";
import CodeIcon from "../../assets/icons/CODE_BAR.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import SkipIcon from "../../assets/icons/backArrow.svg";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { windowHeight } from "../../themes";

const CardScreenTurorial6 = ({ navigation }) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('cards_tutorial', 'cards6')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }

  return (  
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.screenContainer} onPress={()=> navigation.replace('CardScreenTurorial7')}>
          <Text style={styles.text}>
          Si vous avez une carte physique, vous verrez le code de celle-ci ici. Dans le cas d'une carte numérique vous verrez votre numéro client.
          </Text>
          <View style={styles.arrow}>
            <ArrowIcon />
          </View>
        <View style={styles.bar}> 
            <CodeIcon/>
          </View>
      </TouchableOpacity>
    </>
  );
};

export default CardScreenTurorial6;

const styles = StyleSheet.create({
    screenContainer: {
        marginTop:moderateVerticalScale(160),
        flex: 1,
        justifyContent: "flex-start",
       paddingBottom : 50,
       alignItems:'flex-start',
       marginHorizontal:moderateScale(16),
       },
    text: {
        marginHorizontal:moderateScale(16),
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
    arrow:{
        marginStart:moderateScale(60),
        marginTop:moderateVerticalScale(19),
        marginBottom:moderateVerticalScale(10),
        transform: [{ rotate: '180deg'}]
       },
    bar:{
        height:moderateVerticalScale(150),
        backgroundColor:'white',
        paddingVertical:moderateVerticalScale(30),
        width:'100%',
        borderRadius:20
       },
    clearAll: {
        marginTop: windowHeight/moderateVerticalScale(19),
        marginBottom:moderateVerticalScale(10),
        marginRight:moderateVerticalScale(10),
        borderTopColor: "#CED4D9",
        alignItems:'flex-end'
      },
    clearAllText: {
        alignSelf: "center",
        fontSize: 16,
        color: "black",
        fontWeight: "bold",
      },
    floating: {
        width: '30%',
        height: 40,
        flexDirection:'row',
        backgroundColor: "white",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 50,
        opacity: 0.5,
      }, 
});
