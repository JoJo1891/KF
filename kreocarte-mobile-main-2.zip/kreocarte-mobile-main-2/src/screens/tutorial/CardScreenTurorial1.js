import React from "react";

import {  Text, StyleSheet, TouchableOpacity, View } from "react-native";
import SkipIcon from "../../assets/icons/backArrow.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import { windowHeight } from "../../themes";
import AsyncStorage from "@react-native-async-storage/async-storage";

const CardScreenTurorial1 = ({ navigation }) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('cards_tutorial', 'cards1')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }

  return (  
    <>
    <View style={styles.clearAll}>
              <TouchableOpacity
                  onPress={handlerTutorial}
                  style={styles.floating}
                >
                  <Text style={styles.clearAllText}>sauter</Text>
                  <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                </TouchableOpacity>
    </View>
    <TouchableOpacity style={styles.screenContainer} onPress={()=> navigation.replace('CardScreenTurorial2')}>
        <Text style={styles.text}>
        Ceci est la page du magasin vous pouvez vérifier votre numéro client, le code barre de la carte physique, le catalogue du magasin, les avantages d'y être abonné et de ses bons plans.
        </Text>
    </TouchableOpacity>
</>
  );
};

export default CardScreenTurorial1;

const styles = StyleSheet.create({
  screenContainer: {
        marginTop:moderateVerticalScale(10),
        marginHorizontal:moderateScale(30),
        flex: 1,
        justifyContent: 'center',
        alignItems:'center',
       },
  text: {
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
  clearAll: {
    marginTop: windowHeight/moderateVerticalScale(19),
    marginBottom:moderateVerticalScale(10),
    marginRight:moderateVerticalScale(10),
    borderTopColor: "#CED4D9",
    alignItems:'flex-end'
  },
  clearAllText: {
    alignSelf: "center",
    fontSize: 16,
    color: "black",
    fontWeight: "bold",
  },
  floating: {
    width: '30%',
    height: 40,
    flexDirection:'row',
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 50,
    opacity: 0.5,
  }, 
});
