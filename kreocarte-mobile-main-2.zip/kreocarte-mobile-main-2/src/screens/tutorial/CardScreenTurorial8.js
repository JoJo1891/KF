import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import CardIcon from "../../assets/icons/all_icons_tarjeta22.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import AsyncStorage from '@react-native-async-storage/async-storage';

const CardScreenTurorial8 = ({ navigation :{goBack} }) => {
  
  const storeData = async () => {
    try {
      await AsyncStorage.setItem('cards_tutorial', 'cards')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    goBack();
  }

  return (  
    
    <TouchableOpacity style={styles.screenContainer} onPress={ handlerTutorial}>
        <Text style={styles.text}>
             Glissez la carte pour voir la section récompenses et bonus.
        </Text>

       <View style={styles.card}> 
          <CardIcon/>
        </View>
    </TouchableOpacity>

  );
};

export default CardScreenTurorial8;

const styles = StyleSheet.create({
    screenContainer: {
        marginTop:moderateVerticalScale(80),
        flex: 1,
        justifyContent: "center",
       paddingBottom : 50,
       alignItems:'center',
       },
    text: {
        marginHorizontal:moderateScale(30),
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
         marginBottom:moderateVerticalScale(-20)
       },
    card:{
        height:moderateVerticalScale(400),
        width:'100%'
       }
});
