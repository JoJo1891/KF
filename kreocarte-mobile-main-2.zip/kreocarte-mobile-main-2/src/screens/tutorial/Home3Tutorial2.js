import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-4.svg";
import CARDIcon from "../../assets/icons/CARD_X.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import AsyncStorage from '@react-native-async-storage/async-storage';

const Home3Tutorial2 = ({ navigation :{goBack}}) => {

   const storeData = async () => {
      try {
        await AsyncStorage.setItem('home3_tutorial', 'cartes')
      } catch (e) {
        // saving error
      }
    }
  
    const handlerTutorial = () =>{
      storeData();
      goBack();
    }


  return (  
    
    <TouchableOpacity style={styles.screenContainer} onPress={ handlerTutorial}>
       <Text style={styles.text}>
            Garder votre doigt sur l'une des cartes activera l'option de suppression.
       </Text>
       <View style={styles.arrow}>
          <ArrowIcon />
       </View>
       <View style={styles.card}>
          <CARDIcon/>
       </View>
    </TouchableOpacity>

  );
};

export default Home3Tutorial2;

const styles = StyleSheet.create({
    screenContainer: {
        marginTop:moderateVerticalScale(72),
        flex: 1,
        justifyContent: "flex-start",
       paddingBottom : 50,
       alignItems:"flex-start",
       },
    text: {
         marginHorizontal:moderateScale(20),
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
    arrow:{
        marginStart:moderateScale(165),
        marginTop:moderateVerticalScale(4),
        marginBottom:moderateVerticalScale(-50),
        transform: [{ rotate: '30deg'}]
       },
    card:{
        marginHorizontal:moderateScale(2),
        height:moderateVerticalScale(200),
        width:205
       }
});

