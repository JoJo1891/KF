import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-4.svg";
import DealImg from "../../assets/icons/DEAL.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import AsyncStorage from "@react-native-async-storage/async-storage";

const MesPointsTutorial3 = ({ navigation }) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('points', 'points3')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }


  return (  
    
    <TouchableOpacity style={styles.screenContainer} onPress={ handlerTutorial }>
        <Text style={styles.text}>
             Si vous avez besoin d'aide cliquez simplement sur ce lien et vous aurez plus d'informations sur la façon d'utiliser vos points Kréocarte'.
        </Text>
        <View style={styles.arrow}>
          <ArrowIcon />
        </View>
        <View style={styles.box}>
            <Text style={styles.text2}>
            Vous voulez en savoir plus sur Kréocarte' ?
            </Text>
        </View>
    </TouchableOpacity>

  );
};

export default MesPointsTutorial3;

const styles = StyleSheet.create({
    screenContainer: {
        marginTop:moderateVerticalScale(40),
        flex: 1,
        justifyContent: "flex-end",
       marginBottom : 100,
       },
    text: {
        marginHorizontal:moderateScale(30),
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
         marginBottom:2
       },
    arrow:{
        marginHorizontal:moderateScale(17),
        alignItems:'flex-end',
       },
    box:{
        marginTop:16,
        backgroundColor:'white',
        alignItems:'center',
        height:34,
        justifyContent:'center'
    },
    text2: {
         fontFamily: "MontserratRegular",
         fontSize: moderateScale(16),
         color : '#174B9D',
         textAlign:'center'
       },
});
