import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import AsyncStorage from '@react-native-async-storage/async-storage';
import ArrowIcon from "../../assets/icons/tutorial-arrow-4.svg";
import PointsIcon from "../../assets/icons/1000_RING.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import { useNavigation } from '@react-navigation/native';

const HomeTutorialStep5 = ({ navigation:{goBack} }) => {
 
  const storeData = async () => {
    try {
      await AsyncStorage.setItem('home_tutorial', 'home')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    goBack();
  }


  return (
    
    
    <TouchableOpacity onPress={ handlerTutorial}>
        <View style={styles.logos}>
             <PointsIcon/>
         </View>
         <View style={styles.arrow}>
          <ArrowIcon/>
         </View>
        <Text style={styles.text}>
            Vérifiez l'état de vos points Kréocarte' et des notifications récentes.
       </Text>
    </TouchableOpacity>

   
    
  );
};

export default HomeTutorialStep5;

const styles = StyleSheet.create({
  screenContainer: {
  },
  arrow :{
    alignItems:'flex-end',
    marginTop:-(moderateVerticalScale(400)),
    marginEnd:moderateScale(35)
  },
  logos :{
    marginStart:moderateScale(245),
    marginEnd:moderateScale(15),
    marginTop:-(moderateVerticalScale(380)),
  },
  text: {
    marginHorizontal:moderateScale(20),
    marginTop:moderateVerticalScale(10),
    fontFamily: "MontserratMedium",
    fontSize: moderateScale(24),
    color : 'white',
  },
});
