import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-4.svg";
import MenuIcon from "../../assets/icons/INFORMATION.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import SkipIcon from "../../assets/icons/backArrow.svg";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { windowHeight } from "../../themes";

const CardScreenTurorial5 = ({ navigation }) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('cards_tutorial', 'cards5')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }

  return (  
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.screenContainer} onPress={()=> navigation.replace('CardScreenTurorial6')}>
        <View style={styles.bar}> 
            <MenuIcon/>
          </View>
          <View style={styles.arrow}>
            <ArrowIcon />
          </View>
          <Text style={styles.text}>
              Consultez les informations du magasin, l'adresse, les horaires, le téléphone, etc. 
          </Text>
      </TouchableOpacity>
    </>
  );
};

export default CardScreenTurorial5;

const styles = StyleSheet.create({
    screenContainer: {
        marginTop:moderateVerticalScale(100),
        flex: 1,
        justifyContent: "flex-start",
       paddingBottom : 50,
       alignItems:'flex-start',
       },
    text: {
        marginHorizontal:moderateScale(30),
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
    arrow:{
        marginStart:moderateScale(30),
        marginTop:moderateVerticalScale(19),
        marginBottom:moderateVerticalScale(10),
        transform: [{ rotate: '180deg'}]
       },
    bar:{
        height:moderateVerticalScale(90),
        width:'100%'
       },
    clearAll: {
        marginTop: windowHeight/moderateVerticalScale(19),
        marginBottom:moderateVerticalScale(10),
        marginRight:moderateVerticalScale(10),
        borderTopColor: "#CED4D9",
        alignItems:'flex-end'
      },
    clearAllText: {
        alignSelf: "center",
        fontSize: 16,
        color: "black",
        fontWeight: "bold",
      },
    floating: {
        width: '30%',
        height: 40,
        flexDirection:'row',
        backgroundColor: "white",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 50,
        opacity: 0.5,
      }, 
});
