import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-3.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import SkipIcon from "../../assets/icons/backArrow.svg";
import GofidButton from "../../components/partials/GofidButton";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { windowHeight } from "../../themes";

const Menu2Tutorial1 = ({ navigation}) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('menu_tutorial', 'menu1')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }

  return (  
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.screenContainer} onPress={ () => navigation.replace('Menu2Tutorial2')}>
        <View style={styles.button}>
            <GofidButton      
                              name="blue"
                              value="S’inscrire"/>
          </View>
          <View style={styles.arrow}>
            <ArrowIcon />
          </View>
          <Text style={styles.text}>
              Si vous avez besoin d'aide, cliquez simplement sur ce bouton et vous aurez plus d'informations sur la façon d'utiliser vos points Kréocarte'.
        </Text>
      </TouchableOpacity>
    </>
  );
};

export default Menu2Tutorial1;

const styles = StyleSheet.create({
    screenContainer: {
        marginTop:moderateVerticalScale(20),
        marginHorizontal:moderateScale(20),
        flex: 1,
        justifyContent: "flex-start",
       marginBottom : 50,
       alignItems:'center'
       },
    text: {
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
    arrow:{
        marginTop:moderateVerticalScale(29),
        marginBottom:moderateVerticalScale(17),
        transform: [{ rotate: '180deg'}]
       },
    button:{
        marginTop:moderateVerticalScale(30),
        width:'100%'
       },
    clearAll: {
        marginTop: windowHeight/moderateVerticalScale(19),
        marginBottom:moderateVerticalScale(10),
        marginRight:moderateVerticalScale(10),
        borderTopColor: "#CED4D9",
        alignItems:'flex-end'
      },
    clearAllText: {
        alignSelf: "center",
        fontSize: 16,
        color: "black",
        fontWeight: "bold",
      },
    floating: {
        width: '30%',
        height: 40,
        flexDirection:'row',
        backgroundColor: "white",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 50,
        opacity: 0.5,
      }, 
});
