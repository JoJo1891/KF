import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import SkipIcon from "../../assets/icons/backArrow.svg";
import ArrowIcon from "../../assets/icons/tutorial-arrow-3.svg";
import CarteIcon from "../../assets/icons/CARTE2.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { windowHeight } from "../../themes";

const CardScreenTurorial3 = ({ navigation }) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('cards_tutorial', 'cards3')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }


  return (  
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.screenContainer} onPress={()=> navigation.replace('CardScreenTurorial4')}>
        <View style={styles.carte}> 
            <CarteIcon/>
          </View>
          <View style={styles.arrow}>
            <ArrowIcon />
          </View>
          <Text style={styles.text}>
              Dans ce coin, vous pouvez voir quel type de programme de fidélité possède ce magasin.{"\n\n"} 
              Il existe 3 types de programmes: cartes à points, barre de progression et cashback.
          </Text>
      </TouchableOpacity>
    </>
  );
};

export default CardScreenTurorial3;

const styles = StyleSheet.create({
    screenContainer: {
        marginTop:moderateVerticalScale(30),
        flex: 1,
        justifyContent: "flex-start",
       paddingBottom : 50,
       alignItems:'flex-end'
       },
    text: {
        marginStart:moderateScale(30),
        marginEnd:moderateScale(40),
        fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
    arrow:{
        marginHorizontal:moderateScale(60),
        marginTop:moderateVerticalScale(1),
        marginBottom:moderateVerticalScale(10),
        transform: [{ rotate: '225deg'}]
       },
    carte:{
        backgroundColor:'white',
        height:moderateVerticalScale(50),
        paddingVertical:moderateVerticalScale(8),
        width:moderateScale(100),
        borderTopLeftRadius:moderateVerticalScale(50),
        borderBottomLeftRadius:moderateVerticalScale(50),
       },
       clearAll: {
        marginTop: windowHeight/moderateVerticalScale(19),
        marginBottom:moderateVerticalScale(10),
        marginRight:moderateVerticalScale(10),
        borderTopColor: "#CED4D9",
        alignItems:'flex-end'
      },
      clearAllText: {
        alignSelf: "center",
        fontSize: 16,
        color: "black",
        fontWeight: "bold",
      },
      floating: {
        width: '30%',
        height: 40,
        flexDirection:'row',
        backgroundColor: "white",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 50,
        opacity: 0.5,
      }, 
});
