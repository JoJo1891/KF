import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-3.svg";
import SkipIcon from "../../assets/icons/backArrow.svg";
import MenuIcon from "../../assets/icons/MENU_BAR.svg";
import { moderateScale , moderateVerticalScale} from "react-native-size-matters";
import { windowHeight } from "../../themes";
import AsyncStorage from "@react-native-async-storage/async-storage";

const HomeTutorialStep1 = ({ navigation}) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('home_tutorial', 'home')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }

  return (
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.screenContainer} onPress={()=> navigation.replace('HomeTutorialStep2')}>
          <Text style={styles.text}>
            Ceci est votre portefeuille de cartes, ici vous pouvez les gérer et
            avoir un accès facile et rapide à chacun d'eux.
          </Text>
          <View style={styles.arrow}>
              <ArrowIcon/>
          </View>
          <View style={styles.menu}>
              <MenuIcon/>
          </View>
      </TouchableOpacity>
    </>
    
  );
};

export default HomeTutorialStep1;


const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    justifyContent: "flex-end",
    paddingBottom : moderateVerticalScale(50),
  },
  text: {
    marginHorizontal: moderateScale(20),
    fontFamily: "MontserratMedium",
    fontSize: moderateScale(24),
    color : 'white',
  },
  arrow :{
    marginHorizontal: moderateScale(20),
    marginTop : moderateVerticalScale(10),
    marginBottom:-(moderateVerticalScale(530)),
    marginStart:moderateScale(10),
  },
  menu :{
    marginBottom:-(moderateVerticalScale(500))
  } ,
  clearAll: {
    marginTop: windowHeight/moderateVerticalScale(19),
    marginBottom:moderateVerticalScale(10),
    marginRight:moderateVerticalScale(10),
    borderTopColor: "#CED4D9",
    alignItems:'flex-end'
  },
  clearAllText: {
    alignSelf: "center",
    fontSize: 16,
    color: "black",
    fontWeight: "bold",
  },
  floating: {
    width: '30%',
    height: 40,
    flexDirection:'row',
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 50,
    opacity: 0.5,
  }, 
});
