import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import CardIcon from "../../assets/icons/all_icons_tarjeta1.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import SkipIcon from "../../assets/icons/backArrow.svg";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { windowHeight } from "../../themes";

const CardScreenTurorial7 = ({ navigation }) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('cards_tutorial', 'cards7')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }

  return (  
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.screenContainer} onPress={()=> navigation.replace('CardScreenTurorial8')}>
        <View style={styles.card}> 
            <CardIcon/>
          </View>
          <Text style={styles.text}>
              Il s'agit de votre numéro de client, il est personnel et incessible.
          </Text>
      </TouchableOpacity>
    </>
  );
};

export default CardScreenTurorial7;

const styles = StyleSheet.create({
    screenContainer: {
        marginTop:moderateVerticalScale(100),
        flex: 1,
        justifyContent: "center",
       paddingBottom : 50,
       alignItems:'center',
       },
    text: {
        marginTop:moderateVerticalScale(-60),
        marginHorizontal:moderateScale(30),
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
    card:{
        height:moderateVerticalScale(318),
        width:'100%'
       },
    clearAll: {
        marginTop: windowHeight/moderateVerticalScale(19),
        marginBottom:moderateVerticalScale(10),
        marginRight:moderateVerticalScale(10),
        borderTopColor: "#CED4D9",
        alignItems:'flex-end'
      },
    clearAllText: {
        alignSelf: "center",
        fontSize: 16,
        color: "black",
        fontWeight: "bold",
      },
    floating: {
        width: '30%',
        height: 40,
        flexDirection:'row',
        backgroundColor: "white",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 50,
        opacity: 0.5,
      }, 
});
