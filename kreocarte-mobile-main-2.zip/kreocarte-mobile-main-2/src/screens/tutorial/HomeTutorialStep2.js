import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-4.svg";
import MenuIcon from "../../assets/icons/MENU_BAR.svg";
import SkipIcon from "../../assets/icons/backArrow.svg";
import { moderateScale , moderateVerticalScale} from "react-native-size-matters";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { windowHeight } from "../../themes";

const HomeTutorialStep2 = ({ navigation }) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('home_tutorial', 'home')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }

  return (
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.screenContainer}  onPress={()=> navigation.replace('HomeTutorialStep3')}>
        <Text style={styles.text}>
        Dans les paramètres de votre compte, vous avez accès à vos données, préférences, conditions d'utilisation et aide. 
        {"\n\n"}Vous pouvez ajouter des cartes, numériser une carte physique ou créer une carte numérique choisie parmi notre catalogue de magasins affiliés.
        </Text>
        <View style={styles.arrow}>
            <ArrowIcon/>
        </View>
        <View style={styles.menu}>
              <MenuIcon/>
        </View>
      </TouchableOpacity>

    </>
    
  );
};

export default HomeTutorialStep2;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    justifyContent: "flex-end",
    paddingBottom : moderateVerticalScale(50),
  },
  text: {
    marginHorizontal: moderateScale(20),
    fontFamily: "MontserratMedium",
    fontSize: moderateScale(24),
    color : 'white',
  },
  arrow :{
    marginTop : moderateVerticalScale(10),
    marginBottom:-(moderateVerticalScale(530)),
    marginEnd: moderateScale(30),
    alignItems:'flex-end'
  },
  menu :{
    marginHorizontal: moderateScale(1),
    marginBottom:-(moderateVerticalScale(500))
  } ,
  clearAll: {
    marginTop: windowHeight/moderateVerticalScale(19),
    marginBottom:moderateVerticalScale(10),
    marginRight:moderateVerticalScale(10),
    borderTopColor: "#CED4D9",
    alignItems:'flex-end'
  },
  clearAllText: {
    alignSelf: "center",
    fontSize: 16,
    color: "black",
    fontWeight: "bold",
  },
  floating: {
    width: '30%',
    height: 40,
    flexDirection:'row',
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 50,
    opacity: 0.5,
  },  
});