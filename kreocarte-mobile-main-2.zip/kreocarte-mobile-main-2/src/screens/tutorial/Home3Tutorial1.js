import React from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import ArrowIcon from "../../assets/icons/tutorial-arrow-4.svg";
import DealImg from "../../assets/icons/DEAL.svg";
import { moderateScale ,moderateVerticalScale} from "react-native-size-matters";
import SkipIcon from "../../assets/icons/backArrow.svg";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { windowHeight } from "../../themes";

const Home3Tutorial1 = ({ navigation }) => {

  const storeData = async () => {
    try {
      await AsyncStorage.setItem('home3_tutorial', 'cartes1')
    } catch (e) {
      // saving error
    }
  }

  const handlerTutorial = () =>{
    storeData();
    navigation.pop();
  }

  return (  
    <>
      <View style={styles.clearAll}>
                <TouchableOpacity
                    onPress={handlerTutorial}
                    style={styles.floating}
                  >
                    <Text style={styles.clearAllText}>sauter</Text>
                    <SkipIcon style={{color: 'red', transform: [{ rotate: '180deg'}]}}/>
                  </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.screenContainer} onPress={()=> navigation.replace('Home3Tutorial2')}>
          <Text style={styles.text}>
          Ici vous pouvez voir vos cartes, en cliquant dessus vous entrez dans la page du magasin, où vous pouvez utiliser votre carte avec votre 
          
              {"\n\n"}- Numéro de client{"\n"}
              <Text style={styles.text2}>(pour les cartes numériques) </Text>ou 

              {"\n\n"}- Numéro de série{"\n"}
              <Text style={styles.text2}>(pour les cartes physiques).</Text>
          </Text>
      </TouchableOpacity>
    </>
  );
};

export default Home3Tutorial1;

const styles = StyleSheet.create({
    screenContainer: {
        marginHorizontal:moderateScale(30),
        flex: 1,
        justifyContent: 'center',
        alignItems:'center',
       },
    text: {
         fontFamily: "MontserratSemiBold",
         fontSize: moderateScale(24),
         color : 'white',
         textAlign:'left',
       },
    text2: {
         fontFamily: "MontserratRegular",
         fontSize: moderateScale(18),
         color : 'white',
         textAlign:'left',
         opacity:0.7
       },
    clearAll: {
        marginTop: windowHeight/moderateVerticalScale(19),
        marginBottom:moderateVerticalScale(10),
        marginRight:moderateVerticalScale(10),
        borderTopColor: "#CED4D9",
        alignItems:'flex-end'
      },
    clearAllText: {
        alignSelf: "center",
        fontSize: 16,
        color: "black",
        fontWeight: "bold",
      },
    floating: {
        width: '30%',
        height: 40,
        flexDirection:'row',
        backgroundColor: "white",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 50,
        opacity: 0.5,
      }, 
});
