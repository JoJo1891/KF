
import React, { useState } from 'react';
import {Text,View, Switch,  TouchableOpacity,StyleSheet} from 'react-native';
import { ScrollView } from 'react-native';


import SecurityIcon from '../assets/icons/security_menu.svg';
import BellIcon from '../assets/icons/bell1.svg';
import { SimpleHeaderComponent } from '../components';
import { useNavigation } from '@react-navigation/native';
import SwitchRow from '../components/partials/SwitchRow';
import { selectUser } from '../state/auth';
import { useSelector } from 'react-redux';


const SetNotificationScreen = () => {

    const user = useSelector(selectUser);
    const mockData = {
        state1: false,
        state2: false,
        state3: true
      }

  const navigation = useNavigation();
  
        return(
            <ScrollView style={{backgroundColor:'white'}}>
            <SimpleHeaderComponent title="Notifications" />

            <View style={styles.screenContainer}>

                    <SwitchRow  title="Push Notifications" stateNoti={user.allow_notification} state={1}/>
                        <View style={styles.paragraphContainer}>
                            <Text style={styles.paragraph}>
                               Restez informé de vos gains ou avantage fidélité et ne ratez rien des meilleures offres, évènements, exclus de vos magasins préférés
                            </Text>
                        </View>

                    {/* <SwitchRow  title="SMS"/>
                        <View style={styles.paragraphContainer} stateNoti={mockData.state2} state={3}>
                            <Text style={styles.paragraph}>
                                Recevez nos flash info directement par message
                            </Text>
                        </View> */}

                    <SwitchRow  title="E-mails partenaires"  stateNoti={user.is_email_notifications} state={2}/>
                        <View >
                            <Text style={styles.paragraph}>
                            Retrouvez les offres exclusives et infos de nos partenaires
                            </Text>
                        </View>

            </View>
            </ScrollView>
        )
    

}


export default SetNotificationScreen;

const styles = StyleSheet.create({
    screenContainer: {
        flex: 1,
        marginHorizontal: 16,
        height:"100%", 
        alignContent:"center", 
        paddingTop:30
      },
      paragraphContainer:{
        marginTop:5,
        marginBottom:29
      },
      paragraph: {
        fontFamily: 'MontserratRegular',
        fontSize: 14,
        color: '#7D7D7D',
        textAlign:'left'

    }

    })