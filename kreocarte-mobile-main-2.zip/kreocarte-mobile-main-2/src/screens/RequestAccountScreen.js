import React, { useState } from "react";
import { Text, View, StyleSheet, Alert } from "react-native";
import { ScrollView } from "react-native";
import { useMutation, useQueryClient } from "react-query";

import ConfidentialIcon from "../assets/icons/confidential.svg";
import { SimpleHeaderComponent } from "../components";
import GofidButton from "../components/partials/GofidButton";
import { requestAccountData } from "../api/user";

const RequestAccountScreen = ({ navigation }) => {
  const queryClient = useQueryClient();
  const [visible, setVisible] = useState(false);

  const { isLoading, mutate } = useMutation(requestAccountData, {
    onSuccess: (data) => {
        setVisible(true)
    },
    onError: (error) => {
        Alert.alert('Erreur lors de la tentative de demande des données du compte')
        setVisible(false)
    },
    onSettled: () => {
      queryClient.invalidateQueries("requestAccountData");
    },
  });

  const handleSubmit = () =>{
    mutate()
  }

  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <SimpleHeaderComponent title="Informations sur le compte" />
      <View style={styles.screenContainer}>
        <View>
          <ConfidentialIcon />
        </View>

        <View style={styles.textContainer}>
          <Text style={styles.paragraph}>
            <Text style={styles.title}>
              Demandez toute votre activité dans l’application KréoCarte'{"\n\n"}
            </Text>
            {
              "Notre Politique d’utilisation des données détaille les informations que nous collectons dans le cadre de nos services généraux. Recevez par mail, la liste de vos informations à laquelle vous pouvez accéder à tout moment. \n\nSi vous souhaitez consulter vos informations cliquez sur << Demander vos informations >>.\n\n"
            }
          </Text>
        </View>

        {visible === true && (
          <View style={styles.alertContainer}>
            <Text style={styles.alertTxt}>
              Vos informations vous ont été {"\n"}envoyées par e-mail
            </Text>
          </View>
        )}

        <View style={styles.button}>
          <GofidButton
            name="blue"
            value="Demandez vos informations"
            disabled={isLoading}
            press={handleSubmit}
          />
        </View>
      </View>
    </ScrollView>
  );
};

export default RequestAccountScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    marginHorizontal: 16,
    alignItems: "center",
    height: "100%",
    alignContent: "center",
    paddingTop: 40,
  },
  textContainer: {
    marginTop: 80,
  },
  title: {
    fontFamily: "MontserratSemiBold",
    fontSize: 25,
    color: "#174B9D",
    flexDirection: "row",
    textAlign: "left",
  },
  paragraph: {
    fontFamily: "MontserratRegular",
    fontSize: 14,
    color: "#7D7D7D",
    marginBottom: 19,
  },
  button: {
    marginBottom: 50,
    marginTop: 0,
    width: "100%",
  },
  alertContainer: {
    width: 700,
    height: 51,
    backgroundColor: "#5ED96A",
    marginBottom: 40,
  },
  alertTxt: {
    color: "#FFFFFF",
    fontSize: 18,
    fontFamily: "MontserratRegular",
    textAlign: "center",
  },
});
