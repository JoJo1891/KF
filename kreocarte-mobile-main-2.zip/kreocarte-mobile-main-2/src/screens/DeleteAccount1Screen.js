import React, { useState, useEffect } from "react";
import { Text, View, StyleSheet, TextInput, ScrollView } from "react-native";
import { useDispatch } from "react-redux";
import { setIsLogged, setUser } from "../state/auth";
import { useMutation, useQueryClient } from "react-query";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { deleteAccount } from '../api/user'

import {
  ConfirmationModal,
  ModalComponent,
  SimpleHeaderComponent,
} from "../components";
import GofidButton from "../components/partials/GofidButton";

const DeleteAccount1Screen = ({navigation}) => {
  const dispatch = useDispatch();
  const queryClient = useQueryClient();

  const [reason, setReason] = useState("");
  const [modalVisible, setModalVisible] = useState(false);

  const { isLoading, mutate } = useMutation(deleteAccount, {
    onSuccess: (data) => {
      logOut();
    },
    onError: (data) => {},
    onSettled: () => {
      queryClient.invalidateQueries("deleteAccount");
    },
  });

  const handleSubmit = () => {
    mutate();
  };

  const logOut = async () => {
    setModalVisible(false)
    navigation.navigate('AccountDeletedScreen')
    await AsyncStorage.removeItem("token");
    dispatch(setIsLogged(false));
    dispatch(setUser(null));
  };

  const handlerModalVisible = () => {
    if (reason) {
      setModalVisible(!modalVisible);
    }
  };

  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <ModalComponent modalVisible={modalVisible}>
        <ConfirmationModal
          type="inverse"
          value="Etes-vous sûr de vouloir supprimer votre compte?"
          isLoading={isLoading}
          onCancel={() => handleSubmit()}
          onSubmit={() => setModalVisible(!modalVisible)}
        />
      </ModalComponent>
      <SimpleHeaderComponent title="Supprimer votre compte" />
      <View style={styles.screenContainer}>
        <View style={styles.textContainer}>
          <Text style={styles.paragraph}>
            Pouvez-vous partager avec nous ce qui ne fonctionnait pas ? Nous
            corrigerons les bugs dès que nous les aurons repérés. Si quelque
            chose nous glisse entre les doigts, nous serons très reconnaissants
            de l'entendre et de le réparer.
          </Text>
        </View>

        <View style={styles.inputContainer2}>
          <TextInput
            placeholder="Votre explication"
            placeholderTextColor="#174B9D"
            type="text"
            style={styles.bigInput}
            multiline={true}
            numberOfLines={12}
            onChangeText={setReason}
          />
        </View>

        <View style={styles.button}>
          <GofidButton
            type="submit"
            name="red"
            disabled={isLoading}
            value="Supprimer mon compte"
            press={handlerModalVisible}
          />
        </View>
      </View>
    </ScrollView>
  );
};

export default DeleteAccount1Screen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    height: "100%",
    alignContent: "center",
  },
  textContainer: {
    marginTop: 30,
  },
  paragraph: {
    fontFamily: "MontserratMedium",
    fontSize: 14,
    color: "#7D7D7D",
    marginBottom: 0,
    textAlign: "left",
    marginHorizontal: 16,
  },
  inputContainer2: {
    marginHorizontal: 16,
    backgroundColor: "#0697DC0A",
    borderWidth: 1,
    borderColor: "#0697DC",
    borderRadius: 8,
    marginTop: 33.5,
  },
  bigInput: {
    fontSize: 14,
    textAlignVertical: 'top',
    fontFamily: "MontserratMedium",
    textAlign: "left",
    color: "#174B9D",
    paddingHorizontal: 10,
    width: "100%",
  },
  button: {
    marginTop: 90,
    marginBottom: 50,
    marginHorizontal: 16,
  },
});
