import React, { useState, useEffect } from "react";
import { View, FlatList, StyleSheet, Text, Alert } from "react-native";

import {
  GradientComponent,
  SimpleHeaderComponent,
  EarningsHistoryListItems,
  DefisPointsListItems,
  Loader,
} from "../components";
import { windowHeight, windowWidth } from "../themes";
import { moderateVerticalScale } from "react-native-size-matters";
import { useQuery } from "react-query";
import { getDefisPointsLogged, getDefisPointsNotLogged } from "../api/challenges";
import { selectIsLogged } from "../state/auth";
import { useSelector } from "react-redux";


const DefisPointsScreen = ({ navigation }) => {

  const isLogged = useSelector(selectIsLogged);
  const [defisData, setData] = useState([]);
  const [isLoaded, setLoaded] = useState(false);


  if (isLogged){
      const { data, isLoading } = useQuery('defis',getDefisPointsLogged,{
        onSuccess : data =>{
          // console.log(data)
          setData(data)
          setLoaded(true)
        },
        onError: error =>{
          if(error.message === 'Request failed with status code 401'){
              Alert.alert('Error')
          }else{
              Alert.alert('Error')
          }
        },
            cacheTime : 0
        }
        );
  }else{
    const { data, isLoading } = useQuery('defisno',getDefisPointsNotLogged,{
      onSuccess : data =>{
        console.log(data + "Not logged")
        setData(data)
        setLoaded(true)
      },
      onError: error =>{
        if(error.message === 'Request failed with status code 401'){
            Alert.alert('Error')
        }else{
            Alert.alert('Error')
        }
      },
          cacheTime : 0
      }
      );
    }



  return (
    
    <View style={styles.screenContainer}>

      <GradientComponent
        colors={["#E2F2FF", "#FFFFFF"]}
        style={styles.backgroundGradient}
      />
      
      <View style={styles.contentContainer}>
        <FlatList
          ListHeaderComponent={
            <View style={styles.headerContainer}>
              <SimpleHeaderComponent title="Défis Point KréoCarte" />
        {!isLoaded && <View style={{flex : 1 , justifyContent : 'center'}}>
              <Loader/>
        </View>}
              <View style={styles.text}>
                    <Text style={styles.textStyle}>
                            {"Comment cagnotter\ndes points KréoCarte ?"}
                    </Text>
              </View>
            </View>
          }
          ListFooterComponent={<View />}
          ListFooterComponentStyle={{ marginBottom: 40 }}
          data={defisData}
          renderItem={({ item }) => (
            <DefisPointsListItems {...item} />
          )}
          keyExtractor={(notification) => notification.id}
          showsVerticalScrollIndicator={false}
        />
      </View>
    </View>
  );
};

export default DefisPointsScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    justifyContent: "flex-start",
  },
  headerContainer: {
    marginBottom: 20,
  },
  text: {
      marginTop:30,
    alignItems:'center',
    justifyContent:'center',
  },
  textStyle:{
    fontFamily: "MontserratSemiBold",
    fontSize: 16,
    color: "#174B9D",
  }
});
