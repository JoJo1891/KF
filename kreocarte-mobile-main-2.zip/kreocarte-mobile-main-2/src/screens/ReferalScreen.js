import React from "react";
import {
  Text,
  View,
  Alert,
  StyleSheet,
  TextInput,
  ScrollView,
} from "react-native";
import { useMutation, useQueryClient } from "react-query";

import GofidButton from "../components/partials/GofidButton";
import { Formik } from "formik";
import { moderateScale } from "react-native-size-matters";
import { useNavigation } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";

import LottieView from "lottie-react-native";
import { useReferalCode } from "../api/user";

const ReferalScreen = () => {
  const queryClient = useQueryClient();
  const navigation = useNavigation();

  const { mutate, isLoading, isError } = useMutation(useReferalCode, {
    onSuccess: (response) => {
      registerData();
      Alert.alert("Succès", "Opération réussie !");
      navigation.navigate("HomeScreen");
    },
    onError: (error) => {
      console.log(error);
      Alert.alert("Error", "ce code est invalide");
    },
    onSettled: () => {
      queryClient.invalidateQueries("useReferalCode");
    },
  });

  const registerData = async () => {
    try {
      const bool = "true";
      await AsyncStorage.setItem("referal", bool);
      navigation.navigate("HomeScreen");
    } catch (e) {
      console.log(e);
    }
  };

  const pressNext = () => {
    registerData();
  };

  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <View style={styles.screenContainer}>
        <View style={styles.header}>
          <View style={styles.center}>
            <View>
              <Text style={styles.title}>Parrainage</Text>
            </View>
          </View>
        </View>

        <View style={styles.center}>
          <View style={{ paddingTop: moderateScale(20) }}>
            <LottieView
              style={{ width: moderateScale(180), height: moderateScale(180) }}
              source={require("../assets/icons/lottie/referal.json")}
              autoPlay
              loop={false}
            />
          </View>
        </View>

        <View style={{ paddingTop: moderateScale(10) }}>
          <Text style={styles.text}>
            Si vous avez un code de parrainage, entrez-le pour obtenir des
            points gratuits dans KréoCarte. Plus tard, vous pouvez générer des
            points pour inviter vos amis à l'application
          </Text>
        </View>

        <Formik
          initialValues={{
            referal: "",
          }}
          onSubmit={(values) => {
            mutate(values);
          }}
        >
          {({ handleChange, handleBlur, handleSubmit }) => (
            <>
              <View style={styles.inputContainer}>
                <TextInput
                  type="text"
                  style={styles.inputTxt}
                  placeholder="Code"
                  onChangeText={handleChange("referal")}
                  onBlur={handleBlur("referal")}
                  placeholderTextColor="#174B9D"
                />
              </View>

              <View style={{ marginTop: moderateScale(120) }}>
                <GofidButton press={pressNext} name="white" value="Sauter" />
              </View>

              <View
                style={{
                  marginTop: moderateScale(10),
                  marginBottom: moderateScale(50),
                }}
              >
                <GofidButton
                  disabled={isLoading}
                  press={handleSubmit}
                  name="blue"
                  value="Enregistrer"
                />
              </View>
            </>
          )}
        </Formik>
      </View>
    </ScrollView>
  );
};

export default ReferalScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    marginHorizontal: 16,
    height: "100%",
    alignContent: "center",
  },
  center: {
    justifyContent: "center",
    alignItems: "center",
    flex: 1,
  },
  header: {
    alignItems: "center",
    flexDirection: "row",
    paddingTop: moderateScale(80),
    width: "100%",
    marginBottom: moderateScale(23),
  },
  title: {
    fontFamily: "MontserratBold",
    fontSize: moderateScale(20),
    color: "#174B9D",
    paddingBottom: 4,
    textAlign: "left",
  },
  text: {
    fontFamily: "MontserratMedium",
    fontSize: moderateScale(13),
    color: "#989898",
    textAlign: "center",
  },

  inputContainer: {
    flexDirection: "row",
    alignItems: "stretch",
    backgroundColor: "#0697DC0A",
    borderWidth: 1,
    borderColor: "#0697DC",
    borderRadius: 8,
    marginTop: moderateScale(50),
    height: moderateScale(50),
    width: "100%",
    alignItems: "center",
  },
  inputTxt: {
    fontSize: moderateScale(14),
    fontFamily: "MontserratMedium",
    textAlign: "left",
    color: "#174B9D",
    height: moderateScale(50),
    paddingHorizontal: moderateScale(10),
    paddingVertical: moderateScale(5),
    width: "100%",
  },
});
