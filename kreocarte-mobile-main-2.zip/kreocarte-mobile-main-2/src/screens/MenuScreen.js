import React ,{ useEffect} from 'react';
import {useSelector} from 'react-redux'
import { useNavigation } from '@react-navigation/native';
import {
    View,
    StyleSheet,
    Text,ScrollView, BackHandler, Alert
} from 'react-native';

import { GradientComponent, MenuComponents } from '../components';
import Disconnection from '../components/partials/Disconnection';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { selectIsLogged ,selectUser} from '../state/auth';
import { windowHeight } from "../themes";


const MenuScreen = () => {

    const navigationP = useNavigation();
    const isLogged = useSelector(selectIsLogged)
    const user = useSelector(selectUser)
    
    const getData = async () => {
        try {
            const value = await AsyncStorage.getItem('menu_tutorial')
            if(value !== null )  {
               //console.log(value)
            }else{
                navigationP.navigate('Menu2Tutorial1');
            }
        } catch(e) {
            // return value = false;
        }
    }

    const backAction = () => {
        if (navigationP.isFocused()) {
          Alert.alert("Attendez!", "Êtes-vous sûr de vouloir quitter l’application ?", [
            {
              text: "Annuler",
              onPress: () => null,
              style: "cancel"
            },
            { text: "Oui", onPress: () => BackHandler.exitApp() }
          ]);
          return true;
        }
      };
      
      const backHandler = BackHandler.addEventListener(
        "hardwareBackPress",
        backAction
      );

    useEffect(() => {
        getData();
      }, []); 
    

    return (


        <View style={styles.screenContainer}>
        <GradientComponent colors={['#E2F2FF','#FFFFFF']} style={styles.backgroundGradient}/>
            <View style={styles.contentContainer}>
                <ScrollView>  
                    <View> 
                        <MenuComponents user={user} name={user ? user.nom || user.email : 'Invité'} img={null} menuAct={isLogged}/>  
                    </View>    
                    <View style={{paddingTop:35.5, paddingBottom:50}} > 
                        <Disconnection/>  
                    </View>    
                </ScrollView>
            </View>
        </View>

 )
}

export default MenuScreen;

const styles = StyleSheet.create({
    screenContainer: {
        flex: 1,
        backgroundColor: "white"
      },
      backgroundGradient : {
        height : windowHeight/2
      },
      contentContainer : {
        position : 'absolute',
        top : 0,
        left : 0,
        bottom : 0,
      },
      center:{
          alignContent:'center'
      }

});