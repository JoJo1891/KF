import HomeScreen from "./HomeScreen";
import LoginScreen from "./LoginScreen";
import ForgotPasswordScreen from "./ForgotPasswordScreen";
import SliderScreen from "./SliderScreen";
import EmailPasswordScreen from "./EmailPasswordScreen";
import RegisterScreen from "./RegisterScreen";
import InscriptionScreen from "./InscriptionScreen";
import CardScreen from "./CardScreen";
import CatalogScreen from "./CatalogScreen";
import AdvantagesScreen from "./AdvantagesScreen";
import BonusPlansScreen from "./BonusPlansScreen";
import DealsScreen from "./DealsScreen";
import CashBackScreen from "./CashBackScreen";
import CashBackCodeScreen from "./CashBackCodeScreen";
import SelectZoneScreen from "./SelectZoneScreen";
import CompteScreen from "./CompteScreen";
import MenuScreen from "./MenuScreen";
import ParameterScreen from "./ParameterScreen";
import HelpScreen from "./HelpScreen";
import Inscription from "./Inscription";
import ContactScreen from "./ContactScreen";
import CguScreen from "./CguScreen";
import MesPointsScreen from "./MesPointsScreen";
import RatingPage from "./RatingPage";
import RecommendScreen from "./RecommendScreen";
import FaqsScreen from "./FaqsScreen";
import RequestAccountScreen from "./RequestAccountScreen";
import DeleteAccountScreen from "./DeleteAccountScreen";
import CardsScreen from "./CardsScreen";
import WhoWeAreScreen from "./WhoWeAreScreen";
import ConfianceScreen from "./ConfianceScreen";
import NotificationScreen from "./NotificationScreen";
import HomeTutorialStep1 from "./tutorial/HomeTutorialStep1";
import ScannerScreen from "./ScannerScreen";
import ScannerScreenError from "./ScannerScreenError";
import CardSuccessScreen from "./CardSuccessScreen";
import ProfileScreen from "./ProfileScreen";
import ReferalScreen from "./ReferalScreen";
import SecurityScreen from "./SecurityScreen";
import DeleteAccount1Screen from "./DeleteAccount1Screen";
import AccountDeletedScreen from "./AccountDeletedScreen";
import SetNotificationScreen from "./SetNotificationScreen";
import ManualCardScreen from "./ManualCardScreen";
import EarningsHistoryScreen from "./EarningsHistoryScreen";
import ChallengeScoringScreen from "./ChallengeScoringScreen";
import HomeTutorialStep2 from "./tutorial/HomeTutorialStep2";
import HomeTutorialStep3 from "./tutorial/HomeTutorialStep3";
import HomeTutorialStep4 from "./tutorial/HomeTutorialStep4";
import HomeTutorialStep5 from "./tutorial/HomeTutorialStep5";
import MesPointsTutorial1 from "./tutorial/MesPointsTutorial1";
import MesPointsTutorial2 from "./tutorial/MesPointsTutorial2";
import MesPointsTutorial3 from "./tutorial/MesPointsTutorial3";
import Menu2Tutorial1 from "./tutorial/Menu2Tutorial1";
import Menu2Tutorial2 from "./tutorial/Menu2Tutorial2";
import Menu2Tutorial3 from "./tutorial/Menu2Tutorial3";
import Home3Tutorial1 from "./tutorial/Home3Tutorial1";
import Home3Tutorial2 from "./tutorial/Home3Tutorial2";
import CardScreenTurorial1 from "./tutorial/CardScreenTurorial1";
import CardScreenTurorial2 from "./tutorial/CardScreenTurorial2";
import CardScreenTurorial3 from "./tutorial/CardScreenTurorial3";
import CardScreenTurorial4 from "./tutorial/CardScreenTurorial4";
import CardScreenTurorial5 from "./tutorial/CardScreenTurorial5";
import CardScreenTurorial6 from "./tutorial/CardScreenTurorial6";
import CardScreenTurorial7 from "./tutorial/CardScreenTurorial7";
import CardScreenTurorial8 from "./tutorial/CardScreenTurorial8";
import ProgramesFidelitesScreen from "./ProgramesFidelitesScreen";
import PointsAideScreen from "./PointsAideScreen";
import DefisPointsScreen from "./DefisPointsScreen";
import CardErrorScreen from "./CardErrorScreen";
import ScannerBPScreen from "./ScannerBPScreen";
import HistoryPointsPrograms from "./HistoryPointsPrograms";

export {
  HomeScreen,
  LoginScreen,
  ForgotPasswordScreen,
  SliderScreen,
  EmailPasswordScreen,
  RegisterScreen,
  InscriptionScreen,
  SelectZoneScreen,
  MenuScreen,
  CompteScreen,
  ProfileScreen,
  ReferalScreen,
  ParameterScreen,
  HelpScreen,
  Inscription,
  ContactScreen,
  CguScreen,
  RecommendScreen,
  FaqsScreen,
  RequestAccountScreen,
  DeleteAccountScreen,
  DeleteAccount1Screen,
  AccountDeletedScreen,
  SetNotificationScreen,
  WhoWeAreScreen,
  ConfianceScreen,
  SecurityScreen,
  CardScreen,
  CatalogScreen,
  AdvantagesScreen,
  BonusPlansScreen,
  DealsScreen,
  CashBackScreen,
  CashBackCodeScreen,
  ScannerScreen,
  ScannerScreenError,
  CardSuccessScreen,
  CardsScreen,
  NotificationScreen,
  MesPointsScreen,
  RatingPage,
  ManualCardScreen,
  HomeTutorialStep1,
  HomeTutorialStep2,
  HomeTutorialStep3,
  HomeTutorialStep4,
  HomeTutorialStep5,
  MesPointsTutorial1,
  MesPointsTutorial2,
  MesPointsTutorial3,
  Menu2Tutorial1,
  Menu2Tutorial2,
  Menu2Tutorial3,
  Home3Tutorial1,
  Home3Tutorial2,
  CardScreenTurorial1,
  CardScreenTurorial2,
  CardScreenTurorial3,
  CardScreenTurorial4,
  CardScreenTurorial5,
  CardScreenTurorial6,
  CardScreenTurorial7,
  CardScreenTurorial8,
  EarningsHistoryScreen,
  ChallengeScoringScreen,
  ProgramesFidelitesScreen,
  PointsAideScreen,
  DefisPointsScreen,
  CardErrorScreen,
  ScannerBPScreen,
  HistoryPointsPrograms,
};
