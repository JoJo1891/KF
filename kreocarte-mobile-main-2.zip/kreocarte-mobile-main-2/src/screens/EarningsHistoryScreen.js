import React, { useState, useEffect } from "react";
import { View, FlatList, StyleSheet, Alert } from "react-native";

import {
  GradientComponent,
  SimpleHeaderComponent,
  EarningsHistoryListItems,
  VerticalListComponent,
  Loader,
} from "../components";
import { windowHeight, windowWidth } from "../themes";
import { getDefisPointsHistory } from "../api/challenges";
import { useQuery } from "react-query";
import { verticalScale } from "react-native-size-matters";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";

const EarningsHistoryScreen = ({ navigation }) => {
  const [dataList, setData] = useState([]);
  const dList = dataList.reverse();

  const { data, isLoading } = useQuery("defis", getDefisPointsHistory, {
    onSuccess: (data) => {
      setData(data);
    },
    onError: (error) => {
      if (error.message === "Request failed with status code 401") {
        Alert.alert("Error");
      } else {
        Alert.alert("Error");
      }
    },
    cacheTime: 0,
  });

  return (
    <View style={styles.screenContainer}>
      <GradientComponent
        colors={["#E2F2FF", "#FFFFFF"]}
        style={styles.backgroundGradient}
      />

      <View style={styles.contentContainer}>
        <VerticalListComponent
          header={
            <View>
              <SimpleHeaderComponent title="Historique de gains" />
              {isLoading && (
                <View style={styles.loaderContainer}>
                  <Loader />
                </View>
              )}
            </View>
          }
          ItemComponent={(item) => <EarningsHistoryListItems {...item} />}
          data={dList}
        />
      </View>
    </View>
  );
};

export default EarningsHistoryScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: "white",
    marginTop: moderateVerticalScale(7),

  },
  backgroundGradient: {
    height: windowHeight / 2,
  },
  headerContainer: {
    marginBottom: 20,
  },
  loaderContainer: {
    marginTop: verticalScale(windowHeight / 2 - 100),
  },
  contentContainer: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    justifyContent: "flex-start",
    marginHorizontal: moderateScale(15),
  },
});
