import React, { useState, useEffect } from "react";
import { Text, View, StyleSheet } from "react-native";
import { ScrollView } from "react-native";
import {
  ModalComponent,
  SimpleHeaderComponent,
  StoreInfoModal,
} from "../components";
import PointsIcon from "../assets/icons/5_gf-pts.svg";
import Icon1 from "../assets/icons/recomm_icon_1.svg";
import Icon2 from "../assets/icons/recomm_icon_2.svg";
import Icon3 from "../assets/icons/recomm_icon_3.svg";
import GofidButton from "../components/partials/GofidButton";
import ShareModal from "../components/ModalComponent/ShareModal";
import { requestReferalCode } from "../api/user";
import { useMutation, useQueryClient } from "react-query";

const RecommendScreen = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [data, setData] = useState("");
  const handlerModalVisible = () => {
    setModalVisible(!modalVisible);
  };

  const { isLoading, mutate } = useMutation(requestReferalCode, {
    onSuccess: (data) => {
      setData(data);
    },
    onError: (error) => {
      Alert.alert(
        "Erreur lors de la tentative d'obtention du code de parrainage"
      );
      console.log(error);
    },
    onSettled: () => {
      queryClient.invalidateQueries("requestReferalCode");
    },
  });

  useEffect(() => {
    mutate();
  }, []);

  return (
    <ScrollView style={{ backgroundColor: "white" }}>
      <ModalComponent modalVisible={modalVisible} bgType={true}>
        <ShareModal
          referal={data?.referral_code}
          onClose={() => setModalVisible(!modalVisible)}
        />
      </ModalComponent>
      <SimpleHeaderComponent title="Recommandez" />

      <View style={styles.screenContainer}>
        <View>
          <Text style={styles.title}>
            Invite tes amis et gagne des Points KréoCarte’ !
          </Text>
        </View>

        <View style={{ marginTop: 10 }}>
          <Text style={styles.text}>
            Pour chaque utilisateurs à qui vous partagerez l’application, gagnez
          </Text>
        </View>

        <View style={{ marginVertical: 20 }}>
          <PointsIcon />
        </View>

        <View>
          <Text style={styles.title2}>Comment ça marche ?</Text>
        </View>

        <View style={{ marginTop: 10 }}>
          <Text style={styles.text}>
            Vos amis doivent télécharger KréoCarte’ {"\n"}via votre invitation.
          </Text>
        </View>

        <View style={styles.iconContainer}>
          <View style={styles.icon}>
            <Icon1 style={styles.iconSpace} />
            <Text style={styles.iconTxt}>Inviter {"\n"}un ami</Text>
          </View>

          <View style={styles.icon}>
            <Icon2 style={styles.iconSpace} />
            <Text style={styles.iconTxt}>
              Votre ami {"\n"}Télécharge {"\n"}KréoCarte'
            </Text>
          </View>

          <View style={styles.icon}>
            <Icon3 style={styles.iconSpace} />
            <Text style={styles.iconTxt}>Il s’inscrit</Text>
          </View>
        </View>

        <View style={styles.button}>
          <GofidButton
            name="blue"
            value="Partager"
            press={handlerModalVisible}
          />
        </View>
      </View>
    </ScrollView>
  );
};

export default RecommendScreen;

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    marginHorizontal: 16,
    alignItems: "center",
    height: "100%",
    alignContent: "center",
    paddingTop: 50,
  },
  title: {
    fontFamily: "MontserratSemiBold",
    fontSize: 30,
    color: "#174B9D",
    textAlign: "center",
    marginHorizontal: 13,
  },
  text: {
    fontFamily: "MontserratMedium",
    fontSize: 14,
    color: "#7D7D7D",
    textAlign: "center",
  },
  title2: {
    fontFamily: "MontserratSemiBold",
    fontSize: 25,
    color: "#174B9D",
    textAlign: "center",
  },
  iconContainer: {
    flex: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "flex-start",
    marginTop: 47,
  },
  icon: {
    width: "33.33%",
  },
  iconSpace: {
    marginBottom: 8,
    marginLeft: 30,
  },
  iconTxt: {
    fontFamily: "MontserratSemiBold",
    fontSize: 14,
    color: "#174B9D",
    textAlign: "center",
  },
  button: {
    marginTop: 50,
    marginBottom: 30,
    width: "100%",
  },
});
