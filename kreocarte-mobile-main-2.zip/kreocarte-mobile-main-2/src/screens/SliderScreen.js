import React, { useState } from "react";
import { useNavigation } from "@react-navigation/core";
import AppIntroSlider from "react-native-app-intro-slider";

import {
  Text,
  View,
  StatusBar,
  Image,
  StyleSheet,
  ImageBackground,
  TouchableOpacity,
  BackHandler,
  Alert,
} from "react-native";

import AsyncStorage from "@react-native-async-storage/async-storage";
import { moderateScale } from "react-native-size-matters";

const SliderScreen = () => {
  const data = [
    {
      key: 1,
      text: "Bienvenue sur l’application carte fidélité par excellence et bienvenue dans l’univers GO Nord ! Retrouvez tous vos commerçants préférés et dématérialisez toutes vos cartes de fidélité physique.",
      image: require("../assets/icons/inicial.png"),
      background: require("../assets/fondo1.png"),
    },
    {
      key: 2,
      text: "Cumulez des points Kréocarte’ qui vous permettront de profiter de nombreux bons plans exclusifs sur toute l’année ",
      image: require("../assets/logo2.png"),
      background: require("../assets/fondo2.png"),
    },
    {
      key: 3,
      text: "Bénéficiez des récompenses exclusives de vos commerçants préférés !",
      image: require("../assets/logo3.png"),
      background: require("../assets/fondo3.png"),
    },
  ];

  const navigation = useNavigation();

  const pressNext = () => {
    navigation.replace("ConfianceScreen");
  };

  const backAction = () => {
    if (navigation.isFocused()) {
      Alert.alert("Attendez!", "Êtes-vous sûr de vouloir quitter l’application ?", [
        {
          text: "Annuler",
          onPress: () => null,
          style: "cancel"
        },
        { text: "Oui", onPress: () => BackHandler.exitApp() }
      ]);
      return true;
    }
  };
  
  const backHandler = BackHandler.addEventListener(
    "hardwareBackPress",
    backAction
  );

  const renderItem = ({ item }) => {
    return (
      <View style={styles.slide}>
        <ImageBackground
          source={item.background}
          style={styles.image_backgrounds}
        >
          <Image
            source={item.image}
            style={styles.image}
            // width={item.width}
            // height={item.height}
          />

          <View style={styles.containers}>
            <Text style={styles.text}>{item.text}</Text>
            <TouchableOpacity style={styles.button} onPress={pressNext}>
              <Text style={styles.text2}>Suivant</Text>
            </TouchableOpacity>
          </View>
        </ImageBackground>
      </View>
    );
  };

  const keyExtractor = (item) => item.key;

  return (
    <View style={{ flex: 1 }}>
      <StatusBar translucent backgroundColor="transparent" />
      <AppIntroSlider
        keyExtractor={keyExtractor}
        renderItem={renderItem}
        style={{
          flex: 1,
        }}
        data={data}
        dotStyle={styles.dot}
        showSkipButton={false}
        showNextButton={false}
        activeDotStyle={styles.activeDotStyle}
        doneLabel=""
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
  },
  image_backgrounds: {
    flex: 1,
    resizeMode: "cover",
    alignItems: "center",
  },
  image: {
    marginTop: moderateScale(65),
    backgroundColor: "transparent",
    flex: 1,
    width: moderateScale(400),
    height: moderateScale(400),
    resizeMode: "contain",
  },
  slide: {
    flex: 1,
    backgroundColor: "#0697DC",
  },
  text: {
    fontSize: moderateScale(15),
    color: "#FFFFFF",
    textAlign: "left",
    fontFamily: "Nexa",
    opacity: 0.9,
    marginHorizontal: 16,
    marginTop: 100,
    lineHeight: 22,
    justifyContent: "center",
    height: 140,
  },
  text2: {
    fontSize: moderateScale(20),
    color: "#174B9D",
    textAlign: "center",
    fontFamily: "MontserratSemiBold",
    alignItems: "center",
  },
  activeDotStyle: {
    backgroundColor: "#0697DC",
  },
  dot: {
    backgroundColor: "#FFFFFF",
    width: 6,
    height: 6,
  },
  containers: {
    flex: 1,
    justifyContent: "flex-end",
    paddingHorizontal: 10,
    marginBottom: 74,
  },
  button: {
    textAlign: "center",
    backgroundColor: "#FFFFFF",
    padding: 10,
    borderRadius: 25,
  },
});

export default SliderScreen;
