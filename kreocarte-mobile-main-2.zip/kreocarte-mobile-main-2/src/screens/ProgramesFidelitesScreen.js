import React ,{ useState} from 'react';
import {Text,View,StyleSheet} from 'react-native';
import { ScrollView } from 'react-native';


import { SimpleHeaderComponent } from '../components';
import { useNavigation } from '@react-navigation/native';


const ProgramesFidelitesScreen = () => {

        const navigation = useNavigation();

   
        return(
            <ScrollView style={{backgroundColor:'white'}}>
            <SimpleHeaderComponent title="Programmes de fidélités" />
            <View style={styles.screenContainer}>

                <View style={styles.textContainer}>
                        <Text style={styles.paragraph}>
                            <Text style={styles.title}>
                                Qu'est-ce qu’une carte de fidélité ? {"\n\n"}
                            </Text>
                            {'C’est une carte qui vous permet de bénéficier de plusieurs avantages (récompenses, cadeaux, contenu exclusif, accès privatif….), dans le commerce d’on vous la détenez. \n\n'}
                       
                            <Text style={styles.title}>
                             Quels types de cartes retrouvons-nous dans KréoCarte ?  {"\n\n"}
                             La carte à tampon {"\n"}
                            </Text>
                            {'La carte à tampon est une carte qui vous permet de cumuler des tampons à chaque achat dans votre commerce préféré.  \n\n'}

                            <Text style={styles.title}>
                                La carte à point {"\n"}
                            </Text>
                            {'La carte à point vous permet de cumuler des points de fidélité a chaque achat dans votre commerce préféré. \n\n'}

                            <Text style={styles.title}>
                              La carte cashback {"\n"}
                            </Text>
                            {'La carte cashback vous permet de cumuler des euros a chaque euro dépensé dans votre commerce préféré. \n\n'}

                            <Text style={styles.title}>
                                 Quels types de récompenses retrouvons-nous dans KréoCarte ? {"\n"}
                            </Text>
                            {'Vous retrouverez différentes types de récompenses tels que : des remises, des cadeaux, des chèques cadeaux, des bons d’achats, des euros… '}


                       </Text>
                </View>

            
            </View>
            </ScrollView>
        )
    

}


export default ProgramesFidelitesScreen;

const styles = StyleSheet.create({
    screenContainer: {
        flex: 1,
        marginHorizontal: 16,
        alignItems:'center',
        height:"100%", 
        alignContent:"center", 
        paddingTop:10
      },
      textContainer:{
            marginTop:20
      },
      title: {
        fontFamily: 'MontserratSemiBold',
        fontSize: 16,
        color: '#174B9D',
        flexDirection:"row", 
        textAlign: 'left',
    },
    paragraph: {
        fontFamily: 'MontserratRegular',
        fontSize: 16,
        color: '#7D7D7D',
        marginBottom:19

    }
    })