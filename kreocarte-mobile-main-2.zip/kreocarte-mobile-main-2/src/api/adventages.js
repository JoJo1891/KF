import api from './authApi'

export const getAdventages = async (id) =>{
    const result =  await api.get(`/cards/${id}/rewards`)
    return result.data
}