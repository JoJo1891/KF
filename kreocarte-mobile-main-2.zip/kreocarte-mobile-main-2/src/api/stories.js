import api from './api'
import authApi from './authApi'

export const getStories = async () =>{
    const result = await api.get(`/home/stories`)
    return result.data
}

export const getStoriesauth = async () =>{
    const result = await authApi.get(`/home/stories`)
    return result.data
}

export const setViewedStory = async (id) =>{
    const result = await authApi.post(`/home/stories/update-views/${id}`)
    return result.data
}