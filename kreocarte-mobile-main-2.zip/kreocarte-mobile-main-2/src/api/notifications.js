import api from './authApi'

export const getNotifications = async () =>{
    const result =  await api.get(`/notifications/`)
    return result.data
}

export const setNotificationsToken = async (token) =>{
    const result =  await api.put(`/notifications/update-token`,{
        token
    })
    return result.data
}

export const deleteNotificationsToken = async () =>{
    const result =  await api.delete(`/notifications/delete-token`)
    return result.data
}

export const allowNotifications = async () =>{
    const result =  await api.put(`/users/toggle-notifications`)
    return result.data
}

export const allowEmailNotifications = async () =>{
    const result =  await api.post(`/users/me/toggle-email-notifications`)
    return result.data
}

export const deleteNotificationById = async (id) =>{
    const result =  await api.delete(`/notifications/delete/${id}`)
    return result.data
}

export const deleteNotificationByUser = async () =>{
    const result =  await api.delete(`/notifications/delete`)
    return result.data
}

export const saveNotification = async ({message, type, card_id }) =>{
    const result =  await api.post(`/notifications/new`,{
        message: message, 
        type: type, 
        card_id: card_id 
    })
    return result.data
}


