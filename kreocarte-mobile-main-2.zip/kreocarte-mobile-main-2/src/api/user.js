import api from "./authApi";
import api2 from "./api";
import dayjs from "dayjs";

export const getUser = async () => {
  const result = await api.get("/users/me");
  return result.data;
};

export const updateUser = async (values) => {
  if (values.datenaissance)
    values.datenaissance = dayjs(values.datenaissance).format("YYYY-MM-DD");
  const result = await api.put("/users/update", values);
  return result.data;
};

export const changePassword = async (values) => {
  const result = await api.put("/users/change-password", values);
  return result.data;
};

export const deleteAccount = async () => {
  const result = await api.delete("/users/delete");
  return result.data;
};

export const requestAccountData = async () => {
  const result = await api.get("/users/me/datas");
  return result.data;
};

export const requestReferalCode = async () => {
  const result = await api.get("/users/me/referral-code");
  return result.data;
};

export const useReferalCode = async ({ referal }) => {
  const result = await api.post(`/users/me/use-referral-code/${referal}`);
  return result.data;
};
export const requestResetPassword = async ({ email }) => {
  const result = await api2.post("/reset-password/request", { email });
  return result.data;
};

export const getHistoryPrograms = async () => {
  const result = await api.get("/users/historique-caisse");
  return result.data;
};
