import api from './api'

export const registerQuickly = async ({ email , plainPassword}) =>{
    const result =  await api.post('/users/add',{
        email,
        plainPassword
    })
    return result
}

export const register = async ({ email, nom, dateNaissance : datenaissance, sexe , plainPassword}) =>{
    return await api.post('/users/add',{
        email,
        nom, 
        datenaissance, 
        sexe,
        plainPassword
    })
}