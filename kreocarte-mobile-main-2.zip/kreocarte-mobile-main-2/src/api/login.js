import api from "./api";
export const login = async ({ email, password }) => {
  const response = await api.post("/login", {
    email,
    password,
  });
  return response.data;
};

export const authGoogleApi = async (token) => {
  const response = await api.post("/users/google-user/auth", {
    id_token: token,
  });
  return response.data;
};

export const authFacebookApi = async (token) => {
  const response = await api.post("/users/facebook-user/auth", {
    access_token: token,
  });
  return response.data;
};

export const authAppleApi = async (token) => {
  console.log("APPLE:", token);
  const response = await api.post("/users/apple-user/auth", {
    token,
  });
  return response.data;
};
