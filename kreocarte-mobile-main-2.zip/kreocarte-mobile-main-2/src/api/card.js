import api from './authApi'

export const getCardsByUser = async () =>{
    const result =  await api.get(`/cards/`)
    return result.data
}

export const getCard = async (id)=>{
    const result = await api.get(`/cards/${id}/show`)
    return result.data
}

export const createCardByStoreId = async ({storeId}) =>{
    const result = await api.post('/cards/add',{
        enseigne : storeId
    })
    return result.data
}

export const createCardManually = async ({storeId,cardNumber}) =>{
    const result = await api.post('/cards/add-manually',{
        enseigne : storeId,
        card_number : cardNumber
    })
    return result.data
}

export const createCashBackCode = async ({cardId,amount}) =>{
    const result = await api.post('/cadeaux/cashback',{
        carteFidelite : cardId,
        recompense : parseInt(amount)
    })
    return result.data
}

export const getCashBackById = async ({id}) =>{
    const result = await api.get(`/cadeaux/cashback/${id}`)
    return result.data[0]
}

export const cancelCashBackCode = async ({id}) =>{
    const result = await api.post(`/cadeaux/cashback/${id}/cancel`)
    return result.data
}

export const qrAddPoints = async ({code}) =>{
    const result = await api.post('/cards/add-points',{
        qrcode : code
    })
    return result.data
}

export const deleteCard = async ({id}) =>{
    const result = await api.delete(`/cards/${id}/delete`,{
        id
    })
    return result.data
}

