import api from './api'

export const getSlider= async () =>{
    const result = await api.get(`/home/slider`)
    return result.data.medias
}