import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";

//dev: https://dev2.mediafid.fr/api/v3/users/historique-caisse
//prod: https://mediafid.fr/api/v3

const api = axios.create({
  baseURL: "https://mediafid.fr/api/v3",
});

api.interceptors.request.use(async (req) => {
  const token = await AsyncStorage.getItem("token");
  req.headers["Authorization"] = `Bearer ${token}`;
  return req;
});

api.interceptors.response.use(async (res) => {
  if (res.status === 401) {
    await AsyncStorage.removeItem("token");
  }
  return res;
});

export default api;
