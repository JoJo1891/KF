import api from './authApi'

export const getCatalog = async (id) =>{
    // console.log(id)
    const result =  await api.get(`/enseignes/${id}/catalogue`)
    // console.log(result.data)
    return result.data
}