import api from "./authApi";
import api2 from "./api";

export const getDefisPointsLogged = async () => {
  const result = await api.get(`/defis/list`);
  return result.data;
};

export const getDefisPointsNotLogged = async () => {
  const result = await api2.get(`/home/defis`);
  return result.data;
};

export const getDefisPointsHistory = async () => {
  const result = await api.get(`/defis/history`);
  return result.data;
};

export const getDealsList = async () => {
  const result = await api.get(`/deals/user/list`);
  return result.data;
};

export const requestCodeDeal = async ({ deal_id }) => {
  const result = await api.post(`/deals/${deal_id}/unlock`);
  return result.data;
};
