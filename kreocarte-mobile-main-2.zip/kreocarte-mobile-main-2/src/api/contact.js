import api from './api'
import authApi from './authApi'

export const requestContactFormAuth = async ({ email, subject, message }) => {
  const result = await authApi.post("/users/question-gofid", {
    email,
    subject,
    message,
  });
  return result.data;
};

export const requestContactForm = async ({ email, subject, message }) => {
    const result = await api.post("/users/anonymous-question-gofid", {
      email,
      subject,
      message,
    });
    return result.data;
  };

