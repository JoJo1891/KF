import api from './authApi'

export const review = async ({ note, storeId }) => {
  const result = await api.post("/enseignes/review", {
    note:note,
    enseigne: storeId,
  });
  return result.data;
};
