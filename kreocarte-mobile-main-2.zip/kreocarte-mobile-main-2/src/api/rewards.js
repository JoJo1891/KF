import api from './authApi'

export const getRewards = async (id) =>{
    const order = {ACTIF : 1, UNLOCK : 2, UTILISE: 3, CANCEL:4};
    
    const result =  await api.get(`/cards/${id}/plans`)
    result.data.sort((
        (a, b) => order[a.status] - order[b.status])
      );
    return result.data
}

export const unlockBonPlan = async (id) =>{
    const result =  await api.post(`/cadeaux/${id}/unlock-bonplan`)
    return result.data
}

export const useBonPlanScanning = async (id) =>{
    const result =  await api.post(`/cadeaux/${id}/use-bonplan`)
    return result.data
}