import axios from "axios";
//dev: https://dev2.mediafid.fr/api/v3/users/historique-caisse
//prod: https://mediafid.fr/api/v3
const api = axios.create({
  baseURL: "https://mediafid.fr/api/v3",
  headers: {
    accept: "application/json",
  },
});

export default api;
