import api from './api'
import authApi from './authApi'

const getStores = async (zone) =>{
    const result = await api.get(`/enseignes/${zone}/zone`)
    return result.data
}

const getStoresAuth = async (zone) =>{
    const result = await authApi.get(`/enseignes/${zone}/zone-logged`)
    return result.data
}

const getStoresWithoutCards = async () =>{
    const result = await authApi.get(`/enseignes/all`)
    return result.data.map(({ id, nom }) => {
        return { id, name : nom };
    });
}

const useWhatsapp = async () =>{
    const result = await authApi.post(`/enseignes/items-request/add-points`)
    return result.data
}



export {
    getStores,
    getStoresAuth,
    getStoresWithoutCards,
    useWhatsapp
}