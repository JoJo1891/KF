import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Platform,
  UIManager,
} from "react-native";
import { moderateScale, s } from "react-native-size-matters";
import { windowHeight, layoutStyles } from "../../themes";
import Points from '../../assets/icons/gf_points.svg'
import PointsGrey from '../../assets/icons/gf_points_text_gray.svg'
import GfActive from '../../assets/icons/gf_notification.svg'
import GfInactive from '../../assets/icons/gf_notification_grey.svg'



if (
  Platform.OS === "android" &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const DefisPointsListItems = ({ id, is_done, name, points }) => {
  
  return (
    <View style={[styles.container, layoutStyles.elevation]}>
        {!is_done &&
        <View style={{flexDirection:'row', justifyContent:'space-between', alignItems:'center', width:'100%'}}>
            <View style={{flexDirection:"column", flexShrink:1, width:'22%', marginRight:5}}>
                <GfActive/>             
            </View>
            <View style={{flexDirection:"column", flexShrink:1, width:'78%'}}>
                <Text style={styles.textTitle}>{name}</Text>            
            </View>
            <View style={{flexDirection:'row', alignItems:'center'}}> 
                <Text style={styles.textPoint}> +{points} </Text>
                <Points/>                
            </View>
        </View>
         }
        {is_done &&
        <View style={{flexDirection:'row', justifyContent:'space-between', alignItems:'center', width:'100%'}}>
            <View style={{flexDirection:"column", flexShrink:1, width:'22%', marginRight:10}}>
                <GfInactive/>             
            </View>
            <View style={{flexDirection:"column", flexShrink:1, width:'78%'}}>
                <Text style={styles.textTitleGrey}>{name}</Text>            
            </View>
            <View style={{flexDirection:'row', alignItems:'center'}}> 
                <Text style={styles.textPointGrey}> +{points} </Text>
                <PointsGrey/>                
            </View>
        </View>
         }
    </View>
  );
};

export default DefisPointsListItems;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    height: windowHeight / 10,
    marginBottom: 20    ,
    marginTop: 5,
    borderRadius: 20,
    marginHorizontal: 15,
    paddingHorizontal: 15,
    justifyContent: "center",
  },
  textTitle: {
   fontSize : moderateScale(15),
   fontFamily: "MontserratSemiBold",
   color: "#174B9D",
   textAlign:'left'
  },
  textTitleGrey: {
    fontSize : moderateScale(15),
    fontFamily: "MontserratSemiBold",
    color: "#989898",
    textAlign:'left'
   },
  textPoint: {
    fontFamily: "MontserratBold",
    fontSize: moderateScale(25),
    color: "#174B9D",
    fontWeight:'bold'
  },
  textPointGrey: {
    fontFamily: "MontserratBold",
    fontSize: moderateScale(25),
    color: "#989898",
    fontWeight:'bold'
  },
});
