import React from 'react';

import {
  View,
  StyleSheet,
  Image,
  Text,
  TouchableOpacity,
  Platform,
} from 'react-native';

import {
  moderateScale,
  moderateVerticalScale,
} from 'react-native-size-matters';

import { windowHeight, windowWidth, layoutStyles } from '../../themes';
import FrontCart from '../Card/FrontCardComponent';
import BackCard from '../Card/BackCardComponent';
import GfWhiteIcon from '../../assets/icons/gf_white.svg';
import Carousel from 'react-native-reanimated-carousel';

const CardCarousel = ({ card, onChange, handleDeleteCard }) => {
  const renderItem = ({ item, index }) => {
    return (
      <>
        {Platform.isPad === true ? (
          <TouchableOpacity
            onLongPress={handleDeleteCard}
            activeOpacity={1}
            style={[styles.itemContainer, layoutStyles.elevation]}
          >
            {index === 0 ? (
              <FrontCart color={card?.enseigne?.card_color} />
            ) : (
              <BackCard color={card?.enseigne?.card_color} />
            )}
            {index === 0 ? (
              <View style={styles.cardContentContainer}>
                <View style={{ paddingLeft: 90 }}>
                  <Image
                    source={{ uri: item?.enseigne.image_url }}
                    resizeMode="contain"
                    style={styles.storeLogoContainer}
                  />
                </View>
                {item?.enseigne?.card_color === ('#ffffff' || 'white') ? (
                  <View style={{ paddingLeft: 90 }}>
                    <Text style={[styles.textMedium2, styles.customerNumber]}>
                      Numéro de carte
                    </Text>
                    <Text style={[styles.textMedium2, styles.cardNumber]}>
                      {item?.numero_carte}
                    </Text>
                  </View>
                ) : (
                  <View style={{ paddingLeft: 90 }}>
                    <Text style={[styles.textMedium, styles.customerNumber]}>
                      Numéro de carte
                    </Text>
                    <Text style={[styles.textMedium, styles.cardNumber]}>
                      {item?.numero_carte}
                    </Text>
                  </View>
                )}
              </View>
            ) : (
              <View style={styles.backContentContainer}>
                {item?.enseigne.card_color === ('#ffffff' || 'white') ? (
                  <View>
                    <View style={{ paddingLeft: 90 }}>
                      <GfWhiteIcon
                        width={moderateVerticalScale(50)}
                        height={moderateVerticalScale(50)}
                      />
                    </View>
                    <Text style={[styles.textMedium2, styles.rewards2]}>
                      RÉCOMPENSES
                    </Text>
                  </View>
                ) : (
                  <View>
                    <View style={{ paddingLeft: 90 }}>
                      <GfWhiteIcon
                        width={moderateVerticalScale(50)}
                        height={moderateVerticalScale(50)}
                      />
                    </View>
                    <Text style={[styles.textMedium, styles.rewards2]}>
                      RÉCOMPENSES
                    </Text>
                  </View>
                )}
              </View>
            )}
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            onLongPress={handleDeleteCard}
            activeOpacity={1}
            style={[styles.itemContainer, layoutStyles.elevation]}
          >
            {index === 0 ? (
              <FrontCart color={card?.enseigne?.card_color} />
            ) : (
              <BackCard color={card?.enseigne?.card_color} />
            )}
            {index === 0 ? (
              <View style={styles.cardContentContainer}>
                <Image
                  source={{ uri: item?.enseigne.image_url }}
                  resizeMode="contain"
                  style={styles.storeLogoContainer}
                />
                {item?.enseigne.card_color === ('#ffffff' || 'white') ? (
                  <View>
                    <Text style={[styles.textMedium2, styles.customerNumber]}>
                      Numéro de carte
                    </Text>
                    <Text style={[styles.textMedium2, styles.cardNumber]}>
                      {item?.numero_carte}
                    </Text>
                  </View>
                ) : (
                  <View>
                    <Text style={[styles.textMedium, styles.customerNumber]}>
                      Numéro de carte
                    </Text>
                    <Text style={[styles.textMedium, styles.cardNumber]}>
                      {item?.numero_carte}
                    </Text>
                  </View>
                )}
              </View>
            ) : (
              <View style={styles.backContentContainer}>
                {item?.enseigne.card_color === ('#ffffff' || 'white') ? (
                  <View>
                    <GfWhiteIcon
                      width={moderateVerticalScale(50)}
                      height={moderateVerticalScale(50)}
                    />
                    <Text style={[styles.textMedium2, styles.rewards]}>
                      RÉCOMPENSES
                    </Text>
                  </View>
                ) : (
                  <View>
                    <GfWhiteIcon
                      width={moderateVerticalScale(50)}
                      height={moderateVerticalScale(50)}
                    />
                    <Text style={[styles.textMedium, styles.rewards]}>
                      RÉCOMPENSES
                    </Text>
                  </View>
                )}
              </View>
            )}
          </TouchableOpacity>
        )}
      </>
    );
  };

  return (
    <View
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Carousel
        loop
        itemSpacing={30}
        width={windowWidth}
        height={windowHeight / 3}
        autoPlay={false}
        data={[card, card]}
        onSnapToItem={(index) => onChange(index)}
        renderItem={renderItem}
        style={{
          width: windowWidth - 30,
        }}
      />
    </View>
  );
};

export default CardCarousel;

const styles = StyleSheet.create({
  itemContainer: {
    width: windowWidth - 30,
    height: windowHeight / 3,
  },
  paginationDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginHorizontal: 8,
    backgroundColor: '#0697DC',
  },
  cardContentContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    justifyContent: 'space-between',
    paddingTop: moderateVerticalScale(40),
    paddingHorizontal: moderateScale(30),
    paddingBottom: moderateVerticalScale(50),
  },

  textBold: {
    fontFamily: 'MontserratBold',
    color: 'white',
  },
  textMedium: {
    fontFamily: 'MontserratMedium',
    color: 'white',
  },
  textMedium2: {
    fontFamily: 'MontserratMedium',
    color: 'black',
  },
  customerNumber: {
    marginTop: moderateVerticalScale(10),
    fontSize: moderateScale(15),
  },
  cardNumber: {
    fontSize: moderateScale(25),
  },
  storeLogoContainer: {
    width: moderateScale(120),
    height: moderateVerticalScale(90),
  },
  backContentContainer: {
    position: 'absolute',
    left: 0,
    bottom: 0,
    paddingHorizontal: moderateScale(30),
    paddingBottom: moderateVerticalScale(40),
    flexDirection: 'row',
    alignItems: 'center',
  },
  rewards: {
    fontSize: moderateScale(30),
    marginLeft: 5,
  },
  rewards2: {
    fontSize: moderateScale(30),
    marginLeft: 90,
  },
});
