import React from "react";

import { View, StyleSheet, Text, Image, TouchableOpacity } from "react-native";

import { useNavigation } from "@react-navigation/native";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";
import { layoutStyles } from "../../themes";

const StoreHeaderComponentRatingPage = ({ name, imageUrl }) => {
  const navigation = useNavigation();
  return (
    <View style={styles.headerContainer}>
      <View style={styles.storeInfoContainer}>

        {(imageUrl != null || imageUrl != undefined) && (
          <View style={[styles.storeImageContainer, layoutStyles.elevation]}>
            <Image
              source={{
                uri: imageUrl,
              }}
              style={styles.image}
              resizeMode="contain"
            />
          </View>
        )}
        {(name != null || name != undefined) && (
          <View>
            <Text style={[styles.textBold, styles.storeName]}>{name}</Text>
          </View>
        )}
      </View>
    </View>
  );
};

export default StoreHeaderComponentRatingPage;

const styles = StyleSheet.create({
  headerContainer: {
    flex: 1,
    flexDirection: "row",
    // justifyContent : 'space-between',
    alignItems: "center",
    paddingTop: moderateVerticalScale(30),
    paddingBottom: moderateVerticalScale(0),
    justifyContent: "center",
    alignItems: "center",
  },
  storeInfoContainer: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "flex-start",
    justifyContent: "center",
    alignItems: "center",
  },
  storeImageContainer: {
    width: moderateScale(60),
    height: moderateVerticalScale(60),
    borderRadius: moderateScale(40),
    overflow: "hidden",
    borderWidth: 2,
    borderColor: "white",
    marginLeft: 10,
  },
  backButtonContainer: {
    width: moderateScale(30),
  },
  image: {
    flex: 1,
  },
  text: {
    fontFamily: "MontserratRegular",
  },
  textBold: {
    fontFamily: "MontserratBold",
  },
  storeName: {
    fontSize: moderateScale(20),
    marginLeft: 7,
    color: "#343434",
  },
});
