import React from 'react';
import {
    View,
    StyleSheet,
    Text,Image,TouchableOpacity
} from 'react-native';
import { moderateScale, moderateVerticalScale } from 'react-native-size-matters';
import MapNord from '../../assets/maps/MAPS_GONORD_22.svg';


const GoNord = ({setGofid}) => {
    return (
    <View style={styles.screenContainer}>
                <View >
                    <Text style={styles.title}>
                        Bienvenue sur
                    </Text>
                </View>
                <View >
                    <Text style={styles.subtitle}>
                        KréoCarte
                    </Text>
                </View>
                <View style={{marginTop:moderateVerticalScale(30)}}>
                    <Text style={styles.subtitle2}>
                        Sélectionnez votre zone*
                    </Text>
                </View>

                <TouchableOpacity style={{alignItems: 'center', paddingTop:30}} onPress={setGofid}>
                    <View style={{height:moderateVerticalScale(300), width:moderateScale(300)}}>
                         <MapNord/>
                     </View>
                </TouchableOpacity>
                

      </View>
 )
}

export default GoNord;

const styles = StyleSheet.create({
    screenContainer : {
        flex: 1,
        justifyContent:'center',
        alignItems : 'center',
        height:"100%", 
        alignContent:"center"
    },
    title:{
        marginTop:50,
        fontSize: 40, 
        fontFamily: 'MontserratRegular',
        color: '#174B9D'
    },
    subtitle:{
        marginTop:0,
        fontSize: 40, 
        fontFamily: 'MontserratBoldItalic',
        color: '#174B9D'
    },
    subtitle2:{
        marginTop:0,
        fontSize: 24, 
        fontFamily: 'MontserratRegular',
        color: '#174B9D'
    },

});