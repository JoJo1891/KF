import React from 'react';
import {
    View,
    StyleSheet,
    Text,TouchableOpacity,Image
} from 'react-native';
import { moderateScale, moderateVerticalScale } from 'react-native-size-matters';
import GofidMap from '../../assets/maps/MAPS_GONORD_11.svg';


const Gofid = ({setGoNord}) => {
    return (
    <View style={styles.screenContainer}>
                <View >
                    <Text style={styles.title}>
                        Bienvenue sur
                    </Text>
                </View>
                <View >
                    <Text style={styles.subtitle}>
                        Kréocarte'
                    </Text>
                </View>
                <View style={{marginTop:moderateVerticalScale(30)}}>
                    <Text style={styles.subtitle2}>
                        Sélectionnez votre zone*
                    </Text>
                </View>
                

                <TouchableOpacity style={{alignItems: 'center', paddingTop:30}} onPress={setGoNord}>
                    <View style={{height:moderateVerticalScale(300), width:moderateScale(300)}}>
                         <GofidMap/>
                     </View>
                </TouchableOpacity>
                

      </View>
 )
}

export default Gofid;

const styles = StyleSheet.create({
    screenContainer : {
        flex: 1,
        justifyContent:'center',
        alignItems : 'center',
        height:"100%", 
        alignItems: 'center',
        marginHorizontal:16
    },
    title:{
        marginTop:50,
        fontSize: 40, 
        fontFamily: 'MontserratRegular',
        color: '#174B9D'
    },
    subtitle:{
        marginTop:0,
        fontSize: 40, 
        fontFamily: 'MontserratBoldItalic',
        color: '#174B9D'
    },
    subtitle2:{
        marginTop:0,
        fontSize: 24, 
        fontFamily: 'MontserratRegular',
        color: '#174B9D'
    },


});