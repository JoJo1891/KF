import React, { useState } from 'react';

import { View, StyleSheet, Image } from 'react-native';

import { windowHeight, windowWidth, layoutStyles } from '../../themes';
import Carousel from 'react-native-reanimated-carousel';

const Pagination = ({ dotsLength, activeDotIndex, dotStyle }) => {
  return (
    <View
      style={{
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginVertical: 20,
        columnGap: 30,
      }}
    >
      {Array.from({ length: dotsLength }).map((_, index) => (
        <View
          key={index}
          style={[
            dotStyle,
            index === activeDotIndex
              ? styles.paginationDot
              : styles.inactivePaginationDot,
          ]}
        />
      ))}
    </View>
  );
};

const CarouselComponent = ({ data }) => {
  const [activeSlide, setActiveSlide] = useState(0);

  const renderItem = ({ item, index }) => {
    return (
      <View style={[styles.itemContainer, layoutStyles.elevation]}>
        <Image
          source={{
            uri: item.url,
          }}
          style={{ flex: 1 }}
          resizeMode="cover"
        />
      </View>
    );
  };

  const getDotIndex = (index) => {
    if (index < 2) return index;
    while (index > 2) index -= 3;
    return index;
  };

  const pagination = () => {
    return (
      <Pagination
        dotsLength={3}
        activeDotIndex={activeSlide}
        dotStyle={{
          borderRadius: 5,
          backgroundColor: '#0697DC',
        }}
        inactiveDotOpacity={0.4}
        inactiveDotScale={0.6}
      />
    );
  };

  return (
    <View
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Carousel
        loop
        itemSpacing={30}
        width={windowWidth}
        height={windowHeight / 4.5}
        autoPlay={true}
        data={data}
        autoPlayInterval={2500}
        scrollAnimationDuration={1000}
        onSnapToItem={(index) => setActiveSlide(getDotIndex(index))}
        renderItem={renderItem}
        style={{
          width: windowWidth - 30,
        }}
      />
      {pagination()}
    </View>
  );
};

export default CarouselComponent;

const styles = StyleSheet.create({
  itemContainer: {
    width: windowWidth - 30,
    height: windowHeight / 4.5,
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 5,
  },
  paginationDot: {
    width: 10,
    height: 10,
  },
  inactivePaginationDot: {
    width: 6,
    height: 6,

    opacity: 0.4,
  },
});
