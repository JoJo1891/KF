import React from 'react'
import {
    Svg,
    Defs,
    Rect,
    Path,
    Stop,
    LinearGradient
} from 'react-native-svg'


const FrontCard = ({color='#000000'})=>{
    return (
        <Svg id="Layer_2" data-name="Layer 2"
    viewBox="0 0 376 227.3">
    <Defs>
        <LinearGradient id="linear-gradient" x1="313.85" y1="90.53" x2="313.85" gradientUnits="userSpaceOnUse">
            <Stop offset="0" stopColor="#fed871" />
            <Stop offset="1" stopColor="#fbbf16" />
        </LinearGradient>
    </Defs>
    <Rect  fill={color} y="4.24" width="376" height="223.06" rx="14.76" />
    <Path  fill='url(#linear-gradient)'
        d="M345.35,4.5V86a4.49,4.49,0,0,1-4.5,4.5l-6.62-3-19-8.55a3.46,3.46,0,0,0-2.82,0L294.23,87.2l-7.38,3.33a4.5,4.5,0,0,1-4.5-4.5V4.5a4.51,4.51,0,0,1,4.5-4.5h54A4.5,4.5,0,0,1,345.35,4.5Z" />
    <Path fill= "#fbbf16" d="M334.23,0V87.54l-19-8.55a3.46,3.46,0,0,0-2.82,0L294.23,87.2V0Z" />
</Svg>
    )
}

export default FrontCard