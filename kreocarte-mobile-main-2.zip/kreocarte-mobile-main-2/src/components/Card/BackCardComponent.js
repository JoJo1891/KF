import React from 'react'
import {
    Svg,
    Defs,
    Rect,
    Path,
    Stop,
    LinearGradient
} from 'react-native-svg'


const BackCard = ({color='#000000'})=>{
    return (
        <Svg id="Layer_2" data-name="Layer 2"
        viewBox="0 0 376 227.3">
        <Defs>
            <LinearGradient id="linear-gradient" x1="-56.47" y1="87.54" x2="917.03" y2="87.54"
                gradientUnits="userSpaceOnUse">
                <Stop offset="0" stopColor="#2c2e3d" />
                <Stop offset="1" stopColor="#72737d" />
            </LinearGradient>
            <LinearGradient id="linear-gradient-2" x1="312.74" y1="90.53" x2="312.74" gradientUnits="userSpaceOnUse">
                <Stop offset="0" stopColor="#fed871" />
                <Stop offset="1" stopColor="#fbbf16" />
            </LinearGradient>
        </Defs>
        <Path fill={color}
            d="M376,19V212.53a14.76,14.76,0,0,1-14.76,14.77H14.77A14.77,14.77,0,0,1,0,212.53V19A14.77,14.77,0,0,1,14.77,4.24H361.24A14.76,14.76,0,0,1,376,19Z" />
        <Rect fill="url(#linear-gradient)" y="59.83" width="376" height="55.41" />
        <Path fill="url(#linear-gradient-2)"
            d="M344.24,4.5V86a4.49,4.49,0,0,1-4.5,4.5l-6.62-3-19-8.55a3.46,3.46,0,0,0-2.82,0L293.12,87.2l-7.38,3.33a4.5,4.5,0,0,1-4.5-4.5V4.5a4.51,4.51,0,0,1,4.5-4.5h54A4.5,4.5,0,0,1,344.24,4.5Z" />
        <Rect fill="#fbbf16" d="M333.12,0V87.54l-19-8.55a3.46,3.46,0,0,0-2.82,0L293.12,87.2V0Z" />
    </Svg>
    )
}

export default BackCard