import React from 'react';

import {View,TextInput,StyleSheet} from 'react-native';
import {moderateScale, moderateVerticalScale} from 'react-native-size-matters';

const CustomInput = ({keyboardType="numeric",onChange, value}) => {
    return <View style={ styles.inputContainer }>
    <TextInput 
        keyboardType={keyboardType}
        style={styles.inputTxt}
        value={value}
        onChangeText={text=> onChange(text)}
    />
</View>
}

export default CustomInput;

const styles = StyleSheet.create({
    inputContainer:{
        flexDirection:"row",
        alignItems:'stretch',
        borderWidth:1,
        borderColor:"#0697DC",
        borderRadius: 8,
        height : moderateVerticalScale(50)
    },
      inputTxt:{
        flex: 1,
        fontSize: moderateScale(14), 
        fontFamily: 'MontserratMedium',
        textAlign: "left",
        color:'#174B9D',
        paddingHorizontal: 10,
        paddingVertical:5,
    },
})