import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Platform,
  UIManager,
  Image,
} from "react-native";
import {
  moderateScale,
  moderateVerticalScale,
  s,
} from "react-native-size-matters";
import { windowHeight, layoutStyles } from "../../themes";

if (
  Platform.OS === "android" &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const HistoryPointsComponent = ({
  enseigne,
  type,
  transaction,
  amount,
  date,
}) => {
  const datePoints = new Date(date);
  const dateFormatted =
    datePoints.getDate() +
    "/" +
    (datePoints.getMonth() + 1) +
    "/" +
    datePoints.getFullYear();
  return (
    <View style={[styles.container, layoutStyles.elevation]}>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          width: "100%",
        }}
      >
        <View
          style={{
            flexDirection: "column",
            flexShrink: 1,
            width: "22%",
            marginRight: 5,
          }}
        >
          <View style={layoutStyles.elevation}>
            <View
              style={[
                styles.storeImageContainer,
                //   {
                //     backgroundColor: `${
                //       source_details?.card_color
                //         ? source_details.card_color
                //         : "white"
                //     }`,
                //   },
              ]}
            >
              <Image
                source={{
                  uri: enseigne?.avatar,
                }}
                style={styles.image}
                resizeMode="contain"
              />
            </View>
          </View>
        </View>
        <View style={{ flexDirection: "column", flexShrink: 1, width: "78%" }}>
          <Text style={styles.textTitle}>{enseigne?.nom}</Text>
          <Text style={styles.textTitleGrey}>
            {type + " - " + dateFormatted}
          </Text>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Text style={styles.textPoint}>
            {" "}
            {transaction === "USE" ? "-" : "+"}
            {amount}{" "}
          </Text>
        </View>
      </View>
    </View>
  );
};

export default HistoryPointsComponent;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    height: windowHeight / 10,
    marginBottom: 20,
    marginTop: 5,
    borderRadius: 20,
    marginHorizontal: 15,
    paddingHorizontal: 15,
    justifyContent: "center",
  },
  textTitle: {
    fontSize: moderateScale(15),
    fontFamily: "MontserratSemiBold",
    color: "#174B9D",
    textAlign: "left",
  },
  textTitleGrey: {
    fontSize: moderateScale(11),
    marginTop: moderateVerticalScale(5),
    fontFamily: "MontserratSemiBold",
    color: "#989898",
    textAlign: "left",
  },
  textPoint: {
    fontFamily: "MontserratBold",
    fontSize: moderateScale(25),
    color: "#174B9D",
    fontWeight: "bold",
  },
  image: {
    flex: 1,
  },
  storeImageContainer: {
    width: moderateScale(55),
    height: moderateVerticalScale(55),
    borderRadius: moderateScale(40),
    overflow: "hidden",
    borderWidth: 2,
    borderColor: "white",
  },
});
