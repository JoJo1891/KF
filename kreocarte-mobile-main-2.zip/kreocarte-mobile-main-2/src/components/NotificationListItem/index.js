import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  LayoutAnimation,
  Platform,
  UIManager,
  Image,
  TouchableOpacity,
  Alert,
} from "react-native";
import Swipeable from "react-native-gesture-handler/Swipeable";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";

import { windowHeight, layoutStyles } from "../../themes";
import GfActive from "../../assets/icons/gf_notification.svg";
import GfActive2 from "../../assets/icons/gf_notification2.svg";
import { useNavigation } from "@react-navigation/native";

import DealIcon from "../../assets/icons/discount_icon.svg";
import ModalComponent from "../ModalComponent";
import ConfirmationModal from "../ModalComponent/ConfimationModal";
import { createCardByStoreId } from "../../api/card";
import { useMutation, useQueryClient } from "react-query";
import { StoriesModalComponent } from "..";

if (
  Platform.OS === "android" &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const NotificationListComponent = ({
  id,
  texte,
  deleteItem,
  type,
  source_details,
  source2_details,
  name,
}) => {
  const RightAction = () => <View style={styles.rightActionContainer}></View>;
  const navigation = useNavigation();
  const queryClient = useQueryClient();
  const [story, setStory] = useState(null);
  const [cardModalVisible, setCardModalVisible] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);

  const deleteNotification = (id) => {
    LayoutAnimation.configureNext({
      duration: 500,
      create: { type: "linear", property: "opacity" },
      update: { type: "spring", springDamping: 0.9 },
      delete: { type: "linear", property: "opacity" },
    });
    deleteItem(id);
  };

  const { mutate, isLoading } = useMutation(createCardByStoreId, {
    onSuccess: (data) => {
      setCardModalVisible(!cardModalVisible);
      if (data.error) {
        Alert.alert(data.error);
      } else {
        queryClient.refetchQueries("goNordStoresAuth");
        queryClient.refetchQueries("goFidStoresAuth");
        queryClient.refetchQueries("getCardsByUser");
        Alert.alert(
          "Ajout réussi !",
          " Votre carte a bien été ajoutée à votre wallet.",
          [
            {
              text: "Ok",
              onPress: () => {
                if (type === "BONPLAN") {
                  navigation.navigate("BonusPlansScreen", {
                    id: data.id,
                  });
                } else if (type === "CATALOGUE") {
                  navigation.navigate("CatalogScreen", {
                    id: source_details.id,
                  });
                } else {
                  navigation.navigate("CardScreen", {
                    id: data.id,
                  });
                }
              },
            },
          ]
        );
      }
    },
    onError: (error) => {
      setCardModalVisible(false);
      Alert.alert("Error", "Quelque chose s'est mal passé");
    },
    onSettled: () => {
      queryClient.invalidateQueries("createCardByStoreId");
    },
  });

  const handleAddCard = async (storeId) => {
    mutate({
      storeId,
    });
  };

  const notificationNavigate = () => {
    switch (type) {
      case "DEAL":
        navigation.navigate("DealsScreen");
        break;
      case "CASHBACK_UTILISE":
      case "ONE_POINT":
      case "ENSEIGNE":
        if (source_details?.has_card) {
          navigation.navigate("CardScreen", {
            id: source_details.card_id,
          });
        } else {
          setCardModalVisible(!cardModalVisible);
        }
        break;
      case "BONPLAN":
        if (source_details?.has_card) {
          navigation.navigate("BonusPlansScreen", {
            id: source_details.card_id,
          });
        } else {
          setCardModalVisible(!cardModalVisible);
        }
        break;
      case "CATALOGUE":
        if (source_details?.has_card) {
          navigation.navigate("CatalogScreen", {
            id: source_details.id,
          });
        } else {
          setCardModalVisible(!cardModalVisible);
        }
        break;
      case "STORIES":
        if (!source2_details) {
          queryClient.refetchQueries("storiesAuth");
          navigation.navigate("Home");
          return;
        }
        if (source2_details.isExpired)
          return alert("Cette histoire a déjà expiré");
        let newStory = {
          name: source_details?.nom,
          image_url: source_details?.image_url,
          stories: [
            {
              story_id: source2_details.story_id,
              media: source2_details.media,
              isViewed: source2_details.isViewed,
            },
          ],
        };
        setStory(newStory);
        setModalVisible(true);
        break;
      default:
        navigation.navigate("Home");
    }
  };

  useEffect(() => {
    if (!modalVisible) queryClient.refetchQueries("storiesAuth");
  }, [modalVisible]);

  return (
    <Swipeable
      renderRightActions={RightAction}
      onSwipeableRightOpen={() => deleteNotification(id)}
    >
      <ModalComponent modalVisible={cardModalVisible}>
        <ConfirmationModal
          value="Voulez-vous ajouter cette carte à votre collection?"
          isLoading={isLoading}
          onSubmit={() => handleAddCard(source_details?.id)}
          onCancel={() => setCardModalVisible(!cardModalVisible)}
        />
      </ModalComponent>
      <ModalComponent modalVisible={modalVisible} bgType={true}>
        <StoriesModalComponent
          data={story}
          modalVisible={modalVisible}
          setModalVisible={setModalVisible}
        />
      </ModalComponent>

      <TouchableOpacity
        style={[styles.container, layoutStyles.elevation]}
        onPress={notificationNavigate}
      >
        <View style={styles.iconContainer}>
          {type === "DEAL" ? (
            <DealIcon width={60} height={60} />
          ) : (type === "ENSEIGNE" && source_details?.image_url) ||
            type === "BONPLAN" ||
            type === "STORIES" ||
            type === "CATALOGUE" ||
            (type === "USER" && source_details?.image_url) ? (
            <View style={layoutStyles.elevation}>
              <View
                style={[
                  styles.storeImageContainer,
                  {
                    backgroundColor: `${
                      source_details?.card_color
                        ? source_details.card_color
                        : "white"
                    }`,
                  },
                ]}
              >
                <Image
                  source={{
                    uri: source_details?.image_url,
                  }}
                  style={styles.image}
                  resizeMode="contain"
                />
              </View>
            </View>
          ) : type === "CASHBACK_UTILISE" ||
            (type === "USER" && !source_details?.image_url) ? (
            <GfActive2 />
          ) : (
            <GfActive width={60} height={60} />
          )}
        </View>

        {type === "CASHBACK_UTILISE" ? (
          <Text style={styles.text}>{`${name}: ${texte}`}</Text>
        ) : type === "DEAL" ? (
          <Text style={styles.text}>{`${name}: ${texte}`}</Text>
        ) : texte === "Nouvelle enseigne créé" ? (
          <Text style={styles.text}>
            {texte} {source_details?.nom ? `: ${source_details?.nom}` : ""}
          </Text>
        ) : (
          <Text style={styles.text}>{texte}</Text>
        )}
      </TouchableOpacity>
    </Swipeable>
  );
};

export default NotificationListComponent;
const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    minHeight: windowHeight / 7,
    alignItems: "center",
    marginBottom: 15,
    marginTop: 5,
    borderRadius: 20,
    marginHorizontal: 15,
    paddingHorizontal: 15,
    paddingVertical: 15,
    flexDirection: "row",
  },
  text: {
    fontFamily: "MontserratSemiBold",
    fontSize: moderateScale(14),
    color: "#174B9D",
    textAlign: "left",
    flexShrink: 1,
  },
  rightActionContainer: {
    flex: 1,
  },
  iconContainer: {
    marginRight: 5,
  },
  storeImageContainer: {
    width: moderateScale(55),
    height: moderateVerticalScale(55),
    borderRadius: moderateScale(40),
    overflow: "hidden",
    borderWidth: 2,
    borderColor: "white",
  },
  image: {
    flex: 1,
  },
});
