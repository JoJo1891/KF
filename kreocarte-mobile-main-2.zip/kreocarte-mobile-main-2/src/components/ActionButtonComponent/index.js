import React from "react";

import { StyleSheet } from "react-native";
import { useNavigation } from "@react-navigation/native";

import { FloatingAction } from "react-native-floating-action";

const FabButton = () => {
  const navigation = useNavigation();

  const actions = [
    {
      text: "Scan",
      icon: require("../../assets/icons/scan_qr_serial_icon.png"),
      name: "bt_scanner",
      position: 1,
    },
    {
      text: "Créer une carte",
      icon: require("../../assets/icons/creditcard_white.png"),
      name: "bt_card",
      position: 2,
    },
  ];

  return (
    <FloatingAction
      actions={actions}
      onPressItem={(name) =>
        name === "bt_scanner"
          ? navigation.navigate("ScannerScreen")
          : navigation.navigate("ManualCardScreen")
      }
    />
  );
};

export default FabButton;

const styles = StyleSheet.create({
  actionButtonIcon: {
    fontSize: 20,
    height: 22,
    color: "white",
  },
});
