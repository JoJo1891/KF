import React from 'react';

import {
    View,
    FlatList
} from 'react-native';

import CatalogListItem from './CatalogListItem';


const CatalogListComponent = ({header,ItemComponent,data,extraData,columns = 1}) =>{ 
    return (<FlatList
        data={data}
        extraData={extraData}
        ListHeaderComponent={header}
        ListHeaderComponentStyle={{marginBottom : 20}}
        ListFooterComponent={<View/>}
        numColumns={columns}
        ListFooterComponentStyle={{marginBottom : 50}}
        horizontal={false}
        renderItem={({item,index}) => <ItemComponent {...item}/>}
        keyExtractor={(_,index)=>'key'+index}
        showsVerticalScrollIndicator={false}
    />)
}

export default CatalogListComponent;