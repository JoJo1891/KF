import React from 'react';

import {
    View,
    Text,
    Image,
    StyleSheet,
    TouchableOpacity,
} from 'react-native';

import {layoutStyles,windowHeight} from '../../themes';
import { moderateScale, moderateVerticalScale } from 'react-native-size-matters';

const AdvantagesListItem = ({id,recompense,conditions,type_recompense,onPress}) => {
    return (<TouchableOpacity onPress={onPress} style={[styles.itemContainer]}>
        <View style={styles.contentContainer}>
            <View style={styles.textContainer}>
                <Text style={styles.title}>{recompense}</Text>
                <Text style={styles.description}>{conditions}</Text>
            </View>
        </View>
        <View style={styles.separator}/>
    </TouchableOpacity>)
}

export default AdvantagesListItem;

const styles = StyleSheet.create({
    itemContainer :{
        flex : 1,
        paddingHorizontal : 15,
        paddingTop : 15
    },
    contentContainer :{
        flexDirection : 'row',
    },
    imageContainer : {
        borderRadius : 10,
        width : moderateScale(110),
        height : moderateVerticalScale(110),
        overflow :'hidden',
        alignSelf: 'center'
    },
    image : {
        flex : 1
    },
    separator : {
        marginTop : 15,
        borderBottomWidth : 1,
        borderColor : '#EEEEEE',
    },
    title :{
        fontFamily : 'MontserratSemiBold',
        color : '#174B9D',
        fontSize : moderateScale(17)
    },
    description :{
        fontFamily : 'Nexa',
        color : '#858585',
        fontSize : moderateScale(14)
    },
    textContainer : {
        marginLeft : 10
    }
});