import React from "react";

import {
  View,
  Text,
  Linking,
  Image,
  Alert,
  StyleSheet,
  TouchableOpacity,
} from "react-native";

import { useMutation, useQueryClient } from "react-query";

import { useWhatsapp } from "../../api/store";

import { layoutStyles } from "../../themes";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";

const CatalogListItem = ({
  id,
  type,
  nom,
  whatsapp,
  description,
  url_picture,
  onPress,
}) => {
  const queryClient = useQueryClient();

  const { mutate } = useMutation(useWhatsapp, {
    onSuccess: (data) => {
      //
    },
    onError: (error) => {
      Alert.alert("Error", "Quelque chose s'est mal passé");
    },
    onSettled: () => {
      queryClient.invalidateQueries("useWhatsapp");
    },
  });

  const handleSubmit = () => {
    mutate();
  };

  return (
    <TouchableOpacity
      onPress={() => {
        handleSubmit();
        Linking.openURL(
          `whatsapp://send?text=Bonjour, je suis client Kréocarte’ et je suis intéressé par ce produit "${nom}"&phone=${whatsapp}`
        );
      }}
      style={[styles.itemContainer]}
    >
      <View style={styles.contentContainer}>
        {type === "catalogue" ? (
          <View style={[styles.imageContainer, layoutStyles.elevation]}>
            <Image
              source={{ uri: url_picture }}
              resizeMode="cover"
              style={styles.image}
            />
          </View>
        ) : (
          <View></View>
        )}
        <View style={styles.textContainer}>
          <Text style={styles.title}>{nom}</Text>
          <Text style={styles.description}>{description}</Text>
        </View>
      </View>
      <View style={styles.separator} />
    </TouchableOpacity>
  );
};

export default CatalogListItem;

const styles = StyleSheet.create({
  itemContainer: {
    paddingHorizontal: 15,
    paddingTop: 15,
  },
  contentContainer: {
    flexDirection: "row",
  },
  imageContainer: {
    borderRadius: 10,
    width: moderateScale(110),
    height: moderateVerticalScale(110),
    overflow: "hidden",
    alignSelf: "center",
  },
  image: {
    flex: 1,
  },
  separator: {
    marginTop: 15,
    borderBottomWidth: 1,
    borderColor: "#EEEEEE",
  },
  title: {
    fontFamily: "MontserratSemiBold",
    color: "#174B9D",
    fontSize: moderateScale(17),
  },
  description: {
    fontFamily: "Nexa",
    color: "#858585",
    fontSize: moderateScale(14),
  },
  textContainer: {
    flexShrink: 1,
    marginLeft: 10,
  },
});
