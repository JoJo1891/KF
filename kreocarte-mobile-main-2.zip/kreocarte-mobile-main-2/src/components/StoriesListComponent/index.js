import React, { useEffect, useState } from "react";
import { View, StyleSheet, FlatList, TouchableOpacity,Text } from "react-native";
import { windowHeight } from "../../themes";

import StoriesListItem from "./StoriesListItem";

const StoriesListComponent = ({stories,setStories,modalVisible,setModalVisible}) => {
  
  // function compare_lname( a, b ){
  //   if (b.all_viewed){
  //     return -1;
  //   }
  //   if (a.all_viewed){
  //     return 1;
  //   }
  //   return 0;
  // }


  return (
    <View style={styles.listContainer}>
      <FlatList
        scrollEnabled
        data={stories}
        horizontal
        renderItem={({ item, index }) =>
       
          item.name === 'GoFid' || (item.name === 'GoNord' && stories[index+1]?.name !== 'GoFid') ? (
            <View style={styles.separatorContainer}>
              <TouchableOpacity onPress={()=>{
                setStories(item)
                setModalVisible(!modalVisible)
                }}>
                <StoriesListItem {...item} />
              </TouchableOpacity>

              <View style={styles.separator} />
            </View>
          ) : (<TouchableOpacity onPress={()=>{
              setStories(item)
              setModalVisible(!modalVisible)
            }}>
            <StoriesListItem {...item}  />
          </TouchableOpacity>
          )
        }
        keyExtractor={(_, index) => "key" + index}
        showsHorizontalScrollIndicator={false}
      />
    </View>
  );
};

export default StoriesListComponent;

const styles = StyleSheet.create({
  listContainer: {
    // height: windowHeight / 13,
    flexDirection: "row",
  },
  separatorContainer: {
    flexDirection: "row",
  },
  separator: {
    flex: 1,
    borderWidth: 1,
    borderColor: "white",
  },
});
