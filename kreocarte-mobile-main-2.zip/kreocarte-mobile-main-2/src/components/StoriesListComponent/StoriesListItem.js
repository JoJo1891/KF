import React, { useState } from "react";

import { View, StyleSheet, Image, Text } from "react-native";

import { windowWidth } from "../../themes";
import {
  moderateScale,
  moderateVerticalScale,
  s,
  verticalScale,
} from "react-native-size-matters";

const StoriesListItem = ({ image_url,name, all_viewed }) => {

  return (
    <View style={styles.container}>
     {all_viewed ?
      <>
          <View style={styles.itemContainer}>
            <Image
              source={{
                uri: image_url,
              }}
              style={{ flex: 1 }}
              resizeMode="contain"
            />
          </View>  
        </>   
      :
        <View style={styles.itemContainerRed}>
            <Image
              source={{
                uri: image_url,
              }}
              style={{ flex: 1 }}
              resizeMode="contain"
            />
          </View>
      }
        <Text style={{flex:1, fontSize:8, marginTop:5, fontFamily : 'MontserratRegular', width:55, textAlign:'center'}}>
          {name? name: ''}
        </Text>
     </View>
  );
};

export default StoriesListItem;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    overflow: "hidden",
    justifyContent: "center",
    alignItems:'center'
  },
  itemContainer: {
    // flex: 1,
    width: moderateScale(55),
    height:moderateScale(55),
    overflow: "hidden",
    borderRadius:moderateScale(55/2),
    borderWidth: 3,
    borderColor: "#4DBDF2",
    justifyContent: "center",
    marginLeft: 5,
    marginRight: 5,
    backgroundColor: "#f0eceb"
  },
  itemContainerRed: {
    // flex: 1,
    width: moderateScale(55),
    height:moderateScale(55),
    overflow: "hidden",
    borderRadius:moderateScale(55/2),
    borderWidth: 3,
    borderColor: "red",
    justifyContent: "center",
    marginLeft: 5,
    marginRight: 5,
    backgroundColor: "#f0eceb"
  },
});
