import React from 'react';

import {
  View,
  Image,
  StyleSheet,
  TouchableOpacity,
  Platform,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {
  moderateScale,
  moderateVerticalScale,
} from 'react-native-size-matters';
import { windowHeight, layoutStyles } from '../../themes';

const VerticalListItem = ({
  id,
  nom,
  description,
  zone,
  image_url,
  onPress,
  home_color,
}) => {
  const navigation = useNavigation();

  return (
    <TouchableOpacity
      onPress={onPress}
      style={
        Platform.OS === 'android'
          ? [styles.itemContainer, layoutStyles.elevation]
          : [styles.itemContainer2, layoutStyles.elevation]
      }
    >
      <Image
        source={{
          uri: image_url,
        }}
        resizeMode="contain"
        backgroundColor={home_color}
        style={Platform.OS === 'android' ? styles.image : styles.image2}
      />
    </TouchableOpacity>
  );
};

export default VerticalListItem;

const styles = StyleSheet.create({
  itemContainer: {
    flex: 1,
    height: moderateScale(100),
    backgroundColor: 'white',
    marginTop: 10,
    marginBottom: 10,
    borderRadius: 15,
    overflow: 'hidden',
    marginLeft: 10,
    marginRight: 10,
  },
  image: {
    flex: 1,
  },

  itemContainer2: {
    flex: 1,
    height: moderateScale(100),
    backgroundColor: 'white',
    marginTop: 10,
    marginBottom: 10,
    borderRadius: 15,
    // overflow: "hidden",
    marginLeft: 10,
    marginRight: 10,
  },
  image2: {
    flex: 1,
    borderRadius: 15,
    paddingRight: 10,
  },
});
