import React from "react";
import {
  Image,
  StyleSheet,
  TouchableOpacity,
  Platform,
  View,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { moderateScale } from "react-native-size-matters";
import { layoutStyles } from "../../themes";
import Loader from "../Loader";

const VerticalListItem = ({
  id,
  enseigne,
  handleDeleteCard,
  myCards,
  isLoading,
  refreshing,
}) => {
  const navigation = useNavigation();

  if (myCards) {
    return (
      (enseigne.status === "VALIDE" || enseigne.status === "EN ATTENTE") && (
        <TouchableOpacity
          onLongPress={() => handleDeleteCard(id)}
          onPress={() => navigation.navigate("CardScreen", { id })}
          style={
            Platform.OS === "android"
              ? [styles.itemContainer, layoutStyles.elevation]
              : [styles.itemContainer2, layoutStyles.elevation]
          }
        >
          {isLoading || refreshing ? (
            <View
              style={{
                display: "flex",
                width: "100%",
                height: "100%",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Loader />
            </View>
          ) : (
            <Image
              source={{
                uri: enseigne.image_url,
              }}
              resizeMode="contain"
              style={Platform.OS === "android" ? styles.image : styles.image2}
              backgroundColor={enseigne.home_color}
            />
          )}
        </TouchableOpacity>
      )
    );
  } else {
    return (
      enseigne.status === "VALIDE" && (
        <TouchableOpacity
          onLongPress={() => handleDeleteCard(id)}
          onPress={() => navigation.navigate("CardScreen", { id })}
          style={
            Platform.OS === "android"
              ? [styles.itemContainer, layoutStyles.elevation]
              : [styles.itemContainer2, layoutStyles.elevation]
          }
        >
          <Image
            source={{
              uri: enseigne.image_url,
            }}
            resizeMode="contain"
            style={Platform.OS === "android" ? styles.image : styles.image2}
            backgroundColor={enseigne.home_color}
          />
        </TouchableOpacity>
      )
    );
  }
};

export default VerticalListItem;

const styles = StyleSheet.create({
  itemContainer: {
    flex: 1,
    height: moderateScale(100),
    backgroundColor: "white",
    marginTop: 10,
    marginBottom: 10,
    borderRadius: 15,
    overflow: "hidden",
    marginLeft: 10,
    marginRight: 10,
  },
  image: {
    flex: 1,
  },

  itemContainer2: {
    flex: 1,
    height: moderateScale(100),
    backgroundColor: "white",
    marginTop: 10,
    marginBottom: 10,
    borderRadius: 15,
    // overflow: "hidden",
    marginLeft: 10,
    marginRight: 10,
  },
  image2: {
    flex: 1,
    borderRadius: 15,
  },
});
