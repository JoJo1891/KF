import React from 'react';

import {
    View,
    StyleSheet,
    FlatList,
    RefreshControl,
} from 'react-native';

const VerticalListComponent = ({header,data,extraData,ItemComponent,ListEmptyComponent,columns = 1,refreshControl}) => {

    return (<FlatList
        refreshControl={refreshControl}
        ListHeaderComponent={header}
        ListHeaderComponentStyle={{marginBottom : 20}}
        ListEmptyComponent={ListEmptyComponent}
        ListFooterComponent={<View/>}
        ListFooterComponentStyle={{marginBottom : 40}}
        scrollEnable={false}
        data={data}
        extraData={extraData}
        horizontal={false}
        numColumns={columns}
        renderItem={({item})=> <ItemComponent {...item}/>}
        keyExtractor={(_, index) => "key" + index}
        showsVerticalScrollIndicator={false}
    />)
}

export default VerticalListComponent;

const styles = StyleSheet.create({
});