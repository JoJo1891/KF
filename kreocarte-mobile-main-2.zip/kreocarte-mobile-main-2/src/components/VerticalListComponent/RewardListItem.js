import React, { useEffect, useState } from "react";

import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

import { windowHeight } from "../../themes";
import GifBoxIcon from "../../assets/icons/gif_box_icon.svg";
import GifBoxGrayIcon from "../../assets/icons/gif_icon_gray.svg";
import DiscountIcon from "../../assets/icons/discount_icon2.svg";
import DiscountIcon2 from "../../assets/icons/discount_icon3.svg";
import { DealModal, ModalComponent } from "..";
import BonusPlanModal from "../ModalComponent/BonusPlanModal";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";

const RewardListItem = ({
  type,
  enseigne,
  updateDeal,
  recompense,
  actual_deal,
  seuil_points,
  card_id,
  expired_at,
  loading,
  points,
  quantity,
}) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [refresh, setRefresh] = useState(false);

  useEffect(() => {
    if (refresh) {
      updateDeal();
    }
  }, [refresh]);

  return (
    <View style={styles.screenContainer}>
      <ModalComponent modalVisible={modalVisible}>
        {type === "gift" ? (
          <BonusPlanModal
            data={recompense}
            card_id={card_id}
            onClose={() => {
              setModalVisible(!modalVisible);
            }}
          />
        ) : (
          <DealModal
            onClose={() => {
              setModalVisible(!modalVisible);
              setRefresh(true);
            }}
            reward={recompense}
            points={seuil_points}
            store={enseigne.nom}
            deal={actual_deal}
            type={type}
            expired={expired_at}
            userPoints={points}
            quantity={quantity}
          />
        )}
      </ModalComponent>
      <TouchableOpacity
        onPress={() => setModalVisible(!modalVisible)}
        style={[styles.itemContainer]}
        disabled={loading}
      >
        {type === "deal" ? (
          <>
            {!actual_deal?.status ? (
              <View style={styles.dealBox}>
                <DiscountIcon2 />
                <Text style={styles.descriptionDealGray}>{enseigne.nom}</Text>
              </View>
            ) : (
              <View style={styles.dealBox}>
                {points < seuil_points ? (
                  <>
                    <DiscountIcon2 />
                    <Text style={styles.descriptionDealGray}>
                      {enseigne.nom}
                    </Text>
                  </>
                ) : (
                  <>
                    <DiscountIcon />
                    <Text style={styles.descriptionDeal}>{enseigne.nom}</Text>
                  </>
                )}
              </View>
            )}
          </>
        ) : (
          type === "gift" &&
          (recompense?.status === "UTILISE" ||
          recompense?.status === "CANCEL" ? (
            <View style={styles.grayGift}>
              <GifBoxGrayIcon />
            </View>
          ) : (
            <View style={styles.blueGift}>
              <GifBoxIcon />
              <Text style={styles.description}>
                {recompense?.is_promotional ? "PROMOTIONNEL" : " "}
              </Text>
            </View>
          ))
        )}
      </TouchableOpacity>
    </View>
  );
};

export default RewardListItem;

const styles = StyleSheet.create({
  itemContainer: {
    flex: 1,
    height: windowHeight / 8,
    marginBottom: 10,
    borderRadius: 15,
    alignItems: "center",
    marginLeft: 10,
    marginRight: 10,
  },
  screenContainer: {
    flex: 1,
  },
  dealBox: {
    width: moderateScale(60),
    alignItems: "center",
    justifyContent: "center",
  },
  blueGift: {
    width: moderateScale(42),
    height: -moderateVerticalScale(10),
    alignItems: "center",
  },
  grayGift: {
    width: moderateScale(50),
    height: moderateVerticalScale(52),
    alignItems: "center",
  },
  description: {
    marginTop: 5,
    fontFamily: "MontserratRegular",
    color: "red",
    fontSize: moderateVerticalScale(4),
  },
  descriptionDeal: {
    width: "100%",
    marginTop: 5,
    marginLeft: -moderateVerticalScale(5),
    fontFamily: "MontserratRegular",
    color: "red",
    textAlign: "center",
    fontSize: moderateVerticalScale(8),
  },
  descriptionDealGray: {
    width: "100%",
    marginTop: 5,
    marginLeft: -moderateVerticalScale(5),
    fontFamily: "MontserratRegular",
    color: "gray",
    textAlign: "center",
    fontSize: moderateVerticalScale(8),
  },
});
