import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Platform,
  UIManager,
  Image
} from "react-native";
import { moderateScale, s } from "react-native-size-matters";
import { windowHeight, layoutStyles } from "../../themes";
import Points from '../../assets/icons/gf_points.svg';
import NotificationBadge from '../../assets/icons/gf_notification.svg';
import PointsGrey from '../../assets/icons/gf_points_text_gray.svg';
import NotificationBadgeGrey from "../../assets/icons/gf_notification_grey.svg";


if (
  Platform.OS === "android" &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const ChallengeScoringListItems = ({ id, imageUrl, description, points }) => {
  
  return (
    <View style={[styles.container, layoutStyles.elevation]}>
        {
          id == 2 || id == 3 ? 
            <View style={{flexDirection:'row', justifyContent:"space-between" }}>
              <NotificationBadgeGrey
                width={54}
                height={62}
              />                
                <View style={{flexDirection:'row', alignItems:'center', flexShrink:1, justifyContent:'flex-end'}}>
                  <Text style={styles.textTitleGrey} >{description}</Text>               
                </View>
                <View style={{flexDirection:'row', alignItems:'center', justifyContent:'flex-end'}}>
                  <Text style={styles.pointsGrey}>{points} </Text>
                  <PointsGrey/>                
                </View>
            </View>
          :
            <View style={{flexDirection:'row', justifyContent:"space-between" }}>
              <NotificationBadge/>                
                <View style={{flexDirection:'row', alignItems:'center', flexShrink:1, justifyContent:'flex-end'}}>
                  <Text style={styles.textTitle}>{description}</Text>               
                </View>
                <View style={{flexDirection:'row', alignItems:'center', justifyContent:'flex-end'}}>
                  <Text style={styles.textPoint}>{points} </Text>
                  <Points/>                
                </View>
            </View>
        }
    </View>
  );
};

export default ChallengeScoringListItems;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    height: windowHeight / 7,
    marginBottom: 15,
    marginTop: 5,
    borderRadius: 20,
    marginHorizontal: 15,
    paddingHorizontal: 15,
    justifyContent: "center",
  },
  textTitle: {
   fontWeight:"bold",
   color: "#174B9D",
   fontFamily: "MontserratSemiBold",
   fontSize: moderateScale(10),
   paddingLeft:20,
   paddingRight:20,
   textAlign:'center'
  },
  textPoint: {
    fontFamily: "MontserratSemiBold",
    fontSize: moderateScale(14),
    color: "#174B9D",
    fontWeight:'bold',
  },
  textTitleGrey:{
    fontWeight:"bold",
    color: "#B4B3B8",
    fontFamily: "MontserratSemiBold",
    fontSize: moderateScale(10),
    paddingLeft:20,
    paddingRight:20,
    textAlign:'center'
  },
  pointsGrey:{
    fontFamily: "MontserratSemiBold",
    fontSize: moderateScale(14),
    color: "#B4B3B8",
    fontWeight:'bold',
  }
});
