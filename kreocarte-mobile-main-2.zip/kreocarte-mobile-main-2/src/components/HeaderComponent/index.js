import React from "react";

import { View, StyleSheet, TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";

import XIcon from "../../assets/icons/x.svg";
import { windowWidth } from "../../themes";

const HeaderComponent = ({ tintColor }) => {
  const navigation = useNavigation();
  return (
    <View style={styles.headerContainer}>
      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={[
          styles.backButtonContainer,
          { paddingLeft:300 },
        ]}
      >
        <XIcon fill={tintColor === "white" ? "#ffffff" : "#8C8C8C"} />
      </TouchableOpacity>
    </View>
  );
};

export default HeaderComponent;

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: moderateVerticalScale(5),
    paddingBottom: moderateVerticalScale(10),
    marginHorizontal: 15,
    width: windowWidth - 30,
  },
  backButtonContainer: {},
  titleContainer: {
    textAlign: "center",
    flex: 1,
  },
  title: {
    fontFamily: "MontserratSemiBold",
    color: "#174B9D",
    fontSize: moderateScale(18),
    textAlign: "center",
  },
  white: {
    color: "white",
  },
});
