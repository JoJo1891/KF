import React from "react";

import { View, Text, StyleSheet,TouchableOpacity, Alert } from "react-native";

import { moderateScale, moderateVerticalScale } from "react-native-size-matters";
import GifBoxIcon from "../../assets/icons/gif_box_icon.svg";
import CloseIcon from "../../assets/icons/close_gray.svg";
import CelebrationIcon from "../../assets/icons/celebration_icon.svg";
import { CustomButtonComponent } from "..";
import { unlockBonPlan } from "../../api/rewards";
import Loader from "../Loader";
import { useMutation } from "react-query";
import { useNavigation } from "@react-navigation/native";

const BonusPlanModal = ({data,onClose,card_id}) => {
  const navigation = useNavigation();

  const handlerSuccess = () => {
    onClose()
    navigation.navigate('ScannerBPScreen', 
                { 
                  isBonPlan : true,
                  idBonPlan : data.id,
                  cardId: card_id
                })
  }

  const { mutate , isLoading }   = useMutation('unlockBonPlan',unlockBonPlan, {
    onSuccess: (response) => {
      //console.log(response)
      if(response.status === 'UNLOCK'){
        Alert.alert( "Recompense débloqué", "Vous pouvez scanner le code du commerçant.",
        [
          {
            text: "Ok",
            onPress: () => handlerSuccess()
          },
        ]);
      }
    },
    onError: (error) => {
      if(error.message === 'Request failed with status code 400'){
        Alert.alert( "Error", "Pas assez de points");
      }else{
        Alert.alert( "Error ");
      } 
    }
  });

  const apiHandler = (id) =>{
    mutate(
      id
    )
  }

  return (
    <View>
      <View style={styles.container}>
        <TouchableOpacity onPress={onClose} style={styles.closeIcon}><CloseIcon width={moderateScale(40)}/></TouchableOpacity>
        <Text style={styles.text}>
          {data.type_recompense ? data.type_recompense : ''}
        </Text>
        <Text style={styles.text}>
          {data.recompense? data.recompense : ''}
        </Text>
        <View style={styles.celebrationIconContainer}>
            <CelebrationIcon width={moderateScale(60)} height={moderateVerticalScale(60)}/>
            <View style={styles.rightIcon}>
                <CelebrationIcon width={moderateScale(60)} height={moderateVerticalScale(60)}/>
            </View>
        </View>
          {data.is_promotional == true?
            <>
              <Text style={{fontFamily: "MontserratMedium",
                            color: "#FE6869",
                            fontSize: moderateScale(18),
                            textAlign: "center",}}>
                {'PROMOTIONNEL'}
              </Text>
            </>
            :
            data?.status == 'ACTIF' ?
              <>
              <View style={styles.button}>
                  <CustomButtonComponent
                    type="round-primary"
                    value="Utiliser Bon Plan"
                    onPress={() => apiHandler(data.id)}
                  />
              </View>
              </>
              :data?.status == 'UNLOCK' ?
              <>
              <View style={styles.button}>
                  <CustomButtonComponent
                    type="round-disabled"
                    value="DÉBLOQUÉ"
                    onPress={() => apiHandler(data.id)}
                  />
              </View>
              </>
              :data?.status == 'CANCEL' ?
              <>
              <View style={styles.button}>
                <CustomButtonComponent
                  type="round-disabled"
                  value="Annulé"
                  />
              </View>
              </>
              :
              <>
              <View style={styles.button}>
                  <CustomButtonComponent
                    type="round-disabled"
                    value="UTILISÉ"
                    />
              </View>
              </>
        }
        {isLoading &&
            <View
              style={{
                marginTop: moderateVerticalScale(10),
              }}
            >
              <Loader />
            </View>
          }
      </View>
      <View style={styles.boxIconContainer}>
           <GifBoxIcon width={moderateScale(140)} height={moderateVerticalScale(140)}/>
    </View>
    </View>
  );
};

export default BonusPlanModal;

const styles = StyleSheet.create({
  container: {
    width : moderateScale(320),
    paddingHorizontal: 20,
    paddingVertical : 30,
    backgroundColor: "white",
    marginHorizontal : 15,
    borderRadius : 15
  },
  boxIconContainer: {
    position: "absolute",
    top: -(moderateVerticalScale(100)),
    left: 0,
    right: 0,
    alignItems : 'center'
  },
  text: {
    fontFamily: "MontserratMedium",
    color: "#0C3E87",
    fontSize: moderateScale(18),
    textAlign: "center",
    marginTop : 15,
  },
  closeIcon :{
    alignSelf : 'flex-end'
  },
  celebrationIconContainer :{
    flexDirection : 'row',
    justifyContent: 'space-between',
    marginTop : moderateVerticalScale(50)
  },
  rightIcon : {
    transform : [{
     scaleX : -1   
    }]
  }, button:{
    marginTop : moderateVerticalScale(10),
    marginHorizontal : moderateScale(25),
  }
});
