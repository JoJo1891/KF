import React from "react";

import { View, StyleSheet, Text, TouchableOpacity } from "react-native";

import { windowHeight, windowWidth } from "../../themes";
import ShareModalMenuComponent from "../ShareModalMenuComponent";
import GradientComponent from "../GradientComponent";
import CloseIcon from "../../assets/icons/close_white.svg";
import { moderateScale } from "react-native-size-matters";

const ShareModal = ({ onClose, referal }) => {
  return (
    <View style={styles.container}>
      <View style={styles.screenContainer}>
        <GradientComponent
          colors={["#0697DC", "#174B9D"]}
          style={styles.backgroundGradient}
        />
        <View style={styles.contentContainer}>
          <View style={styles.headerContainer}>
            <Text style={styles.titleHeader}>Partager</Text>
            <TouchableOpacity onPress={onClose}>
              <CloseIcon />
            </TouchableOpacity>
          </View>
          <ShareModalMenuComponent referal={referal} />
        </View>
      </View>
    </View>
  );
};

export default ShareModal;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: "absolute",
    bottom: -10,
    marginHorizontal: 16,
    alignItems: "center",
    height: windowHeight / 1.7,
  },
  screenContainer: {
    flex: 1,
    width: windowWidth - 30,
  },
  contentContainer: {
    position: "absolute",
    width: "100%",
    // marginHorizontal: 15,
    alignItems: "center",
  },
  backgroundGradient: {
    height: "100%",
    borderRadius: 15,
    borderWidth: 2,
    borderColor: "#4DBDF2",
  },
  headerContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    paddingVertical: 15,
    marginBottom: moderateScale(30),
  },
  titleHeader: {
    fontFamily: "MontserratSemiBold",
    fontSize: 25,
    color: "white",
    textAlign: "center",
    width: "80%",
  },
});
