import React, { useState, useEffect } from 'react';

import {
  View,
  StyleSheet,
  Text,
  ScrollView,
  Linking,
  Alert,
  Platform,
  TouchableOpacity,
} from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import {
  moderateScale,
  moderateVerticalScale,
  verticalScale,
} from 'react-native-size-matters';

import CustomButtonComponent from '../CustomButtonComponent';
import { windowHeight, windowWidth } from '../../themes';
import BackArrow from '../../assets/icons/backArrow-white.svg';
import ClockIcon from '../../assets/icons/time_icon.svg';
import LinkIcon from '../../assets/icons/link_web_icon.svg';
import StarIcon from '../../assets/icons/star_icon.svg';
import LocationIcon from '../../assets/icons/location_icon.svg';

import MarkerIcon2 from '../../assets/icons/Marker2.svg';
import dayjs from 'dayjs';
import { useNavigation } from '@react-navigation/native';
import * as Location from 'expo-location';

const StoreInfoModal = ({ data, onClose }) => {
  const navigation = useNavigation();
  const [location, setLocation] = useState(null);
  const [statuss, setStatus] = useState(null);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      setStatus(status);

      if (status !== 'granted') {
        Alert.alert(
          'Accès Refusé',
          "L'application Kréocarte' a besoin d'accéder à votre emplacement pour que vous puissiez utiliser Google Maps."
        );
      }

      const userLocation = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Highest,
        maximumAge: 10000,
      });
      setLocation(userLocation);
    })();
  }, []);

  return (
    <View>
      <View style={styles.headerContainer}>
        <TouchableOpacity onPress={onClose}>
          <BackArrow />
        </TouchableOpacity>
        <Text style={[styles.textSemiBold, styles.storeName]}>{data?.nom}</Text>
      </View>
      <View style={styles.contentContainer}>
        <View style={{ paddingBottom: 10 }}>
          <Text
            numberOfLines={3}
            ellipsizeMode="tail"
            style={[styles.textMedium, styles.address]}
          >
            {data.description}
          </Text>
        </View>

        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={styles.mapContainer}>
            {statuss == 'granted' && (
              <MapView
                provider={PROVIDER_GOOGLE}
                style={styles.map}
                zoomControlEnabled={true}
                showsScale={true}
                zoomEnabled={true}
                showsUserLocation
                region={{
                  latitude: data?.latitude,
                  longitude: data?.longitude,
                  latitudeDelta: 0.457393734930383,
                  longitudeDelta: 0.414590573310852,
                }}
              >
                <Marker
                  title={data?.nom}
                  description={data?.description}
                  coordinate={{
                    latitude: data?.latitude,
                    longitude: data?.longitude,
                  }}
                >
                  <MarkerIcon2 />
                </Marker>
              </MapView>
            )}
            {statuss == 'denied' && (
              <TouchableOpacity
                onPress={() =>
                  Alert.alert(
                    'Accès Refusé',
                    "L'application Kréocarte' a besoin d'accéder à votre emplacement pour que vous puissiez utiliser Google Maps."
                  )
                }
              >
                <View
                  style={{
                    backgroundColor: 'gray',
                    width: '100%',
                    height: '100%',
                  }}
                ></View>
              </TouchableOpacity>
            )}
          </View>
          <View style={styles.line} />

          <View style={styles.addressContainer}>
            <LocationIcon />
            <Text style={[styles.textMedium, styles.address]}>
              {data.adresse}
            </Text>
          </View>
          <View style={styles.locationButton}>
            <CustomButtonComponent
              type="round-white"
              value="Voir itinéraire"
              onPress={() => {
                const scheme = Platform.select({
                  ios: 'maps:0,0?q=',
                  android: 'geo:0,0?q=',
                });
                const latLng = `${data.latitude},${data.longitude}`;
                const label = data.nom;
                const url = Platform.select({
                  ios: `${scheme}${label}@${latLng}`,
                  android: `${scheme}${latLng}(${label})`,
                });
                Linking.openURL(url);
              }}
            />
          </View>

          {data.telephone ? (
            <TouchableOpacity
              onPress={() => Linking.openURL(`tel:${data.telephone}`)}
            >
              <Text style={[styles.textRegular, styles.telephone]}>
                Téléphone {data.telephone}
              </Text>
            </TouchableOpacity>
          ) : (
            <></>
          )}

          <View style={styles.line} />

          <View style={styles.datesContainer}>
            <View style={{ paddingBottom: 80 }}>
              <ClockIcon />
            </View>
            <View style={{ marginLeft: moderateScale(10) }}>
              {data?.horaires.map((item, i) => {
                return (
                  <Text
                    style={[styles.textRegular]}
                    key={`day-${i.toString()}`}
                  >
                    {item.day}
                  </Text>
                );
              })}
            </View>
            <View style={{ marginLeft: moderateScale(50) }}>
              {data?.horaires.map((item, i) => {
                return (
                  <Text
                    style={[styles.textRegular]}
                    key={`day-${i.toString()}`}
                  >
                    {dayjs(item.opening).format('HH:mm')} -{' '}
                    {dayjs(item.closing).format('HH:mm')}
                  </Text>
                );
              })}
            </View>
          </View>

          {data.website ? (
            <>
              <View style={styles.line} />
              <TouchableOpacity
                onPress={() => Linking.openURL(data.website)}
                style={styles.webLinkContainer}
              >
                <View style={{ marginLeft: 21 }}>
                  <Text
                    numberOfLines={1}
                    ellipsizeMode="tail"
                    style={[styles.textSemiBold, styles.webLink]}
                  >
                    {data.website}
                  </Text>
                </View>
                <View style={{ marginRight: 20 }}>
                  <LinkIcon />
                </View>
              </TouchableOpacity>
            </>
          ) : (
            <></>
          )}

          <View style={styles.line} />
          <View style={styles.rateButton}>
            <CustomButtonComponent
              icon={<StarIcon />}
              type="round-primary"
              value="Évaluez ce Magasin"
              onPress={() => {
                navigation.navigate('RatingPage', { data });
                onClose();
              }}
            />
          </View>
        </ScrollView>
      </View>
    </View>
  );
};

export default StoreInfoModal;

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: verticalScale(10),
    marginTop: verticalScale(40),
  },
  contentContainer: {
    flex: 1,
    width: windowWidth - 30,
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 15,
    borderWidth: 2,
    borderColor: '#4DBDF2',
  },
  mapContainer: {
    height: windowHeight / 3.5,
    borderRadius: 15,
    overflow: 'hidden',
  },
  map: {
    flex: 1,
  },
  textMedium: {
    fontFamily: 'MontserratMedium',
    color: '#707070',
  },
  textRegular: {
    fontFamily: 'MontserratRegular',
    color: '#707070',
  },
  textSemiBold: {
    fontFamily: 'MontserratSemiBold',
    color: '#707070',
  },
  textBold: {
    fontFamily: 'MontserratBold',
    color: '#707070',
  },
  storeName: {
    fontSize: moderateScale(17),
    color: 'white',
    marginLeft: 5,
  },
  addressContainer: {
    flexDirection: 'row',
    marginTop: 15,
    paddingRight: 20,
  },
  address: {
    fontSize: moderateScale(17),
    color: '#707070',
  },
  locationButton: {
    marginTop: 20,
  },
  telephone: {
    textAlign: 'center',
    marginTop: 15,
  },
  datesContainer: {
    marginTop: moderateVerticalScale(20),
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    right: 0,
  },
  time: {
    marginTop: 5,
  },
  webLinkContainer: {
    flexDirection: 'row',
    marginTop: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  webLink: {
    color: '#4DBDF2',
    fontSize: moderateScale(15),
    marginRight: 5,
  },
  rateButton: {
    marginTop: 30,
    marginBottom: 20,
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: '#00000029',
    bottom: -10,
  },
});
