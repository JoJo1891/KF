import React from "react";

import { View, Text, StyleSheet,TouchableOpacity } from "react-native";

import { moderateScale, moderateVerticalScale } from "react-native-size-matters";
import AdvantagesIcon from "../../assets/icons/advantages-icon.svg";
import CloseIcon from "../../assets/icons/close_gray.svg";

const AdvantagesModal = ({id,recompense,conditions,type_recompense,onClose}) => {
  return (
    <View>
      <View style={styles.container}>
        <TouchableOpacity onPress={onClose} style={styles.closeIcon}><CloseIcon/></TouchableOpacity>
        <Text style={styles.title}>
            Avantage
        </Text>
        <Text style={styles.description}>{recompense}</Text>
      </View>
      <View style={styles.boxIconContainer}>
           <AdvantagesIcon width={moderateScale(140)} height={moderateVerticalScale(140)}/>
    </View>
    </View>
  );
};

export default AdvantagesModal;

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
    paddingTop : 30,
    backgroundColor: "white",
    marginHorizontal : 15,
    borderRadius : 15,
  },
  boxIconContainer: {
    position: "absolute",
    top: -(moderateVerticalScale(100)),
    left: 0,
    right: 0,
    alignItems : 'center'
  },
  title: {
    fontFamily: "MontserratMedium",
    color: "#0C3E87",
    fontSize: moderateScale(18),
    textAlign: "center",
    marginTop : 15,
  },
  description : {
    color : '#7D7D7D',
    fontFamily : 'MontserratRegular',
    fontSize: moderateScale(14),
    textAlign : 'center',
    marginTop : 10,
    marginBottom : moderateVerticalScale(80)
  },
  closeIcon :{
    alignSelf : 'flex-end'
  },
  celebrationIconContainer :{
    flexDirection : 'row',
    justifyContent: 'space-between',
    marginTop : moderateVerticalScale(50)
  },
  rightIcon : {
    transform : [{
     scaleX : -1   
    }]
  }
});
