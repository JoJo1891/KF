import React from 'react';

import {View,Text,StyleSheet} from 'react-native';

import { moderateScale } from 'react-native-size-matters';
import { windowWidth } from '../../themes'
import CustomButtonComponent from '../CustomButtonComponent';
import Loader from '../Loader'


const ConfirmationModal = ({type,value,onCancel,onSubmit,isLoading}) => {

    return (
      <View>
        {type === "inverse" && (
          <View style={[styles.container, { borderColor: "#FE6869" }]}>
            {isLoading ? (
              <View style={{ alignSelf: "center" }}>
                <Loader />
              </View>
            ) : (
              <View>
                <Text style={[styles.text, { color: "#FE6869" }]}>{value}</Text>
                <View style={styles.buttonsContainer}>

                  <View style={[styles.buttonContainer,{marginRight : 15}]}>
                    <CustomButtonComponent
                      value="Non"
                      type="round-primary"
                      onPress={onSubmit}
                    />
                  </View>

                  <View style={styles.buttonContainer}>
                    <CustomButtonComponent
                      value="Oui"
                      type="round-secondary"
                      onPress={onCancel}
                    />
                  </View>
                  
                </View>
              </View>
            )}
          </View>
        )}

        {!(type || type === "normal") && (
          <View style={[styles.container, { borderColor: "#4DBDF2" }]}>
            {isLoading ? (
              <View style={{ alignSelf: "center" }}>
                <Loader />
              </View>
            ) : (
              <View>
                <Text style={[styles.text, { color: "#174B9D" }]}>{value}</Text>
                <View style={styles.buttonsContainer}>

                  <View style={[styles.buttonContainer,{marginRight : 15}]}>
                    <CustomButtonComponent
                      value="Non"
                      type="round-secondary"
                      onPress={onCancel}
                    />
                  </View>

                  <View style={[styles.buttonContainer]}>
                    <CustomButtonComponent
                      value="Oui"
                      type="round-primary"
                      onPress={onSubmit}
                    />
                  </View>

                </View>
              </View>
            )}
          </View>
        )}
      </View>
    );
}

export default ConfirmationModal;

const styles = StyleSheet.create({
    container: {
        width : windowWidth-30,
        paddingHorizontal: 15,
        paddingVertical : 30,
        backgroundColor: "white",
        marginHorizontal : 15,
        borderRadius : 15,
        borderWidth : 2,
    },
    buttonsContainer :{
        marginTop : 25,
        flexDirection : 'row',
        justifyContent : 'space-between',
    },
    buttonContainer :{
        flex : 1
    },
    text : {
        fontFamily : 'MontserratMedium',
        textAlign : 'center',
        fontSize : moderateScale(17)
    }
});