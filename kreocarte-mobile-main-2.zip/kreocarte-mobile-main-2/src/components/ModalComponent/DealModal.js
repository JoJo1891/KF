import React, { useEffect, useState } from "react";

import { View, Text, Alert, StyleSheet, TouchableOpacity } from "react-native";

import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";
import DealIcon from "../../assets/icons/discount_icon.svg";
import CloseIcon from "../../assets/icons/close_gray.svg";
import CelebrationIcon from "../../assets/icons/celebration_icon.svg";
import "dayjs/locale/fr";
import { useMutation, useQueryClient } from "react-query";
import ConfirmationModalDeals from "../../components/ModalComponent/ConfirmationModalDeal";
import dayjs from "dayjs";
import ModalComponent from "../../components/ModalComponent/index";
import { requestCodeDeal } from "../../api/challenges";

const DealModal = ({
  deal,
  onClose,
  reward,
  points,
  store,
  expired,
  userPoints,
  quantity,
}) => {
  const deal_id = deal?.id;

  const queryClient = useQueryClient();
  const [modalVisible, setModalVisible] = useState(false);
  const [dealData, setDeal] = useState(deal ? deal : {});

  const { mutate, isLoading } = useMutation(requestCodeDeal, {
    onSuccess: (data) => {
      setDeal(data);
      setModalVisible(!modalVisible);
    },
    onError: (error) => {
      setModalVisible(!modalVisible);
      if (error.message === "Request failed with status code 400") {
        Alert.alert("Error", "Pas assez de points");
      } else {
        Alert.alert("Error ");
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries("requestCodeDeal");
    },
  });

  const handleSubmit = (deal_id) => {
    mutate({
      deal_id,
    });
  };

  useEffect(() => {
    //queryClient.refetchQueries("deals");
  }, [dealData]);

  return (
    <View>
      <View style={styles.container}>
        <TouchableOpacity onPress={onClose} style={styles.closeIcon}>
          <CloseIcon />
        </TouchableOpacity>
        <Text style={styles.text}>
          Félicitations, vous avez reçu cette offre de {store}
        </Text>
        <Text style={styles.margin}>{reward}</Text>

        <View style={styles.celebrationIconContainer}>
          <CelebrationIcon
            width={moderateScale(60)}
            height={moderateVerticalScale(60)}
          />
          {dealData?.status == "RECEIVED" && (
            <View style={{ paddingTop: 10 }}>
              <ModalComponent modalVisible={modalVisible}>
                <ConfirmationModalDeals
                  onCancel={() => setModalVisible(!modalVisible)}
                  onSubmit={() => handleSubmit(deal_id)}
                  id={deal_id}
                  isLoading={isLoading}
                />
              </ModalComponent>

              {userPoints < points ? (
                <View style={styles.boxContainer2}>
                  <View style={styles.center}>
                    <Text style={styles.buttonText3}>Points insuffisants</Text>
                  </View>
                </View>
              ) : (
                <TouchableOpacity
                  onPress={() => setModalVisible(!modalVisible)}
                >
                  <View style={styles.boxContainer}>
                    <View style={styles.center}>
                      <Text style={styles.buttonText}>Utiliser Deal</Text>
                    </View>
                  </View>
                </TouchableOpacity>
              )}
            </View>
          )}

          {/* -------------------Used-------------------- */}

          {dealData?.status == "USED" && (
            <View style={{ paddingTop: 10 }}>
              <View style={styles.boxContainer2}>
                <View style={styles.center}>
                  <Text style={styles.buttonText1}>Utilisé</Text>
                </View>
              </View>
            </View>
          )}

          {/* -------------------EXPIRED-------------------- */}

          {dealData?.status == "EXPIRED" && (
            <View style={{ paddingTop: 10 }}>
              <View style={styles.boxContainer2}>
                <View style={styles.center}>
                  <Text style={styles.buttonText3}>EXPIRÉ</Text>
                </View>
              </View>
            </View>
          )}

          {/* -------------------Code-------------------- */}

          {dealData?.status == "IN_USED" && (
            <View style={{ paddingTop: 10 }}>
              <TouchableOpacity>
                <Text selectable={true} style={styles.buttonText2}>
                  Code : {dealData?.code}
                </Text>
              </TouchableOpacity>
            </View>
          )}

          {/* -------------------null-------------------- */}

          {dealData?.status === undefined && (
            <View style={{ paddingTop: 10 }}>
              <View style={styles.boxContainer2}>
                <View style={styles.center}>
                  <Text style={styles.buttonText3}>Points insuffisants</Text>
                </View>
              </View>
            </View>
          )}

          <View style={styles.rightIcon}>
            <CelebrationIcon
              width={moderateScale(60)}
              height={moderateVerticalScale(60)}
            />
          </View>
        </View>

        {dealData?.status == "IN_USED" && (
          <View>
            <Text style={styles.text2}>
              Communiquez ce code au commerçant afin d'utiliser votre deal
            </Text>
          </View>
        )}

        <View
          style={{
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <View
            style={{
              width: "90%",
              flexDirection: "row",
              paddingTop: 10,
            }}
          >
            <View
              style={{
                width: "100%",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Text style={styles.text2}>
                Points: {points}
                {"  "} l'offre expire:{"  "}
                {dayjs(expired).locale("fr").format("DD MMMM YYYY")}
              </Text>
            </View>
          </View>
          <View style={styles.quantityContainer}>
            <Text style={styles.text2}>Quantité: {quantity}</Text>
          </View>
        </View>
      </View>

      <View style={styles.boxIconContainer}>
        <DealIcon
          width={moderateScale(140)}
          height={moderateVerticalScale(140)}
        />
      </View>
    </View>
  );
};

export default DealModal;

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: moderateScale(17),
    paddingVertical: moderateVerticalScale(30),
    backgroundColor: "white",
    marginHorizontal: moderateScale(15),
    borderRadius: moderateScale(15),
  },
  quantityContainer: {
    paddingTop: 10,
  },
  boxIconContainer: {
    position: "absolute",
    top: -moderateVerticalScale(100),
    left: 0,
    right: 0,
    alignItems: "center",
  },
  boxContainer: {
    borderColor: "#FE6869",
    height: moderateScale(40),
    width: moderateScale(140),
    borderRadius: 10,
    borderWidth: 2.5,
    overflow: "hidden",
  },
  boxContainer2: {
    borderColor: "#669c36",
    height: moderateScale(40),
    width: moderateScale(140),
    borderRadius: 10,
    borderWidth: 2.5,
  },
  buttonText: {
    color: "#FE6869",
    fontFamily: "MontserratMedium",
    fontSize: moderateScale(21),
  },
  buttonText1: {
    color: "#669c36",
    fontFamily: "MontserratMedium",
    fontSize: moderateScale(30),
  },
  buttonText2: {
    textAlign: "center",
    color: "#FE6869",
    fontFamily: "MontserratMedium",
    fontSize: moderateScale(25),
  },
  buttonText3: {
    color: "#669c36",
    fontFamily: "MontserratMedium",
    fontSize: moderateScale(14),
  },
  text: {
    fontFamily: "MontserratMedium",
    color: "#0C3E87",
    fontSize: moderateScale(18),
    textAlign: "center",
    marginTop: 15,
  },
  text2: {
    fontFamily: "MontserratMedium",
    color: "#0C3E87",
    fontSize: moderateScale(12),
    textAlign: "center",
  },
  closeIcon: {
    alignSelf: "flex-end",
  },
  margin: {
    alignItems: "center",
    textAlign: "center",
    marginTop: moderateVerticalScale(20),
  },
  celebrationIconContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: moderateVerticalScale(20),
  },
  rightIcon: {
    transform: [
      {
        scaleX: -1,
      },
    ],
  },
  center: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: "center",
    alignItems: "center",
  },
});
