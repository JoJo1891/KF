import React from "react";

import { View, Text, StyleSheet } from "react-native";

import { windowWidth } from "../../themes";
import CustomButtonComponent from "../CustomButtonComponent";
import Loader from "../Loader";
import { moderateScale, moderateVerticalScale } from "react-native-size-matters";


const ConfirmationModalDeals = ({
  type,
  value,
  onCancel,
  onSubmit,
  id,
  isLoading,
}) => {
  return (
    <View>
      <View style={[styles.container, { borderColor: "#4DBDF2" }]}>
        <View>
          <Text style={[styles.text, { textAlign: "center" }]}>
            Êtes vous sur de vouloir utiliser ce deal
          </Text>
        </View>

        <View>
          <Text style={[styles.text, { color: "#174B9D" }]}>{value}</Text>
          <View style={styles.buttonsContainer}>
            <View style={[styles.buttonContainer, { marginRight: 15 }]}>
              <CustomButtonComponent
                value="Non"
                type="round-secondary"
                onPress={onCancel}
              />
            </View>
            <View style={[styles.buttonContainer]}>
              <CustomButtonComponent
                value="Oui"
                type="round-primary"
                onPress={onSubmit}
                disabled={isLoading}
              />
            </View>
          </View>
        </View>
        <View>
          <Text style={styles.text2}>
            si vous appuyez sur "oui" communiquez ce code au commerçant pour
            utiliser votre offre
          </Text>
        </View>
        {isLoading && (
          <View
            style={{
              marginTop: moderateVerticalScale(10),
            }}
          >
            <Loader />
          </View>
        )}
      </View>
    </View>
  );
};

export default ConfirmationModalDeals;

const styles = StyleSheet.create({
  container: {
    width: windowWidth - 30,
    paddingHorizontal: 15,
    paddingVertical: 30,
    backgroundColor: "white",
    marginHorizontal: 15,
    borderRadius: 15,
    borderWidth: 2,
  },
  buttonsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  buttonContainer: {
    flex: 1,
  },
  text: {
    fontFamily: "MontserratMedium",
    textAlign: "center",
    fontSize: moderateScale(17),
  },
  text2: {
    fontFamily: "MontserratMedium",
    color: "#0C3E87",
    fontSize: moderateScale(12),
    textAlign: "center",
    marginTop: 15,
  },
});
