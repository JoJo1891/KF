import React from "react";

import {
  Modal,
  View,
  StyleSheet,
} from "react-native";

const ModalComponent = ({
    children,
    modalVisible,bgType
}) => {

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={modalVisible}
    >
      {!bgType &&
          <View style={styles.centeredView}>
            {children}
         </View>}
      {bgType &&
          <View style={styles.centeredViewTransparent}>
            {children}
         </View>}
    </Modal>
  );
};

export default ModalComponent;

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#000000aa",
  },
  centeredViewTransparent: {
    flex: 1,
    justifyContent:'center',
    alignItems: "center",
    // flex: 1,
    // position : 'absolute',
    // bottom:-10,
    // marginHorizontal:16,
    // alignItems:'center',
    // height : windowHeight/1.7
  }
});
