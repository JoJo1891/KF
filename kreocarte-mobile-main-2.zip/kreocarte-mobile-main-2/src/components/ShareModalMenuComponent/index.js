import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, Share } from "react-native";
import { useNavigation } from "@react-navigation/native";
import WhatsappIcon from "../../assets/icons/whatsapp.svg";
import InstagramIcon from "../../assets/icons/instagram.svg";
import FacebookIcon from "../../assets/icons/facebook.svg";
import Shares from "../../assets/icons/share.svg";
import { moderateScale } from "react-native-size-matters";

const ShareModalMenuComponent = ({ referal }) => {
  const navigation = useNavigation();
  const onShare = async () => {
    try {
      const result = await Share.share({
        title: "Kréocarte",
        message: `Rejoins Kréocarte' et retrouve toutes tes cartes de fidélité, bons plans et codes promos de tes commerces préférés. Cumule un max de points fidélité et de cadeaux sur, utilisant le code: \n \n ${referal} \n \n`,
        url: "https://gofid.page.link/register",
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      Alert.alert(error.message);
    }
  };
  return (
    <View>
      <TouchableOpacity
        style={{
          width: moderateScale(300),
          height: moderateScale(40),
          justifyContent: "center",
          display: "flex",
          alignItems: "center",
          borderRadius: 20,
          borderColor: "#FFFFFF",
          borderWidth: 1,
        }}
        onPress={onShare}
      >
        <View style={{ display: "flex", flexDirection: "row" }}>
          <Text style={[styles.text, { paddingRight: 10 }]}>
            Partagez votre code
          </Text>
          <Shares />
        </View>
      </TouchableOpacity>

      {/* <TouchableOpacity
        onPress={() =>
          Share.share({
            message: `Rejoins GoFid' et retrouve toutes tes cartes de fidélité, bons plans et codes promos de tes commerces préférés. Cumule un max de points fidélité et de cadeaux sur "https://gofid.page.link/register", utilisant le code: \n \n ${referal}`,
          })
        }
      >
        <View style={[styles.menuRows, { paddingTop: 20 }]}>
          <View style={styles.icons}>
            <WhatsappIcon />
          </View>
          <Text style={styles.menuTxt}>Whatsapp</Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() =>
          Share.share({
            message: `Rejoins GoFid' et retrouve toutes tes cartes de fidélité, bons plans et codes promos de tes commerces préférés. Cumule un max de points fidélité et de cadeaux sur "https://gofid.page.link/register", utilisant le code: \n \n ${referal}`,
          })
        }
      >
        <View style={styles.menuRows}>
          <View style={styles.icons}>
            <InstagramIcon />
          </View>
          <Text style={styles.menuTxt}>Instagram</Text>
        </View>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() =>
          Share.share({
            message: `Rejoins GoFid' et retrouve toutes tes cartes de fidélité, bons plans et codes promos de tes commerces préférés. Cumule un max de points fidélité et de cadeaux sur "https://gofid.page.link/register", utilisant le code: \n \n ${referal}`,
          })
        }
      >
        <View style={styles.menuRows}>
          <View style={styles.icons}>
            <FacebookIcon />
          </View>
          <Text style={styles.menuTxt}>Facebook</Text>
        </View>
      </TouchableOpacity> */}

      <View style={[styles.menuRows, { paddingTop: 10 }]}>
        <Text style={styles.menuCopier}>Copier le Code</Text>
      </View>

      <View style={styles.button}>
        <Text
          selectable={true}
          style={styles.Text}
          numberOfLines={2}
          ellipsizeMode="tail"
        >
          {referal}
        </Text>
      </View>
    </View>
  );
};

export default ShareModalMenuComponent;

const styles = StyleSheet.create({
  iconHeader: {
    width: 10,
    height: 10,
  },
  menuRows: {
    display: "flex",
    flexDirection: "row",
    marginBottom: 20,
    alignItems: "center",
    width: "100%",
  },
  icons: {
    width: "10%",
    alignItems: "center",
  },
  menuTxt: {
    marginLeft: 21,
    fontFamily: "MontserratMedium",
    fontSize: 18,
    color: "white",
    textAlign: "left",
    width: "80%",
  },
  menuCopier: {
    marginTop: 10,
    fontFamily: "MontserratMedium",
    fontSize: 18,
    color: "white",
    textAlign: "left",
  },
  button: {
    width: moderateScale(300),
    height: moderateScale(40),
    backgroundColor: "#FFFFFF",
    borderRadius: moderateScale(50),
  },
  Text: {
    flex: 1,
    fontFamily: "MontserratMedium",
    textAlign: "center",
    paddingTop: moderateScale(10),
    color: "#707070",
    fontSize: 16,
  },
  text: {
    fontFamily: "MontserratMedium",
    fontSize: 18,
    color: "#FFFFFF",
    textAlign: "center",
  },
});
