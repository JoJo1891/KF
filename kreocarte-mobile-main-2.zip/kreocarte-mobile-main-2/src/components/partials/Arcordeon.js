import React, { useState } from "react";

import { StyleSheet, Text, View, TouchableOpacity } from "react-native";
import ArrowIcon from "../../assets/icons/backArrow.svg";

const Arcordeon = (props) => {
  const [icon, setIcon] = useState(false);

  const functionCombined = () => {
    props.press();
    if (icon === true) {
      setIcon(false);
    } else {
      setIcon(true);
    }
  };

  return (
    <View>
      {props.type === "1" && (
        <TouchableOpacity style={styles.labelBorder} onPress={functionCombined}>
          <Text style={styles.label}>{props.description}</Text>
          {icon ? (
            <View style={styles.icon2}>
              <ArrowIcon />
            </View>
          ) : (
            <View style={styles.icon}>
              <ArrowIcon />
            </View>
          )}
        </TouchableOpacity>
      )}

      {props.type === "2" && (
        <TouchableOpacity
          style={styles.labelBorder2}
          onPress={functionCombined}
        >
          <Text style={styles.label}>{props.description}</Text>
          {icon ? (
            <View style={styles.icon2}>
              <ArrowIcon />
            </View>
          ) : (
            <View style={styles.icon}>
              <ArrowIcon />
            </View>
          )}
        </TouchableOpacity>
      )}
    </View>
  );
};

export default Arcordeon;

const styles = StyleSheet.create({
  labelBorder: {
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    width: "100%",
    height: 100,
  },
  label: {
    fontFamily: "MontserratMedium",
    fontSize: 24,
    color: "#174B9D",
    flexDirection: "row",
    textAlign: "left",
    width: "90%",
  },
  labelBorder2: {
    alignItems: "center",
    borderColor: "#EBEBEB",
    flexDirection: "row",
    width: "100%",
    height: 60,
  },
  icon: {
    // width: "10%",
    alignItems: "flex-end",
    transform: [{ rotate: "270deg" }],
  },
  icon2: {
    // width: "10%",
    alignItems: "flex-end",
    transform: [{ rotate: "90deg" }],
  },
});
