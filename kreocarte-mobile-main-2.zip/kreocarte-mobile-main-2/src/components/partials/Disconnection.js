import React from 'react';
import {useDispatch,useSelector} from 'react-redux'
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity
} from 'react-native';
import DisconIcon from '../../assets/icons/disconnection.svg';
import { selectIsLogged, setIsLogged, setUser } from '../../state/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { deleteNotificationsToken } from '../../api/notifications';
import { useMutation, useQueryClient } from 'react-query';


const Disconnection = (props) => {

  const isLogged = useSelector(selectIsLogged)
  const dispatch = useDispatch()
  const queryClient = useQueryClient();

  const { mutate, isLoading, isError } = useMutation(deleteNotificationsToken, {
    onSuccess: (response) => {
      //console.log(response)
       AsyncStorage.removeItem('token')
    },
    onError: (error) => {
     // console.log(error);
    },
    onSettled: () => {
      queryClient.invalidateQueries("deleteNotificationsToken");
    },
  });

  const logOut = async () =>{
    mutate();
    dispatch(setIsLogged(false))
    dispatch(setUser(null))
   
  }



  return (
    <View>
        {isLogged &&<TouchableOpacity style={styles.authButton} onPress={logOut}>
            <Text style={styles.authButtText}>Déconnexion</Text>
            <DisconIcon />
        </TouchableOpacity>}
    </View>
  );
}

export default Disconnection;

const styles = StyleSheet.create({
    authButton:{
        alignSelf: 'stretch',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row'
    },
    authButtText:{
        fontSize: 18,
        color: "#FE6869",
        textAlign:'center',
        fontFamily: 'MontserratSemiBold',
        paddingRight: 5.5
        
    },

});