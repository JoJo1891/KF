import React from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity
} from 'react-native';


const GofidButton = (props) => {
  return (
    <View>
      {props.name === 'blue' &&
        <TouchableOpacity disabled={props.disabled} style={[styles.blueButton,{backgroundColor: props.disabled ? '#dcdcdc' : '#174B9D'}]} onPress={props.press} type={props.type}>
            <Text style={styles.buttText}>{props.value}</Text>
        </TouchableOpacity>
        }

      {props.name === 'red' &&
        <TouchableOpacity disabled={props.disabled} style={[styles.redButton,{backgroundColor: props.disabled ? '#dcdcdc' : '#FE6869'}]} onPress={props.press}>
            <Text style={styles.buttText}>{props.value}</Text>
        </TouchableOpacity>
        }

    {props.name === 'partager' &&
        <TouchableOpacity disabled={props.disabled} style={[styles.partagerButton,{backgroundColor: props.disabled ? '#dcdcdc' : '#FFFFFF'}]} onPress={props.press} type={props.type}>
            <Text style={styles.partagerTxt}>{props.value}</Text>
        </TouchableOpacity>
        }

    {props.name === 'white' &&
        <TouchableOpacity disabled={props.disabled} style={[styles.whiteButton,{backgroundColor: props.disabled ? '#dcdcdc' : '#FFFFFF'}]} onPress={props.press} type={props.type}>
            <Text style={styles.WhiteText}>{props.value}</Text>
        </TouchableOpacity>
        }

    </View>
  );
}

export default GofidButton;

const styles = StyleSheet.create({
    blueButton:{
        alignSelf: 'stretch',
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 25,
        flexDirection: 'row',
        backgroundColor: '#174B9D',
        
    },
    whiteButton:{
      alignSelf: 'stretch',
      height: 50,
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 25,
      flexDirection: 'row',
      backgroundColor: '#FFFFFF',
      
    },  
    WhiteText:{
      fontSize: 20,
      color: "#174B9D",
      textAlign:'center',
      fontFamily: 'MontserratSemiBold',
    
    },
    buttText:{
      fontSize: 20,
      color: "#FFFFFF",
      textAlign:'center',
      fontFamily: 'MontserratSemiBold',
        
    },
    redButton:{
      alignSelf: 'stretch',
      height: 50,
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 25,
      flexDirection: 'row',
      backgroundColor: '#FE6869'
    },
    partagerButton:{
      alignSelf: 'stretch',
      height: 50,
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 25,
      flexDirection: 'row',
      backgroundColor: '#FFFFFF',
      width:'100%'
    },
    partagerTxt:{
      fontSize: 15,
      color: "#707070",
      textAlign:'center',
      fontFamily: 'MontserratSemiBold',
      
  },

});