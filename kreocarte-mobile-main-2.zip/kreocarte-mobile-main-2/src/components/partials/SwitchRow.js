import React, { useState } from 'react';

import {
  StyleSheet,
  Switch,
  View,
  Text,
  Alert
} from 'react-native';
import { useMutation } from 'react-query';
import { useDispatch } from 'react-redux';
import { allowEmailNotifications, allowNotifications } from '../../api/notifications';
import { editUser } from '../../state/auth';


const SwitchRow = ({stateNoti, state, title}) => {
    const [isEnabled, setIsEnabled] = useState(stateNoti);
    const dispatch = useDispatch();

    const { mutate, isLoading } = useMutation("setAllowNotification", allowNotifications, {
      onSuccess: (datas) => {
        dispatch(editUser(datas));
      },
      onError: (error) => {
        Alert.alert("Error", "Quelque chose s'est mal passé");
      },
    });

    const setEmailNotificationMutation = useMutation("allowEmailNotifications",allowEmailNotifications, {
      onSuccess: (response) => {
        dispatch(editUser(response));
      },
      onError: (error) => {
        Alert.alert("Error", "Quelque chose s'est mal passé")
      }
    });

    const toggleSwitch = () => {
      setIsEnabled(previousState => !previousState);
      if(state == 1){
        mutate()
      }else if(state == 2){
        setEmailNotificationMutation.mutate()
      }else{
        //
      }
    }
   

  return (
    <View style={ styles.labelBorder} > 
                        <Text style={styles.label}>
                             {title}
                        </Text>
                        <View style={styles.icon}>
                            <Switch
                                trackColor={{ false: "#EBEBEB", true: "#D1E8FC" }}
                                thumbColor={isEnabled ? "#174B9D" : "#7D7D7D"}
                                onValueChange={toggleSwitch}
                                value={isEnabled}
                            />
                        </View>
    </View>   
  );
}

export default SwitchRow;

const styles = StyleSheet.create({

    labelBorder:{
        alignItems:'center',
        flexDirection:"row", 
        width:'100%',
        height:68.3,
  },
  icon:{
    width:'20%',
    alignItems: 'center'
  },
  label: {
      fontFamily: 'MontserratSemiBold',
      fontSize: 20,
      color: '#174B9D',
      width:'80%',
      flexDirection:"row", 
      textAlign:'left'

  }
});