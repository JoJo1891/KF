import React, { useRef, useEffect } from 'react';

import BigChecked from '../../assets/icons/big-checked.svg';

import {
  StyleSheet,
  Animated
} from 'react-native';
import { windowHeight } from '../../themes';
import { moderateVerticalScale } from 'react-native-size-matters';

const AnimationSuccess = ({message,redirect}) => {
  const fadeAnim = useRef(new Animated.Value(0)).current
  const fadeOutAnim = useRef(new Animated.Value(1)).current
  const rotateAnim = useRef(new Animated.Value(360)).current
  const moveCheckUpAnim = useRef(new Animated.Value(10)).current

  useEffect(() => {
    Animated.timing(
      rotateAnim,
      {
        toValue: 0,
        duration : 9999,
        useNativeDriver: true,
        delay : 0
      }
    ).start();

    startTextAnim()
 
  }, [fadeAnim, fadeOutAnim, rotateAnim, moveCheckUpAnim])

  const startTextAnim = () => {
    Animated.timing(
      moveCheckUpAnim,
      {
        toValue: -5,
        delay: 1000,
        duration: 1000,
        useNativeDriver: true
      }
    ).start();

    Animated.timing(
      fadeAnim,
      {
        toValue: 1,
        delay: 2000,
        duration: 1000,
        useNativeDriver: true
      }
    ).start();

    Animated.timing(
      fadeOutAnim,
      {
        toValue: 0,
        duration: 1000,
        delay: 1000,
        useNativeDriver: true
      }
    ).start();
  }

  return (
    <Animated.View style={styles.full}>
      <Animated.View style={styles.checkContainer}>
        <Animated.View style={styles.BigChecked}>
          <Animated.View style={{transform: [{translateY: moveCheckUpAnim}]}}>
            <BigChecked />
          </Animated.View>
          <Animated.View style={{opacity: fadeAnim, marginTop:moderateVerticalScale(20)}}>
            <Animated.Text style={styles.checkText}>{message}</Animated.Text>
          </Animated.View>
        </Animated.View>
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  full: {
        minHeight: windowHeight + 50,
        backgroundColor:'white'
      },
  checkContainer: {
    position: 'relative',
    flexDirection: 'row',
    flex: 1,
    marginTop: windowHeight/3,
    justifyContent: 'center',
  },

  BigChecked: {
    width: '100%',
    flexDirection: 'column',
    position: 'absolute',
    alignItems: 'center',
  },

  checkText: {
    fontSize: 16,
    fontFamily: 'SegoeUISemiBold',
    color: "#174B9D"
  }
});

export default AnimationSuccess;