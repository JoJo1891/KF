import React, { useState, useRef, useEffect } from "react";
import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableWithoutFeedback,
  Modal,
  Animated,
  StatusBar,
  Button,
  TouchableOpacity,
} from "react-native";
import { Video } from "expo-av";
import Image from "react-native-image-progress";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { setViewedStory } from "../../api/stories";
import { useMutation, useQueryClient } from "react-query";
import { selectIsLogged } from "../../state/auth";
import { useSelector } from "react-redux";
const { width, height } = Dimensions.get("window");

const StoriesModal = ({ data, modalVisible, setModalVisible }) => {
  // THE CONTENT
  const queryClient = useQueryClient();
  const [content, setContent] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const isLogged = useSelector(selectIsLogged);

  const setViewedStoryMutation = useMutation("setViewedStory", setViewedStory, {
    onSuccess: (response) => {
      // console.log(response)
      queryClient.refetchQueries("storiesAuth");
    },
    onError: (error) => {
      console.log(error);
    },
  });

  useEffect(() => {
    if (data) {
      setContent(
        data.stories.map((media) => {
          return {
            id: media.story_id,
            viewed: media.isViewed,
            url: media.media,
            type: "image",
            finish: 0,
          };
        })
      );
      setIsLoading(false);
    }
  }, [data]);

  // i use modal for opening the instagram stories
  // for get the duration
  const [end, setEnd] = useState(0);
  // current is for get the current content is now playing
  const [current, setCurrent] = useState(0);
  // if load true then start the animation of the bars at the top
  const [load, setLoad] = useState(false);
  // progress is the animation value of the bars content playing the current state
  const progress = useRef(new Animated.Value(0)).current;

  function start(content, n) {
    // checking if the content type is video or not
    if (content[current]?.type == "video") {
      // type video
      if (load) {
        Animated.timing(progress, {
          toValue: 1,
          duration: n,
          useNativeDriver: false,
        }).start(({ finished }) => {
          if (finished) {
            next(content);
          }
        });
      }
    } else {
      // type image
      Animated.timing(progress, {
        toValue: 1,
        duration: 5000,
        useNativeDriver: false,
      }).start(({ finished }) => {
        if (finished) {
          next(content);
        }
      });
    }
  }

  function stop() {
    progress.stopAnimation(({ value }) => console.log("Final Value: " + value));
  }

  // handle playing the animation
  function play(content) {
    start(content, end);
  }

  // next() is for changing the content of the current content to +1
  function next(content) {
    // check if the last content is already viewed if not mark as viewed true
    const storyId = content[current].id;
    const viewed = content[current].viewed;
    if (!viewed && isLogged) {
      setViewedStoryMutation.mutate(storyId);
    }

    // check if the next content is not empty
    if (current !== content.length - 1) {
      let data = [...content];
      data[current].finish = 1;
      setContent(data);
      setCurrent(current + 1);
      progress.setValue(0);
      setLoad(false);
    } else {
      // the next content is empty
      close();
    }
  }

  // previous() is for changing the content of the current content to -1
  function previous(content) {
    // checking if the previous content is not empty
    if (current - 1 >= 0) {
      const storyId = content[current].id;
      const viewed = content[current].viewed;
      if (!viewed && isLogged) {
        setViewedStoryMutation.mutate(storyId);
      }
      let data = [...content];
      data[current].finish = 0;
      setContent(data);
      setCurrent(current - 1);
      progress.setValue(0);
      setLoad(false);
    } else {
      const storyId = content[current].id;
      const viewed = content[current].viewed;
      if (!viewed && isLogged) {
        setViewedStoryMutation.mutate(storyId);
      }
      // the previous content is empty
      close();
    }
  }

  // closing the modal set the animation progress to 0
  const close = () => {
    const storyId = content[current].id;
    const viewed = content[current].viewed;
    if (!viewed && isLogged) {
      setViewedStoryMutation.mutate(storyId);
    }
    progress.setValue(0);
    setLoad(false);
    setCurrent(0);
    setModalVisible(false);
  };

  return (
    <Modal animationType="fade" transparent={false} visible={modalVisible}>
      <View style={styles.containerModal}>
        <View style={styles.backgroundContainer}>
          {/* check the content type is video or an image */}
          {!isLoading && content[current].type == "video" ? (
            <Video
              source={{
                uri: content[current].url,
              }}
              rate={1.0}
              volume={1.0}
              resizeMode="cover"
              shouldPlay={true}
              positionMillis={0}
              // I WAS THINKING TO GET THE VIDEO THUMBNAIL BEFORE THE VIDEO LOADS UP
              // posterSource={{
              // 	uri: content[current].thumbnail,
              // }}
              // posterStyle={{
              // 	width: width,
              // 	height: height,
              // }}
              // usePoster
              onReadyForDisplay={play(content)}
              onPlaybackStatusUpdate={(AVPlaybackStatus) => {
                setLoad(AVPlaybackStatus.isLoaded);
                setEnd(AVPlaybackStatus.durationMillis);
              }}
              style={{ height: height, width: width }}
            />
          ) : (
            <View>
              {content && (
                <Image
                  onLoadEnd={() => {
                    progress.setValue(0);
                    play(content);
                  }}
                  source={{
                    uri: content[current].url,
                  }}
                  style={{ width: width, height: height, resizeMode: "cover" }}
                />
              )}
            </View>
          )}
        </View>
        <View
          style={{
            flexDirection: "column",
            flex: 1,
          }}
        >
          <LinearGradient
            colors={["rgba(0,0,0,1)", "transparent"]}
            style={{
              position: "absolute",
              left: 0,
              right: 0,
              top: 0,
              height: 100,
            }}
          />
          {/* ANIMATION BARS */}
          <View
            style={{
              flexDirection: "row",
              paddingTop: 40,
              paddingHorizontal: 10,
            }}
          >
            {!isLoading &&
              content.map((index, key) => {
                return (
                  // THE BACKGROUND
                  <View
                    key={key}
                    style={{
                      height: 2,
                      flex: 1,
                      flexDirection: "row",
                      backgroundColor: "rgba(117, 117, 117, 0.5)",
                      marginHorizontal: 2,
                    }}
                  >
                    {/* THE ANIMATION OF THE BAR*/}
                    <Animated.View
                      style={{
                        flex: current == key ? progress : 0,
                        height: 2,
                        backgroundColor: "rgba(255, 255, 255, 1)",
                      }}
                    ></Animated.View>
                  </View>
                );
              })}
          </View>
          {/* END OF ANIMATION BARS */}

          <View
            style={{
              height: 50,
              flexDirection: "row",
              justifyContent: "space-between",
              paddingHorizontal: 15,
            }}
          >
            {/* THE AVATAR AND USERNAME  */}
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              {data?.image_url && (
                <Image
                  style={{ height: 30, width: 30, borderRadius: 25 }}
                  source={{ uri: data?.image_url }}
                />
              )}
              <Text
                style={{
                  fontWeight: "bold",
                  color: "white",
                  paddingLeft: 10,
                }}
              >
                {data?.name || ""}
              </Text>
            </View>
            {/* END OF THE AVATAR AND USERNAME */}
            {/* THE CLOSE BUTTON */}
            <TouchableOpacity
              onPress={() => {
                close();
              }}
            >
              <View
                style={{
                  alignItems: "center",
                  justifyContent: "center",

                  height: 50,
                  paddingHorizontal: 15,
                }}
              >
                <Ionicons name="ios-close" size={28} color="white" />
              </View>
            </TouchableOpacity>
            {/* END OF CLOSE BUTTON */}
          </View>
          {/* HERE IS THE HANDLE FOR PREVIOUS AND NEXT PRESS */}
          <View style={{ flex: 1, flexDirection: "row" }}>
            <TouchableWithoutFeedback
              onPress={() => {
                if (!isLoading) previous(content);
              }}
              onLongPress={() => stop()}
              onPressOut={() => play(content)}
            >
              <View style={{ flex: 1 }}></View>
            </TouchableWithoutFeedback>
            <TouchableWithoutFeedback
              onPress={() => {
                if (!isLoading) next(content);
              }}
              onLongPress={() => stop()}
              onPressOut={() => play(content)}
            >
              <View style={{ flex: 1 }}></View>
            </TouchableWithoutFeedback>
          </View>
          {/* END OF THE HANDLE FOR PREVIOUS AND NEXT PRESS */}
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  containerModal: {
    flex: 1,
    backgroundColor: "#000",
  },
  backgroundContainer: {
    position: "absolute",

    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
});

export default StoriesModal;
