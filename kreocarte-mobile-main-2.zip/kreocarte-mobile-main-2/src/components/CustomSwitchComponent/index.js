import React from 'react';

import {
    View,
    StyleSheet,
    TouchableOpacity,
    Text,
} from 'react-native';

import { moderateScale } from 'react-native-size-matters';

const CustomSwitchComponent = ({title1,title2,value,onChange}) => {
    return (<View style={styles.switchContainer}>
        <TouchableOpacity onPress={()=>onChange(!value)} style={[styles.itemContainer, value ? styles.active :{}]}>
            <Text style={[styles.text, value ? styles.textActive :styles.textInactive]}>{title1}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={()=>onChange(!value)} style={[styles.itemContainer, value ? {} :styles.active]}>
            <Text style={[styles.text, value ? styles.textInactive :styles.textActive]}>{title2}</Text>
        </TouchableOpacity>
    </View>)
}

export default CustomSwitchComponent;

const styles = StyleSheet.create({
    switchContainer : {
        flex : 1,
        backgroundColor : '#EBEBEB',
        borderRadius : 1000,
        padding : 5,
        flexDirection : 'row',
    },
    itemContainer: {
        flex: 1,
        borderRadius : 1000,
        justifyContent : 'center',
        alignItems : 'center'
    },
    active : {
        backgroundColor : '#174B9D'
    },
    text : {
        fontFamily : 'MontserratRegular',
        fontSize : moderateScale(15)
    },
    textActive : {
        color : 'white'
    },
    textInactive : {
        color : '#7D7D7D'
    }
})