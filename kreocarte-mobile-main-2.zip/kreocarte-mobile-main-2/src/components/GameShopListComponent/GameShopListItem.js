import React from 'react';

import {
    View,
    StyleSheet,
    Image,
    Text
} from 'react-native';

import {windowWidth} from '../../themes';
import PointerProgress from '../../assets/icons/pogression_pointer_icon.svg';
import { moderateVerticalScale } from 'react-native-size-matters';

const GameShopListItem = ({bar1, bar2}) => {

   
    return (
        <View style={styles.itemsContainer}>
      
             {bar1 ?
                    <View style={styles.containerFirstYellow }>
                    </View>
                    :
                    <View style={styles.containerFirst}>
                    </View>
                }
             {bar2 ?
                    <View style={styles.containerLastYellow }>
                    </View>
                    :
                    <View style={styles.containerLast}>
                    </View>
              
                }
                
           
               
        
            <View style={{position:"absolute", top:30}}>
                <PointerProgress/>
            </View>
        
      
    </View>)
}

export default GameShopListItem;

const styles = StyleSheet.create({
    container : {
        flex : 1,
        flexDirection:'row',
        width : windowWidth,
        overflow : 'hidden',
        borderWidth : 1,
        borderColor : '#174B9D',
        justifyContent : 'center',
        alignItems: 'center',
        marginLeft: 0,
        marginRight: 0,
        borderBottomWidth:2,
        borderTopWidth:2,
    },
    containerFirst : {
        flex : 1,
        width : windowWidth/moderateVerticalScale(2.2),
        overflow : 'hidden',
        borderWidth : 1,
        borderColor : '#174B9D',
        borderBottomWidth:2,
        borderTopWidth:2,
        borderLeftWidth:2,
        borderTopLeftRadius:20,
        borderBottomLeftRadius:20,
    },
    containerFirstYellow : {
        flex : 1,
        width : windowWidth/moderateVerticalScale(2.2),
        overflow : 'hidden',
        borderWidth : 1,
        borderColor : '#174B9D',
        borderBottomWidth:2,
        borderTopWidth:2,
        borderLeftWidth:2,
        borderTopLeftRadius:20,
        borderBottomLeftRadius:20,
        backgroundColor: '#FFD974'
    },
    containerLast: {
        flex : 1,
        width : windowWidth/moderateVerticalScale(2.2),
        overflow : 'hidden',
        borderWidth : 1,
        borderColor : '#174B9D',
        borderBottomWidth:2,
        borderTopWidth:2,
        borderRightWidth:2,
        borderTopRightRadius:20,
        borderBottomRightRadius:20
    },
    containerLastYellow: {
        flex : 1,
        width : windowWidth/moderateVerticalScale(2.2),
        overflow : 'hidden',
        borderWidth : 1,
        borderColor : '#174B9D',
        borderBottomWidth:2,
        borderTopWidth:2,
        borderRightWidth:2,
        borderTopRightRadius:20,
        borderBottomRightRadius:20,
        backgroundColor: '#FFD974'

    },
    itemsContainer :{
        flexDirection: 'row',
        flex : 1,
        height : windowWidth/12,
        width: '100%',
        marginBottom:16
        
       
    }
})