import React, { useEffect, useState } from 'react';

import {
    View,
    StyleSheet,
    FlatList,
    Text,
    Alert
} from 'react-native';
import GameShopListItem from './GameShopListItem';
import { windowHeight, windowWidth } from "../../themes";
import MedailGrey from '../../assets/badges/medal__grey_small.svg'
import MedailGold from '../../assets/icons/medal.svg'
import * as Progress from 'react-native-progress';
import { moderateScale, moderateVerticalScale } from 'react-native-size-matters';


const GameShopListComponent = ({rewards, maxItem }) => {

  const [bar1,setBar1] = useState(false)
  const [bar2,setBar2] = useState(false)

  const arrayComplete = () => {
    if(rewards >= maxItem/2 && rewards < maxItem){
        setBar1(true)
        setBar2(false)
    }else if(rewards >= maxItem){
        setBar1(true)
        setBar2(true)
    }else {
        setBar1(false)
        setBar2(false)
     }
    } 

  useEffect(() => {
    arrayComplete()
  }, []);

   
  
    return (
      
    <View style={styles.listContainer}>
       <View>
        <View style={{ flexDirection:'row', position:"absolute", right:0, bottom:moderateVerticalScale(55) }}>
          {/* <View style={{flexDirection:'row'}}>
            <Text style={{fontSize:moderateVerticalScale(12), fontWeight:'bold', color:'#174B9D' }}>Récompense 1 </Text>
            {!bar1 &&
              <View style={{position:"relative", bottom:moderateVerticalScale(10)}}>
                 <MedailGrey/>
              </View>
            }
            {bar1 &&
              <View style={{position:"relative", bottom:moderateVerticalScale(10)}}>
                 <MedailGold/>
              </View>
            }
         </View>  */}

         <View style={{flexDirection:'row',  marginLeft:moderateScale(15)}}>
         <Text style={{fontSize:moderateVerticalScale(12), fontWeight:'bold', color:'#174B9D' }}>Récompense  </Text>
           {!bar2 &&
              <View style={{position:"relative", bottom:moderateVerticalScale(10)}}>
                 <MedailGrey/>
              </View>
            }
            {bar2 &&
              <View style={{position:"relative", bottom:moderateVerticalScale(10)}}>
                 <MedailGold/>
              </View>
            }
         </View> 
        </View>
        <View style={styles.container}>
           <Progress.Bar  progress={rewards/maxItem} 
                          width={windowWidth/1.2} 
                          height={moderateVerticalScale(20)} 
                          borderRadius={14}
                          borderWidth={2}
                          color={'#FFD974'}
                          borderColor={'#174B9D'}
                              />
            <View style={styles.containerFirst }>
              
            </View>
        </View>

       </View>
    </View>
  )
}

export default GameShopListComponent;

const styles = StyleSheet.create({
    listContainer: {
      height: windowHeight /moderateVerticalScale(12),
      flexDirection: "row",
      top:moderateVerticalScale(9),
    },
    container:{
      alignItems:'center',

    },
    containerFirst : {
      marginTop:moderateVerticalScale(-22),
      height:moderateVerticalScale(22),
      width : 2,
      backgroundColor: '#174B9D'
      
  }
   
});