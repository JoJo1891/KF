import React from "react";

import { View, StyleSheet, Text } from "react-native";

import { moderateScale } from "react-native-size-matters";
import { layoutStyles } from "../../themes";
import StarIcon from "../../assets/icons/star_icon.svg";
import WatchIcon from "../../assets/icons/time_icon.svg";
import LocationIcon from "../../assets/icons/location_icon.svg";
import WebIcon from "../../assets/icons/link_web_icon.svg";

const StoreInfo = (data) => {
  const rating = data?.card?.enseigne?.review.toFixed(1);

  return (
    <View style={[styles.container, layoutStyles.elevation]}>
      <View>
        <Text style={[styles.text, styles.infoText]}>Information</Text>
      </View>
      <View style={styles.iconsContainer}>
        <View style={{ paddingRight: moderateScale(10) }}>
          <LocationIcon />
        </View>
        <View style={{ paddingRight: moderateScale(10) }}>
          <WebIcon />
        </View>
        <View style={{ paddingRight: moderateScale(10) }}>
          <WatchIcon />
        </View>
        <StarIcon />
        <Text style={[styles.text, styles.blueText]}> {rating}/5</Text>
      </View>
    </View>
  );
};

export default StoreInfo;

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 15,
    paddingVertical: 20,
    borderRadius: 15,
    borderWidth: 2,
    borderColor: "#4DBDF2",
    backgroundColor: "white",
  },
  text: {
    fontFamily: "MontserratMedium",
  },
  infoText: {
    fontSize: moderateScale(20),
  },
  blueText: {
    color: "#4DBDF2",
    fontSize: moderateScale(16),
    marginLeft: 5,
  },
  iconsContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
});
