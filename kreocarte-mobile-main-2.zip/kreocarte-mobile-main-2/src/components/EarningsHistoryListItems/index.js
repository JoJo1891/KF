import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Platform,
  UIManager,
} from "react-native";
import { moderateScale, s } from "react-native-size-matters";
import { windowHeight, layoutStyles } from "../../themes";
import Points from '../../assets/icons/gf_points.svg'
import dayjs from 'dayjs';
import 'dayjs/locale/fr';

if (
  Platform.OS === "android" &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const EarningsHistoryListItems = ({ date_acquition, defi_gofid  }) => {
  
  return (
    <View style={[styles.container, layoutStyles.elevation]}>
        <View style={{flexDirection:'row', justifyContent:'space-between', }}>
            <View style={{flexDirection:"column", flexShrink:1}}>
                <Text style={styles.textTitle}>{dayjs(date_acquition).locale('fr').format('DD MMMM')}</Text>
                <Text style={styles.textSubTitle}>{defi_gofid.name}</Text>                
            </View>
            <View style={{flexDirection:'row', alignItems:'center'}}> 
                <Text style={styles.textPoint}>+{defi_gofid.points} </Text>
                <Points/>                
            </View>
        </View>
    </View>
  );
};

export default EarningsHistoryListItems;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    height: moderateScale(75),
    marginBottom: 15,
    marginTop: 5,
    borderRadius: 20,
    marginHorizontal: 15,
    paddingHorizontal: 15,
    justifyContent: "center",
  },
  textTitle: {
   fontSize : moderateScale(18),
   fontFamily: "MontserratSemiBold",
   color:'black',
  },
  textSubTitle: {
    fontFamily: "MontserratSemiBold",
    fontSize: moderateScale(15),
    color: "#B4B3B8",
  },
  textPoint: {
    fontFamily: "MontserratSemiBold",
    fontSize: moderateScale(28),
    color: "#174B9D",
    fontWeight:'bold'
  },
});
