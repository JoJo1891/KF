import React from 'react';

import {
    TouchableOpacity,
    StyleSheet,
    View,
    Text
} from 'react-native';
import { moderateScale, moderateVerticalScale } from 'react-native-size-matters';

const CustomButton = ({type = 'round-primary',value,onPress,disabled,icon}) => {
    return (<View>
        {type === 'round-disabled' && <TouchableOpacity
            onPress={onPress}
            disabled= {disabled}
            style={[styles.buttonContainer,styles.disabled,styles.round]}
          >
            {icon}
            <Text style={styles.text}>{value}</Text>
        </TouchableOpacity>}

        {type === 'round-primary' && <TouchableOpacity
            onPress={onPress}
            disabled= {disabled}
            style={[styles.buttonContainer,styles.default,styles.round,{opacity : disabled ? 0.6 : 1}]}
          >
            {icon}
            <Text style={styles.text}>{value}</Text>
        </TouchableOpacity>}

        {type === 'round-secondary' && <TouchableOpacity
            onPress={onPress}
            disabled= {disabled}
            style={[styles.buttonContainer,styles.secondary,styles.round]}
        >
            {icon}
            <Text style={styles.text}>{value}</Text>
        </TouchableOpacity>}

        {type === 'round-white' && <TouchableOpacity
            onPress={onPress}
            disabled= {disabled}
            style={[styles.buttonContainer,styles.default,styles.round,styles.whiteButton]}
          >
            {icon}
            <Text style={[styles.text,styles.blue]}>{value}</Text>
        </TouchableOpacity>}
    </View>)
}

export default CustomButton;

const styles = StyleSheet.create({
    buttonContainer : {
        flexDirection : 'row',
        justifyContent : 'center',
        alignItems : 'center',
        paddingVertical : moderateVerticalScale(10),
        paddingHorizontal : moderateScale(15)
    },
    round : {
        borderRadius : 1000
    },
    disabled : {
        backgroundColor : '#7D7D7D'
    },
    default : {
        backgroundColor : '#0C3E87'
    },
    secondary : {
        backgroundColor : '#FE6869'
    },
    whiteButton : {
        borderWidth : 2,
        borderColor : '#4DBDF2',
        backgroundColor : 'white'
    },
    blue : {
        color : '#4DBDF2'
    },
    text :{
        fontSize : moderateScale(17),
        fontFamily : 'MontserratSemiBold',
        color : 'white',
        marginLeft :5,
        textAlign : 'center'
    }
})