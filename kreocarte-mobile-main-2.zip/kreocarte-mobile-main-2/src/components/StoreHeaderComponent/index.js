import React from "react";

import {
  View,
  StyleSheet,
  Text,
  Image,
  TouchableOpacity,
  Platform,
} from "react-native";

import { useNavigation } from "@react-navigation/native";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";
import CarteIcon from "../../assets/icons/carte.svg";
import CashbackIcon from "../../assets/icons/cashback.svg";
import Progression from "../../assets/icons/progression.svg";

import { layoutStyles } from "../../themes";
import BackArrowIcon from "../../assets/icons/backArrow.svg";

const StoreHeaderComponent = ({ name, imageUrl, tintColor, status }) => {
  const navigation = useNavigation();
  return (
    <View style={styles.headerContainer}>
      <View style={styles.storeInfoContainer}>
      <View style={{width:'80%',  flex: 1,flexDirection: "row", alignItems: "center", justifyContent: "flex-start",}}>
        <TouchableOpacity
          onPress={() => navigation.navigate("Home")}
          style={
            Platform.OS === "android"
              ? styles.backButtonContainer
              : styles.backButtonContainer2
          }
        >
          <BackArrowIcon />
        </TouchableOpacity>

        {(imageUrl != null || imageUrl != undefined) && (
          <View style={[styles.storeImageContainer, layoutStyles.elevation]}>
            <Image
              source={{
                uri: imageUrl,
              }}
              style={styles.image}
              resizeMode="contain"
            />
          </View>
        )}
         
        {(name != null || name != undefined) && (
          <View style={{flex:1}}>
            <Text style={[styles.textBold, styles.storeName]}>{name}</Text>
          </View>
        )}
    </View>
    <TouchableOpacity  style={status == "POINTS"? styles.icon2 : styles.icon}>
            {status == "CASHBACK" && (
                <CashbackIcon />
            )}

            {status == "TAMPONS" && (
                <CarteIcon />
            )}

            {status == "POINTS" && (
                <Progression />
            )}
      </TouchableOpacity>
      </View>
    </View>
  );
};

export default StoreHeaderComponent;

const styles = StyleSheet.create({
  headerContainer: {
    flex: 1,
    flexDirection: "row",
    // justifyContent : 'space-between',
    alignItems: "center",
    paddingTop: moderateVerticalScale(30),
    paddingBottom: moderateVerticalScale(35),
    paddingHorizontal: 15,
  },
  storeInfoContainer: {
    flex: 1,
    flexDirection: "row",
    width:'100%',
    alignItems: "center",
    justifyContent: "flex-start",
  },
  storeImageContainer: {
    width: moderateScale(40),
    height: moderateVerticalScale(40),
    borderRadius: moderateScale(40),
    overflow: "hidden",
    borderWidth: 2,
    borderColor: "white",
    marginLeft: 10,
    backgroundColor: "#f0eceb",
  },
  backButtonContainer: {},
  backButtonContainer2: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignContent: "center",
  },
  image: {
    flex: 1,
  },
  text: {
    fontFamily: "MontserratRegular",
  },
  textBold: {
    fontFamily: "MontserratBold",
  },
  storeName: {
    fontSize: moderateScale(16),
    marginLeft: 7,
    color: "#343434",
  },
  icon:{
     width:'15%', 
     justifyContent:'flex-end', 
     alignItems:'center',
     marginRight:1
    },
    icon2:{
      width:'20%', 
      justifyContent:'flex-end', 
      alignItems:'center',
      marginRight:5
     }
});
