import React,{useEffect, useState} from "react";
import { useDispatch, useSelector } from "react-redux";

import { View, StyleSheet, Text, TouchableOpacity } from "react-native";

import { useNavigation } from "@react-navigation/native";
import { moderateScale } from "react-native-size-matters";
import GfPointsIcon from "../../assets/icons/gf_points.svg";
import BellIcon from "../../assets/icons/bell_home_icon.svg";
import { selectUser } from "../../state/auth";
import { selectNotification, setNotificationReceived } from "../../state/notificationsReceived";

const HomeHeaderComponent = ({ name, data }) => {
  const navigation = useNavigation();
  const user = useSelector(selectUser)
  const notificationReceived = useSelector(selectNotification)
  const dispatch = useDispatch();
  
  return (
    <View style={styles.headerContainer}>
      <View>
        <Text style={[styles.text, styles.nameText]}>Bonjour,</Text>
        <Text style={[styles.textBold, styles.nameText, (!user?.prenom ? {fontSize: moderateScale(13)} : {})]}  >{user?.prenom ? `${user.prenom}`: user?.email || "Invite"}</Text>
      </View>
      <View>
        <View style={styles.pointsContainer}>
          <TouchableOpacity
            onPress={() => navigation.navigate("MesPointsScreen")}
            style={{flexDirection : 'row',alignItems : 'center'}}
          >
            <Text style={[styles.points, styles.textBold]}>{ data?.points_gofid || 0}</Text>
            <GfPointsIcon />
          </TouchableOpacity> 
          <TouchableOpacity
            onPress={() => {navigation.navigate("NotificationScreen");
                            dispatch(setNotificationReceived(false));}}
            style={styles.bellIcon}
          >
            <BellIcon />
            {notificationReceived &&
              <View style={styles.dot} />
            }
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default HomeHeaderComponent;

const styles = StyleSheet.create({
  headerContainer: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 15,
    paddingHorizontal: 15,
  },
  text: {
    fontFamily: "MontserratRegular",
  },
  textBold: {
    fontFamily: "MontserratBold",
  },
  nameText: {
    fontSize: moderateScale(16),
  },
  pointsContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  points: {
    color: "#174B9D",
    fontSize: moderateScale(23),
    marginRight: 5,
  },
  pointsText: {
    color: "#174B9D",
    fontSize: moderateScale(10),
    marginLeft: 5,
  },
  bellIcon: {
    marginLeft: moderateScale(10),
    
  },
  dot: {
    position:'absolute',
    left:13,
    top:5,
    height: 10,
    width: 10,
    borderRadius: 10,
    backgroundColor: "red",
  },
});
