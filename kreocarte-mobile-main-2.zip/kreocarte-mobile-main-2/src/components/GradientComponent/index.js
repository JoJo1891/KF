import React from 'react';

import {
    StyleSheet
} from 'react-native';

import { LinearGradient } from 'expo-linear-gradient';

const Gradient = ({colors,style = {}}) => {
    return <LinearGradient
        colors={colors}
        style={[defaultStyles,style]}
    />
}

export default Gradient;

const defaultStyles = StyleSheet.create({
    gradient : {
        flex : 1
    }
})

