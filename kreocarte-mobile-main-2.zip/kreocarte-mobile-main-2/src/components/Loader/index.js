import React from 'react'
import {ActivityIndicator,StyleSheet} from 'react-native'

const Loader = ({size = "large"}) =>{
    return <ActivityIndicator
        size={size}
        style={styles.loader}
        color="#174B9D"
    />
}

export default Loader

const styles = StyleSheet.create({
    loader : {
        alignSelf : 'center'
    }
})