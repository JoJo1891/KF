import React from 'react';

import {
    View,
    StyleSheet,
    TextInput
} from 'react-native';
import {layoutStyles} from '../../themes';
import SearchIcon from '../../assets/icons/search-icon.svg'

const SearchBarComponent = ({onChange}) => {
    return (<View style={[styles.componentContainer,layoutStyles.elevation]}>
        <View style={styles.searchIcon}>
            <SearchIcon/>
        </View>
        <TextInput onChangeText={onChange ? (text) => onChange(text) : ()=>true} style={styles.input}/>
    </View>)
}

export default SearchBarComponent;

const styles = StyleSheet.create({
    componentContainer : {
        flex : 1,
        alignItems : 'center',
        backgroundColor : 'white',
        flexDirection : 'row',
        borderRadius : 1000
    },
    input : {
        flex : 1,
        paddingHorizontal : 15,
        paddingVertical : 10
    },
    searchIcon : {
        marginLeft : 10
    }
});