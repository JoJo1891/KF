import React from "react";

import {
  View,
  Text,
  StyleSheet,
  Platform,
  TouchableOpacity,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";

import BackArrowIcon from "../../assets/icons/backArrow.svg";
import BackArrowWhiteIcon from "../../assets/icons/backArrow-white.svg";
import { windowWidth } from "../../themes";

const SimpleHeaderComponent = ({ title, tintColor, notArrow }) => {
  const navigation = useNavigation();
  return (
    <View style={styles.headerContainer}>
      {!notArrow && (
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={
            Platform.OS === "android"
              ? (styles.backButtonContainer)
              : (styles.backButtonContainer2)
          }
        >
          <BackArrowIcon fill={tintColor === "white" ? "#ffffff" : "#174B9D"} />
        </TouchableOpacity>
      )}
      <View style={[styles.titleContainer]}>
        <Text
          style={[styles.title, tintColor === "white" ? styles.white : null]}
        >
          {title}
        </Text>
      </View>
    </View>
  );
};

export default SimpleHeaderComponent;

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: moderateVerticalScale(30),
    paddingBottom: moderateVerticalScale(10),
    marginHorizontal: 15,
    width: windowWidth - 30,
  },
  backButtonContainer: {
  },
  backButtonContainer2: {
    height: 40,
    justifyContent: "center",
    alignContent: "center",
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    fontFamily: "MontserratSemiBold",
    color: "#174B9D",
    paddingRight:moderateScale(15),
    fontSize: moderateScale(18),
    textAlign: "center",
  },
  white: {
    color: "white",
  },
});
