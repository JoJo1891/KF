import React from "react";

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";

import BackArrowIcon from "../../assets/icons/backArrow.svg";
import RelojIcon from "../../assets/icons/clock.svg";
import { windowWidth } from "../../themes";
import { useSelector } from "react-redux";
import { selectIsLogged } from "../../state/auth";

const CompositeHeaderComponent = ({ title, tintColor }) => {
  const isLogged = useSelector(selectIsLogged);
  const navigation = useNavigation();
  return (
    <View style={styles.headerContainer}>
      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={styles.backButtonContainer2}
      >
        <BackArrowIcon fill={tintColor === "white" ? "#ffffff" : "#174B9D"} />
      </TouchableOpacity>

      {Platform.isPad === true ? (
        <>
          {isLogged && (
            <TouchableOpacity
              onPress={() => navigation.navigate("EarningsHistoryScreen")}
              style={[styles.clockContainer, { paddingLeft: 620 }]}
            >
              <RelojIcon fill={tintColor === "white" ? "#ffffff" : "#174B9D"} />
            </TouchableOpacity>
          )}
        </>
      ) : (
        <>
          {isLogged && (
            <TouchableOpacity
              onPress={() => navigation.navigate("EarningsHistoryScreen")}
              style={styles.clockContainer}
            >
              <RelojIcon fill={tintColor === "white" ? "#ffffff" : "#174B9D"} />
            </TouchableOpacity>
          )}
        </>
      )}
    </View>
  );
};

export default CompositeHeaderComponent;

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: "row",
    width: "100%",
    alignItems: "center",
    marginTop: moderateVerticalScale(30),
    paddingBottom: moderateVerticalScale(10),
    marginHorizontal: 15,
  },
  clockContainer: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "flex-end",
    width: "40%",
  },
  backButtonContainer2: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "flex-start",
    width: "50%",
  },
  titleContainer: {
    textAlign: "center",
    flex: 1,
  },
  title: {
    fontFamily: "MontserratSemiBold",
    color: "#174B9D",
    fontSize: moderateScale(18),
    textAlign: "center",
  },
  white: {
    color: "white",
  },
});
