import React from "react";

import { View, Platform, StyleSheet, TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";
import {
  moderateScale,
  moderateVerticalScale,
} from "react-native-size-matters";

import BackArrowIcon from "../../assets/icons/backArrow.svg";
import CarteIcon from "../../assets/icons/carte.svg";
import { windowWidth } from "../../themes";
import { useSelector } from "react-redux";
import { selectIsLogged } from "../../state/auth";

const CompositeHeaderComponentRating = ({ title, tintColor }) => {
  const navigation = useNavigation();
  return (
    <View style={styles.headerContainer}>
      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={
          Platform.OS === "android"
            ? styles.backButtonContainer
            : styles.backButtonContainer2
        }
      >
        <BackArrowIcon fill={tintColor === "white" ? "#ffffff" : "#174B9D"} />
      </TouchableOpacity>

      {Platform.OS === "android" && (
        <TouchableOpacity
          style={[
            styles.backButtonContainer,
            { position: "absolute", right: 0 },
          ]}
        >
          <CarteIcon fill={tintColor === "white" ? "#ffffff" : "#174B9D"} />
        </TouchableOpacity>
      )}
    </View>
  );
};

export default CompositeHeaderComponentRating;

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: moderateVerticalScale(30),
    paddingBottom: moderateVerticalScale(10),
    marginHorizontal: 15,
    // height : moderateVerticalScale(30),
    width: windowWidth - 30,
  },
  backButtonContainer: {},
  backButtonContainer2: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignContent: "center",
  },
  titleContainer: {
    textAlign: "center",
    flex: 1,
  },
  title: {
    fontFamily: "MontserratSemiBold",
    color: "#174B9D",
    fontSize: moderateScale(18),
    textAlign: "center",
  },
  white: {
    color: "white",
  },
});
