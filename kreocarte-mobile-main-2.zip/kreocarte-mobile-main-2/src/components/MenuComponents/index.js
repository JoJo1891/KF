import React ,{ useState} from 'react';
import {
    View,
    StyleSheet,
    Text,ScrollView,TouchableOpacity
} from 'react-native';

import dayjs from 'dayjs';
import 'dayjs/locale/fr';
import UserIcon from '../../assets/icons/user_available.svg';
import GfIcon from '../../assets/icons/gf_points_lightblue.svg';
import ParametresIcon from '../../assets/icons/preference_menu.svg';
import MegaphoneIcon from '../../assets/icons/megaphone.svg';
import HelpIcon from '../../assets/icons/help_faqs_menu.svg';
import TermsIcon from '../../assets/icons/terms_condition_menu.svg';
import EmailIcon from '../../assets/icons/email_menu.svg';
import ArrowIcon from '../../assets/icons/backArrow.svg';
import Avatar1 from '../../assets/icons/avatar_1S.svg';
import Avatar2 from '../../assets/icons/avatar_2S.svg';
import { useNavigation } from '@react-navigation/native';
import GofidButton from '../partials/GofidButton';
import UserIconInactive from '../../assets/icons/user_unavailable.svg';
import ParametresIconInactive from '../../assets/icons/preference_menu_unavailable.svg';
import MegaphoneIconInactive from '../../assets/icons/megaphone_unavailable.svg';
import { moderateScale } from 'react-native-size-matters';



const MenuComponent = ({user, name , inscrit, img, menuAct}) => {

        const navigation = useNavigation();

        function returnImg() {
            if (user?.sexe === "femme") {
                return <Avatar1/>
           } else {
            return <Avatar2/>
           }
        }


    return (

        <View style={styles.screenContainer}>

 {/* --------------- Menu Logged (menuAct=true)--------------*/}
       {menuAct  &&
        <View >
       
            <View style={ styles.userBorder}>
                   
                    <View style={{width:'20%', alignContent:'center', alignItems:'center'}}>
                         {returnImg()}
                    </View>
                    <View style={{width:'80%'}}>
                        <Text style={[styles.userName, (!user?.nom ? {fontSize: moderateScale(14)} : {})]}>
                        {user?.nom ? `${user.nom} ${user.prenom || ''}`: user?.email || "Invite"}
                        </Text>
                        <Text style={styles.date}>
                         Inscrit depuis le {dayjs(user?.inscription_date?.date? user.inscription_date.date : user?.inscription_date).locale('fr').format('DD MMMM YYYY')}
                        </Text>
                    </View>      
                
            </View>

            {/* tambien el modelo de fecha francesa es Dia, Fecha, Mes, Año : Martes 25 de enero de 2022 (sin comas) */}
             

            <TouchableOpacity style={ styles.labelBorder} onPress={()=> navigation.navigate('CompteScreen')}>
                    <View style={ styles.icon}>
                            <UserIcon/>
                    </View>
                    <View style={styles.label}>
                        <Text style={styles.txt}>
                                Compte
                        </Text>
                    </View>
                    <View style={styles.arrow}>
                        <ArrowIcon style={{transform: [{ rotate: '180deg'}]}}/>
                    </View>
            </TouchableOpacity>

            <TouchableOpacity style={ styles.labelBorder} onPress={() => navigation.navigate("DefisPointsScreen")}>
                    <View style={ styles.icon}>
                            <GfIcon/>
                    </View>
                    <View style={styles.label}>
                        <Text style={styles.txt}>
                        Défis
                        </Text>
                    </View>
                    <View style={styles.arrow}>
                        <ArrowIcon style={{transform: [{ rotate: '180deg'}]}}/>
                    </View>
            </TouchableOpacity>

            <TouchableOpacity style={ styles.labelBorder} onPress={()=> navigation.navigate('ParameterScreen')}>
                     <View style={ styles.icon}>
                            <ParametresIcon/>
                    </View>
                    <View style={styles.label}>
                        <Text style={styles.txt}>
                                Paramètres
                        </Text>
                    </View>
                    <View style={styles.arrow}>
                        <ArrowIcon style={{transform: [{ rotate: '180deg'}]}}/>
                    </View>
            </TouchableOpacity>

            <TouchableOpacity style={ styles.labelBorder} onPress={()=> navigation.navigate('RecommendScreen')}>
                   <View style={ styles.icon}>
                            <MegaphoneIcon/>
                    </View>
                    <View style={styles.label}>
                        <Text style={styles.txt}>
                                 Recommander
                        </Text>
                    </View>
                    <View style={styles.arrow}>
                        <ArrowIcon style={{transform: [{ rotate: '180deg'}]}}/>
                    </View>
            </TouchableOpacity>

      </View>
        }


    {/* --------------- Menu (menuAct=false)--------------*/}

    {!menuAct  &&
        <View >
       
            <View style={ { marginBottom: 46,  marginTop: 60, width:'100%'}}>
                        <Text style={styles.invite}>
                             Invité
                        </Text>
                        <View style={{ marginTop:25}}>
                            <GofidButton
                                name="blue"
                                    value="Connectez-vous"
                                    press={()=> navigation.navigate('LoginScreen')}
                            />
                         </View>
            </View>
             

            <TouchableOpacity style={ styles.labelBorder} >
                    <View style={ styles.icon}>
                            <UserIconInactive/>
                    </View>
                    <View style={styles.label}>
                        <Text style={styles.txt2}>
                                Compte
                        </Text>
                    </View>
                    <View style={styles.arrow}>
                        <ArrowIcon style={{transform: [{ rotate: '180deg'}]}}/>
                    </View>
            </TouchableOpacity>

            <TouchableOpacity style={ styles.labelBorder} >
                     <View style={ styles.icon}>
                            <ParametresIconInactive/>
                    </View>
                    <View style={styles.label}>
                        <Text style={styles.txt2}>
                                Paramètres
                        </Text>
                    </View>
                    <View style={styles.arrow}>
                        <ArrowIcon style={{transform: [{ rotate: '180deg'}]}}/>
                    </View>
            </TouchableOpacity>

            <TouchableOpacity style={ styles.labelBorder}>
                   <View style={ styles.icon}>
                            <MegaphoneIconInactive/>
                    </View>
                    <View style={styles.label}>
                        <Text style={styles.txt2}>
                                 Recommander
                        </Text>
                    </View>
                    <View style={styles.arrow}>
                        <ArrowIcon style={{transform: [{ rotate: '180deg'}]}}/>
                    </View>
            </TouchableOpacity>

      </View>
        }

            <TouchableOpacity style={ styles.labelBorder} onPress={()=> navigation.navigate('HelpScreen')}>
                    <View style={ styles.icon}>
                            <HelpIcon/>
                    </View>
                    <View style={styles.label}>
                        <Text style={styles.txt}>
                                Aide
                        </Text>
                    </View>
                    <View style={styles.arrow}>
                        <ArrowIcon style={{transform: [{ rotate: '180deg'}]}}/>
                    </View>
            </TouchableOpacity>

            <TouchableOpacity style={ styles.labelBorder} onPress={()=> navigation.navigate('CguScreen')}>
                    <View style={ styles.icon}>
                            <TermsIcon/>
                    </View>
                    <View style={styles.label}>
                        <Text style={styles.txt}>
                                 CGU
                        </Text>
                    </View>
                    <View style={styles.arrow}>
                        <ArrowIcon style={{transform: [{ rotate: '180deg'}]}}/>
                    </View>
            </TouchableOpacity>

            <TouchableOpacity style={ styles.labelBorder} onPress={()=> navigation.navigate('ContactScreen')}>
                     <View style={ styles.icon}>
                            <EmailIcon/>
                    </View>
                    <View style={styles.label}>
                        <Text style={styles.txt}>
                        Contactez- nous
                        </Text>
                    </View>
                    <View style={styles.arrow}>
                        <ArrowIcon style={{transform: [{ rotate: '180deg'}]}}/>
                    </View>
            </TouchableOpacity>


      </View>
    
 )
}

export default MenuComponent;

const styles = StyleSheet.create({
    screenContainer: {
        flex: 1,
        marginHorizontal: 16
      },
      userBorder:{
        alignItems:'center',
        borderColor: '#EBEBEB',
        borderBottomWidth: 1,
        flexDirection:"row", 
        paddingBottom: 47.7,
        paddingTop: 60,
        width:'100%'
      },
      userName:{
        fontFamily: 'MontserratBold',
        fontSize: moderateScale(20),
        color: '#174B9D',
        paddingBottom: 4,
        textAlign:'left'
        
      },
      date:{
        fontFamily: 'MontserratMedium',
        fontSize: 15,
        color: '#989898',
        textAlign:'left'
      },
      labelBorder:{
            alignItems:'center',
            borderColor: '#EBEBEB',
            borderBottomWidth: 1,
            flexDirection:"row", 
            width: '100%',
      },
      label: {
          alignItems:'center',
          width:'70%',
          height:68.3,
          flexDirection:"row", 

      },
      icon: {
          alignItems:'center',
          width:'20%'
      },
      txt:{
        fontFamily: 'MontserratSemiBold',
        fontSize: 20,
        color: '#174B9D',   
      },
      arrow:{
              width:'10%',
              alignItems:'center'
      },
      invite:{
        fontFamily: 'MontserratBold',
        fontSize: 28,
        color: '#174B9D',
        paddingBottom: 4,
        textAlign:'center'
      },
      txt2:{
        fontFamily: 'MontserratSemiBold',
        fontSize: 20,
        color: '#707070',   
        opacity: 0.5
      },

});