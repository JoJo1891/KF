import React, { useEffect, useState } from 'react';

import {
    View,
    StyleSheet,
    FlatList,
    Alert,
} from 'react-native';
import  FidelityListItem  from './FidelityListItem';
import { windowHeight } from "../../themes";
import { moderateScale } from 'react-native-size-matters';


const FidelityListComponent = ({rewards, maxItem }) => {

  const [list,setList] = useState([])

  const arrayComplete = () => {
    if (rewards.length < maxItem){
      let arr = rewards;
        for (let i = rewards.length ; i < maxItem; i++) {
          let item = {
            type:null
          }
          arr.push(item);
        }
      setList(arr)
    } else {
      setList(rewards)
    }
  }

  useEffect(() => {
    arrayComplete()
  });
          
   
  
    return (
    <View style={styles.listContainer}>
        <FlatList
            scrollEnable
            data={list}
            horizontal
            renderItem={({item})=> <FidelityListItem {...item}/>}
            keyExtractor={(_, index) => "key" + index}
            showsHorizontalScrollIndicator={false}
        />
    </View>)
}

export default FidelityListComponent;

const styles = StyleSheet.create({
    listContainer: {
      height: windowHeight / 12,
      flexDirection: "row",
      marginHorizontal:moderateScale(16),

    },
   
});