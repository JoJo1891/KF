
import React from 'react';

import {
    View,
    StyleSheet,
    Image,
    Text
} from 'react-native';

import BagdeFidelity from '../../assets/badges/bag_color_big.svg';
import BagdeFidelityGrey from "../../assets/badges/bag_grey.svg";
import {windowHeight, windowWidth} from '../../themes';

const FidelityListItem = ({type, recompense}) => {
    return (
        <View>
            {
                type != null ?
                <>
                <View style={styles.imageContainerColor}>
                    <BagdeFidelity
                        width="100%"
                        height="100%"
                    />
                </View>
                {/* <Text style={{fontSize:8, textAlign:'center', color:"#4DBDF2"}}>{recompense}</Text> */}
                </>
                :
                <View style={styles.imageContainerGrey}>
                    <BagdeFidelityGrey
                        width="100%"
                        height="100%"
                    />
                </View>
            }
        </View>
    )
}

export default FidelityListItem;

const styles = StyleSheet.create({
    imageContainerColor : {
   
        width : windowWidth/8,
        height: windowHeight/17,
        overflow : 'hidden',
        borderRadius : windowWidth/6,
        borderWidth : 1,
        borderColor : '#4DBDF2',
        justifyContent : 'center',
        marginLeft: 1,
        marginRight: 1,
    },
 
    imageContainerGrey:{
        width : windowWidth/8,
        height: windowHeight/17,
        overflow : 'hidden',
        borderRadius : windowWidth/6,
        borderWidth : 1,
        borderColor : '#E1E1E1',
        justifyContent : 'center',
        marginLeft: 1,
        marginRight: 1,
    }
})